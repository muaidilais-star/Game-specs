package com.aisz.gamespace.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.width
import androidx.compose.ui.composed
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.AssistantBridge
import com.aisz.gamespace.AssistantEngine
import com.aisz.gamespace.ClaudeClient
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.MusicEngine
import com.aisz.gamespace.PerformanceMonitor
import com.aisz.gamespace.ShizukuHelper
import com.aisz.gamespace.TemperatureMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private class ChatMsg(val fromUser: Boolean, val text: String)

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

private fun statusText(ctx: Context): String {
    val g = GameSettings(ctx)
    val perf = PerformanceMonitor(ctx)
    val mem = perf.memory()
    val bat = perf.battery()
    val th = TemperatureMonitor(ctx).read()
    val live = (0 until GameSettings.LIVE_SLOTS).count { g.liveOn(it) }
    val shizuku = when {
        !ShizukuHelper.isInstalled(ctx) -> "belum dipasang"
        ShizukuHelper.isRunning() && ShizukuHelper.hasPermission() -> "aktif"
        ShizukuHelper.isRunning() -> "berjalan, izin belum diberikan"
        else -> "belum berjalan"
    }
    return listOf(
        "Mode: ${g.profile.label}",
        "Suhu baterai: ${th.batteryC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "N/A"} (${th.level.label})",
        "RAM: ${mem.usedPercent}% terpakai, ${mem.availMb} MB bebas",
        "Baterai: ${bat.levelPercent?.let { "$it%" } ?: "N/A"}${if (bat.charging) " (mengisi)" else ""}",
        "Refresh layar: ${String.format(Locale.US, "%.0f Hz", perf.deviceInfo().refreshRateHz)}",
        "Ping rendah: ${if (g.pingLow) "aktif" else "mati"}; Fokus: ${if (g.focusActive) "aktif" else "mati"}",
        "Tekstur Ringan: ${if (g.texApplied) "aktif" else "mati"}; Turunkan Resolusi: ${if (g.texAltApplied) "aktif" else "mati"}",
        "Overlay live: $live slot tampil; Musik: ${if (MusicEngine.isPlaying) "memutar" else "berhenti"}",
        "Shizuku: $shizuku"
    ).joinToString("\n")
}

/** Menjalankan satu aksi dan mengembalikan teks hasilnya. */
private fun runAction(ctx: Context, a: AssistantEngine.Action): String {
    if (!AssistantEngine.isAllowed(a)) return "Aksi tidak diizinkan: ${a.name}"
    if (a.name == "status") return statusText(ctx)
    val exec = AssistantBridge.execute ?: return "Panel Game Space belum menyala. Nyalakan dulu lewat Home > Masuk ke Game Space."
    return try {
        exec(a.name, a.arg)
    } catch (e: Exception) {
        "Gagal menjalankan ${a.name}: ${e.message}"
    }
}

@Composable
fun AssistantScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val settings = remember { GameSettings(ctx) }
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf(
            ChatMsg(
                false,
                "Halo! Saya asisten AISZ. Minta saya mengatur mode (\"mode performa\"), menyalakan fitur (\"nyalakan fokus\"), " +
                    "memutar musik, mengecek status HP, atau tanya apa saja soal AISZ GAME SPACE."
            )
        )
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(settings.aiOnline && settings.aiKey.isNotBlank()) }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, busy) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    fun addBot(text: String) {
        if (text.isNotBlank()) messages.add(ChatMsg(false, text))
    }

    fun runActions(actions: List<AssistantEngine.Action>) {
        for (a in actions) addBot("\u2713 " + runAction(ctx, a))
    }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        val history = messages.map { it.fromUser to it.text }
        messages.add(ChatMsg(true, text))
        input = ""
        if (settings.aiOnline && settings.aiKey.isNotBlank()) {
            busy = true
            scope.launch {
                val res = withContext(Dispatchers.IO) {
                    ClaudeClient.ask(settings.aiKey, ClaudeClient.systemPrompt(statusText(ctx)), history, text)
                }
                busy = false
                if (res.error != null) {
                    addBot("Claude online gagal: ${res.error}\nMemakai asisten offline.")
                    val local = AssistantEngine.interpret(text)
                    addBot(local.text)
                    runActions(local.actions)
                } else {
                    addBot(res.reply ?: "")
                    runActions(res.actions)
                }
            }
        } else {
            val local = AssistantEngine.interpret(text)
            addBot(local.text)
            runActions(local.actions)
        }
    }

    Column(Modifier.fillMaxSize().background(AiszColors.Black).systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("\u2039 Kembali", color = AiszColors.Neon, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickableNoRipple { onClose() }.padding(end = 12.dp, top = 4.dp, bottom = 4.dp))
            Column(Modifier.weight(1f)) {
                Text("Asisten AISZ", color = AiszColors.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (online) "Claude online (${ClaudeClient.MODEL})" else "Offline: tanpa internet",
                    color = if (online) AiszColors.Ok else AiszColors.TextDim, fontSize = 11.sp
                )
            }
            Text("\u2699", color = AiszColors.Neon, fontSize = 24.sp,
                modifier = Modifier.clickableNoRipple { showSettings = true }.padding(8.dp))
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    val shape = RoundedCornerShape(16.dp)
                    Text(
                        m.text,
                        color = AiszColors.Text,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .widthIn(max = 520.dp)
                            .background(if (m.fromUser) AiszColors.Neon.copy(alpha = 0.22f) else AiszColors.Surface, shape)
                            .border(1.dp, (if (m.fromUser) AiszColors.Neon else AiszColors.TextDim).copy(alpha = 0.3f), shape)
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
            if (busy) {
                item { Text("Mengetik...", color = AiszColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(4.dp)) }
            }
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Mode performa", "Mode hemat daya", "Mode seimbang", "Cek status HP", "Nyalakan fokus", "Putar musik", "Apa itu tekstur ringan?")
                .forEach { q -> NeonChip(q, false, Modifier) { send(q) } }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ketik perintah atau pertanyaan...", color = AiszColors.TextDim, fontSize = 13.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send(input) }),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = AiszColors.Text,
                    unfocusedTextColor = AiszColors.Text,
                    focusedBorderColor = AiszColors.Neon,
                    unfocusedBorderColor = AiszColors.TextDim,
                    cursorColor = AiszColors.Neon
                )
            )
            Spacer(Modifier.width(8.dp))
            NeonButton("Kirim", Modifier.height(54.dp), enabled = !busy) { send(input) }
        }
    }

    if (showSettings) {
        var keyText by remember { mutableStateOf(settings.aiKey) }
        var onlineSwitch by remember { mutableStateOf(settings.aiOnline) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Pengaturan asisten") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Asisten offline selalu jalan tanpa internet. Opsional: pakai Claude online untuk jawaban yang lebih " +
                            "bebas. Perlu kunci API Anthropic milik lu sendiri.",
                        fontSize = 12.sp
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pakai Claude online", modifier = Modifier.weight(1f), fontSize = 14.sp)
                        Switch(
                            checked = onlineSwitch, onCheckedChange = { onlineSwitch = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = AiszColors.Neon, checkedThumbColor = AiszColors.Black)
                        )
                    }
                    OutlinedTextField(
                        value = keyText,
                        onValueChange = { keyText = it },
                        label = { Text("Kunci API") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Kunci disimpan hanya di HP ini dan hanya dikirim ke api.anthropic.com. Yang dikirim: pesan lu dan ringkasan " +
                            "status HP (mode, suhu, RAM, baterai). Pemakaian dikenai biaya sesuai akun lu. Asisten hanya boleh " +
                            "menjalankan aksi daftar putih: ganti mode, ping, fokus, overlay, musik, bersihkan RAM.",
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    settings.aiKey = keyText
                    settings.aiOnline = onlineSwitch && keyText.isNotBlank()
                    online = settings.aiOnline
                    showSettings = false
                }) { Text("Simpan") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        settings.aiKey = ""
                        settings.aiOnline = false
                        online = false
                        showSettings = false
                    }) { Text("Hapus kunci") }
                    TextButton(onClick = { showSettings = false }) { Text("Batal") }
                }
            }
        )
    }
}
