package com.aisz.gamespace

/**
 * Jembatan dari layar Asisten ke panel Game Space. Panel mengisi [execute]; hanya aksi yang ada di daftar putih
 * ([AssistantEngine.allowedActions]) yang pernah sampai ke sini.
 */
object AssistantBridge {
    /** (nama aksi, argumen) -> pesan hasil. Null bila panel Game Space belum menyala. */
    var execute: ((String, String) -> String)? = null
}
