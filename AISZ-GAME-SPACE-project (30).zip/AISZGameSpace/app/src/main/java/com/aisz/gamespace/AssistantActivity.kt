package com.aisz.gamespace

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.aisz.gamespace.ui.AiszTheme
import com.aisz.gamespace.ui.AssistantScreen

/** Layar chat Asisten AISZ. */
class AssistantActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AiszTheme {
                AssistantScreen(onClose = { finish() })
            }
        }
    }
}
