package com.aisz.gamespace

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Efek suara real time (16-bit mono). Jenis: 0 anak-anak, 1 robot, 2 perempuan, 3 laki-laki.
 * Anak/perempuan/laki-laki memakai pergeseran nada (pitch shifter jalur tunda dua kepala, bayangan
 * formant ikut bergeser sehingga terdengar lebih kecil/besar); robot memakai ring modulator + comb.
 */
class VoiceFx(private val sr: Int) {
    var type = 0
    var mix = 1f
    var volume = 1f

    private val delayWin = 0.035f * sr
    private val bufSize = (sr * 0.1f).toInt() + 8
    private val buf = FloatArray(bufSize)
    private var w = 0
    private var phase = 0f

    private var rp = 0f
    private val combLen = (sr * 0.004f).toInt().coerceAtLeast(8)
    private val comb = FloatArray(combLen)
    private var ci = 0
    private var gate = 0f
    private val twoPi = 2f * PI.toFloat()

    private fun readDelay(delay: Float): Float {
        var pos = w - delay
        while (pos < 0f) pos += bufSize
        val i0 = pos.toInt() % bufSize
        val i1 = (i0 + 1) % bufSize
        val f = pos - floor(pos)
        return buf[i0] * (1f - f) + buf[i1] * f
    }

    private fun pitch(x: Float, ratio: Float): Float {
        buf[w] = x
        val p1 = phase
        val p2 = (phase + 0.5f) % 1f
        val y1 = readDelay(p1 * delayWin)
        val y2 = readDelay(p2 * delayWin)
        val g1 = 0.5f - 0.5f * cos(twoPi * p1)
        val g2 = 0.5f - 0.5f * cos(twoPi * p2)
        phase += (1f - ratio) / delayWin
        if (phase >= 1f) phase -= 1f
        if (phase < 0f) phase += 1f
        w = (w + 1) % bufSize
        return y1 * g1 + y2 * g2
    }

    private fun robot(x: Float): Float {
        val r = x * sin(rp)
        rp += twoPi * 55f / sr
        if (rp > twoPi) rp -= twoPi
        val c = r + 0.45f * comb[ci]
        comb[ci] = c
        ci = (ci + 1) % combLen
        val z = c * 3.5f
        return z / (1f + abs(z))
    }

    /** Memproses n sampel dari inp ke out. */
    fun process(inp: ShortArray, n: Int, out: ShortArray) {
        var sum = 0f
        for (i in 0 until n) {
            val v = inp[i] / 32768f
            sum += v * v
        }
        val rms = sqrt(sum / max(1, n))
        val gateTarget = if (rms < 0.006f) 0f else 1f
        for (i in 0 until n) {
            val x = inp[i] / 32768f
            gate += (gateTarget - gate) * 0.02f
            val y = when (type) {
                0 -> pitch(x, 1.55f)
                1 -> robot(x)
                2 -> pitch(x, 1.30f)
                else -> pitch(x, 0.78f)
            }
            val m = x * (1f - mix) + y * mix
            val o = m * volume * gate
            out[i] = (o.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
    }
}
