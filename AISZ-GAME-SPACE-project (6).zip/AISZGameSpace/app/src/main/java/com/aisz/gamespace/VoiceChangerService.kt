package com.aisz.gamespace

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.max

/**
 * Pengubah suara: mikrofon -> efek -> speaker/headset. Mode langsung (live) dan uji 4 detik.
 * Catatan platform: aplikasi biasa tidak bisa menggantikan mikrofon aplikasi lain (mis. chat suara game),
 * dan Android dapat membisukan rekaman bila aplikasi lain memakai mikrofon bersamaan.
 */
class VoiceChangerService : Service() {

    @Volatile private var live = false
    @Volatile private var testing = false
    private var worker: Thread? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                live = false
                if (!testing) finishService()
            }
            ACTION_TEST -> {
                if (!enterForeground()) return START_NOT_STICKY
                startTest()
            }
            else -> {
                if (!enterForeground()) return START_NOT_STICKY
                startLive()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        live = false
        isRunning = false
        super.onDestroy()
    }

    private fun say(msg: String) {
        main.post {
            if (!FloatingPanelService.announce(msg)) {
                Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun finishService() {
        isRunning = false
        main.post {
            try {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } catch (_: Exception) {
            }
            stopSelf()
        }
    }

    private fun enterForeground(): Boolean {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Izin mikrofon belum diberikan.")
            stopSelf()
            return false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "Pengubah suara", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 3, Intent(this, VoiceChangerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("AISZ GAME SPACE")
            .setContentText("Pengubah suara aktif")
            .setOngoing(true)
            .addAction(0, "Hentikan", stop)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            say("Tidak dapat memulai pengubah suara: ${e.message ?: "ditolak sistem"}")
            stopSelf()
            return false
        }
        isRunning = true
        return true
    }

    private fun buildTrack(frame: Int): AudioTrack {
        val minOut = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val b = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minOut, frame * 2 * 3))
            .setTransferMode(AudioTrack.MODE_STREAM)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }
        return b.build()
    }

    private fun newRecord(frame: Int): AudioRecord? {
        val minIn = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return try {
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minIn, frame * 4)
            )
            if (r.state == AudioRecord.STATE_INITIALIZED) r else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ mode langsung

    private fun startLive() {
        if (live || testing) return
        live = true
        worker = Thread({ runLive() }, "aisz-voice").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun runLive() {
        val gs = GameSettings(this)
        val frame = 1024
        val rec = newRecord(frame)
        if (rec == null) {
            say("Mikrofon tidak dapat dibuka (sedang dipakai aplikasi lain?).")
            live = false
            finishService()
            return
        }
        val track = buildTrack(frame)
        val fx = VoiceFx(SR)
        val inp = ShortArray(frame)
        val out = ShortArray(frame)
        var silent = 0
        var warned = false
        try {
            rec.startRecording()
            track.play()
            say("Pengubah suara aktif: ${TYPE_NAMES[gs.voiceType.coerceIn(0, 3)]}. Pakai headset agar tidak berdengung.")
            while (live) {
                fx.type = gs.voiceType
                fx.mix = gs.voiceMix / 100f
                fx.volume = gs.voiceVolume / 50f
                val n = rec.read(inp, 0, frame)
                if (n <= 0) continue
                var peak = 0
                for (i in 0 until n) peak = max(peak, abs(inp[i].toInt()))
                if (peak == 0) silent++ else silent = 0
                if (silent > 90 && !warned) {
                    warned = true
                    say("Mikrofon terbisukan: aplikasi lain (mis. game) sedang memakainya.")
                }
                fx.process(inp, n, out)
                track.write(out, 0, n)
            }
        } catch (e: Exception) {
            say("Pengubah suara berhenti: ${e.message ?: "kesalahan audio"}")
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            try { track.stop() } catch (_: Exception) {}
            track.release()
            live = false
            if (!testing) finishService()
        }
    }

    // ------------------------------------------------------------ uji 4 detik

    private fun startTest() {
        if (live) {
            say("Matikan pengubah suara langsung dulu sebelum uji.")
            return
        }
        if (testing) return
        testing = true
        worker = Thread({ runTest() }, "aisz-voice-test").apply { start() }
    }

    private fun runTest() {
        val gs = GameSettings(this)
        val frame = 1024
        val total = SR * 4
        val rec = newRecord(frame)
        try {
            if (rec == null) {
                say("Mikrofon tidak dapat dibuka (sedang dipakai aplikasi lain?).")
                return
            }
            val data = ShortArray(total)
            say("Bicara sekarang (4 detik)...")
            rec.startRecording()
            var pos = 0
            while (pos < total) {
                val n = rec.read(data, pos, minOf(frame, total - pos))
                if (n <= 0) break
                pos += n
            }
            rec.stop()
            val fx = VoiceFx(SR)
            fx.type = gs.voiceType
            fx.mix = gs.voiceMix / 100f
            fx.volume = gs.voiceVolume / 50f
            val out = ShortArray(pos)
            var i = 0
            val tmpIn = ShortArray(frame)
            val tmpOut = ShortArray(frame)
            while (i < pos) {
                val n = minOf(frame, pos - i)
                System.arraycopy(data, i, tmpIn, 0, n)
                fx.process(tmpIn, n, tmpOut)
                System.arraycopy(tmpOut, 0, out, i, n)
                i += n
            }
            say("Memutar suara ${TYPE_NAMES[gs.voiceType.coerceIn(0, 3)]}...")
            val track = buildTrack(frame)
            try {
                track.play()
                track.write(out, 0, pos)
                Thread.sleep(pos * 1000L / SR + 250L)
                track.stop()
            } finally {
                track.release()
            }
        } catch (e: Exception) {
            say("Uji suara gagal: ${e.message ?: "kesalahan audio"}")
        } finally {
            rec?.release()
            testing = false
            if (!live) finishService()
        }
    }

    companion object {
        const val ACTION_START = "com.aisz.gamespace.action.VOICE_START"
        const val ACTION_STOP = "com.aisz.gamespace.action.VOICE_STOP"
        const val ACTION_TEST = "com.aisz.gamespace.action.VOICE_TEST"
        private const val CHANNEL = "aisz_voice"
        private const val NOTIF_ID = 1003
        private const val SR = 44100
        val TYPE_NAMES = listOf("Anak-anak", "Robot", "Perempuan", "Laki-laki")

        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
