package com.aisz.gamespace

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Aktivitas transparan singkat: meminta izin mikrofon bila perlu, lalu memulai layanan pengubah suara
 * dari kondisi latar depan (syarat Android 12+ agar mikrofon boleh dipakai layanan).
 */
class VoiceRequestActivity : ComponentActivity() {

    private var action = VoiceChangerService.ACTION_START

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startVoice()
        } else {
            Toast.makeText(this, "Izin mikrofon ditolak.", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        action = intent.getStringExtra("action") ?: VoiceChangerService.ACTION_START
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice()
        } else {
            perm.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoice() {
        ContextCompat.startForegroundService(
            this, Intent(this, VoiceChangerService::class.java).setAction(action)
        )
        finish()
    }
}
