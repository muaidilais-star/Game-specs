package com.aisz.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

data class ShellResult(val ok: Boolean, val output: String, val error: String = "")

data class FpsResult(val fps: Int?, val note: String)

/**
 * Akses shell lewat Shizuku. Shizuku dimulai tanpa root lewat Debugging nirkabel (Android 11+)
 * atau ADB dari PC. Catatan: Shizuku yang dimulai lewat ADB nirkabel berhenti saat Wi-Fi putus
 * atau HP dimulai ulang.
 */
object ShizukuHelper {
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val REQUEST_CODE = 4242

    fun isInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku belum berjalan
        }
    }

    /** Menjalankan perintah shell. Panggil dari thread latar belakang, bukan UI. */
    fun exec(command: String): ShellResult {
        if (!hasPermission()) return ShellResult(false, "", "Shizuku belum aktif atau izin belum diberikan")
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = p.inputStream.bufferedReader().readText().trim()
            val err = p.errorStream.bufferedReader().readText().trim()
            val code = p.waitFor()
            val failed = code != 0 || out.startsWith("Error") || out.contains("Exception") ||
                out.contains("Unknown command")
            ShellResult(!failed, out, err)
        } catch (e: Throwable) {
            ShellResult(false, "", e.message ?: e.javaClass.simpleName)
        }
    }
}

/** Menjalankan perintah baca-saja (dumpsys) dengan izin DUMP milik AISZ sendiri, tanpa Shizuku. */
object LocalShell {
    fun exec(command: String): ShellResult = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
        val out = p.inputStream.bufferedReader().readText().trim()
        val err = p.errorStream.bufferedReader().readText().trim()
        p.waitFor()
        val denied = out.contains("Permission Denial") || err.contains("Permission Denial")
        ShellResult(!denied, out, err)
    } catch (e: Throwable) {
        ShellResult(false, "", e.message ?: "gagal")
    }
}

/** Perintah yang dipakai AISZ. Semua argumen divalidasi sebelum masuk ke shell. */
object ShellTools {
    private val SAFE = Regex("[A-Za-z0-9._/]+")
    private fun safe(s: String): Boolean = SAFE.matches(s)

    @Volatile
    var appCtx: Context? = null

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
    }

    fun hasDump(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED

    fun hasSecureSettings(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** True bila FPS/foreground bisa dibaca: lewat Shizuku, atau lewat izin DUMP milik AISZ. */
    fun canRead(): Boolean {
        if (ShizukuHelper.hasPermission()) return true
        val c = appCtx ?: return false
        return hasDump(c)
    }

    /** Membaca dumpsys: Shizuku bila aktif, selain itu izin DUMP sendiri. */
    fun read(cmd: String): ShellResult {
        if (ShizukuHelper.hasPermission()) return ShizukuHelper.exec(cmd)
        val c = appCtx
        if (c != null && hasDump(c)) return LocalShell.exec(cmd)
        return ShellResult(false, "", "Shizuku/DUMP tidak tersedia")
    }

    /**
     * Saat Shizuku aktif, AISZ memberi dirinya izin DUMP dan WRITE_SECURE_SETTINGS (izin tingkat
     * pengembang). Izin ini bertahan walau Shizuku berhenti, sehingga FPS dan Penghemat Baterai
     * tetap bisa dipakai.
     */
    fun ensureSelfPermissions(ctx: Context): Boolean {
        if (!ShizukuHelper.hasPermission()) return hasDump(ctx)
        val pkg = ctx.packageName
        ShizukuHelper.exec(
            "pm grant $pkg android.permission.DUMP; pm grant $pkg android.permission.WRITE_SECURE_SETTINGS"
        )
        return hasDump(ctx)
    }

    fun setBatterySaver(on: Boolean): ShellResult =
        ShizukuHelper.exec("settings put global low_power ${if (on) 1 else 0}")

    /** Mode kinerja HP (Power HAL). Tidak semua HP mendukung; hasil dilaporkan jujur. */
    fun setFixedPerformance(on: Boolean): ShellResult {
        val a = ShizukuHelper.exec("cmd power set-fixed-performance-mode-enabled ${if (on) "true" else "false"}")
        if (a.ok) return a
        return ShizukuHelper.exec("cmd power set-mode 2 ${if (on) "true" else "false"}")
    }

    /** mode: standard | performance | battery (Game Mode bawaan Android 12+). */
    fun setGameMode(pkg: String, mode: String): ShellResult {
        if (!safe(pkg) || mode !in listOf("standard", "performance", "battery")) {
            return ShellResult(false, "", "Argumen tidak valid")
        }
        return ShizukuHelper.exec("cmd game mode $mode $pkg")
    }

    fun lockRefreshRate(hz: Float): ShellResult {
        val v = String.format(Locale.US, "%.1f", hz)
        return ShizukuHelper.exec(
            "settings put system min_refresh_rate $v; settings put system peak_refresh_rate $v"
        )
    }

    fun unlockRefreshRate(): ShellResult = ShizukuHelper.exec(
        "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
    )

    fun setBrightness(value0to255: Int): ShellResult = ShizukuHelper.exec(
        "settings put system screen_brightness_mode 0; " +
            "settings put system screen_brightness ${value0to255.coerceIn(1, 255)}"
    )

    /** Paket aplikasi yang sedang di layar depan (dua cara, yang kedua sebagai cadangan). */
    fun foregroundPackage(): String? {
        val re = Regex("u\\d+\\s+([A-Za-z0-9._]+)/")
        val a = read(
            "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 2"
        ).output
        re.find(a)?.groupValues?.get(1)?.let { return it }
        val b = read("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -n 3").output
        return re.find(b)?.groupValues?.get(1)
    }

    private val layerCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    /**
     * FPS game dari SurfaceFlinger. `--list` menampilkan nama layer dengan akhiran "#id", sedangkan
     * `--latency` membandingkan nama TANPA akhiran itu, jadi kedua bentuk dicoba.
     */
    fun measureFps(pkg: String): FpsResult {
        if (!safe(pkg)) return FpsResult(null, "nama paket tidak valid")
        val cached = layerCache[pkg]
        if (cached != null) {
            val f = latencyFps(cached)
            if (f != null) return FpsResult(f, "ok")
            layerCache.remove(pkg)
        }
        val listed = read("dumpsys SurfaceFlinger --list")
        val layers = listed.output.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (layers.isEmpty()) return FpsResult(null, "daftar layer kosong ${listed.error.take(40)}".trim())
        val candidates = layers
            .filter {
                it.contains(pkg) && !it.startsWith("Background") && !it.startsWith("Bounds") &&
                    !it.startsWith("Dim")
            }
            .sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        if (candidates.isEmpty()) return FpsResult(null, "layer game belum ada (${layers.size} layer)")
        var best: Int? = null
        var bestName: String? = null
        for (layer in candidates.take(4)) {
            val variants = listOf(layer.replace(Regex("#\\d+$"), ""), layer).distinct()
            for (name in variants) {
                val f = latencyFps(name)
                val cur = best
                if (f != null && (cur == null || f > cur)) {
                    best = f
                    bestName = name
                }
                if (f != null) break
            }
        }
        val result = best
        val name = bestName
        if (result == null || name == null) return FpsResult(null, "data frame kosong (${candidates.size} layer)")
        layerCache[pkg] = name
        return FpsResult(result, "ok")
    }

    private fun latencyFps(name: String): Int? {
        if (name.contains("'")) return null
        val lines = read("dumpsys SurfaceFlinger --latency '$name'").output.lines()
        val times = lines.drop(1).mapNotNull { l ->
            val parts = l.trim().split(Regex("\\s+"))
            val t = parts.getOrNull(1)?.toLongOrNull()
            if (t == null || t <= 0L || t == Long.MAX_VALUE) null else t
        }.takeLast(120)
        if (times.size < 5) return null
        val latest = times.last()
        // Data basi (game diam/dijeda) dianggap 0 FPS, bukan angka lama.
        if (System.nanoTime() - latest > 1_500_000_000L) return 0
        // Hitung dari 1 detik terakhir agar angkanya real time.
        val recent = times.filter { latest - it <= 1_000_000_000L }
        val use = if (recent.size >= 4) recent else times.takeLast(30)
        val span = use.last() - use.first()
        if (span <= 0L) return null
        return ((use.size - 1) * 1_000_000_000.0 / span).toInt().coerceIn(0, 240)
    }

    /**
     * Membuka aplikasi dalam jendela mengambang (freeform). Bentuk jendela dan perilaku game di
     * belakangnya ditentukan HyperOS, bukan aplikasi ini.
     */
    fun launchFreeform(context: Context, pkg: String): ShellResult {
        val comp = context.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            ?: return ShellResult(false, "", "Aplikasi tidak punya launcher")
        if (!safe(pkg) || !safe(comp.replace("$", ""))) return ShellResult(false, "", "Argumen tidak valid")
        val first = ShizukuHelper.exec("am start --windowingMode 5 -n '$comp'")
        if (first.ok) return first
        ShizukuHelper.exec(
            "settings put global enable_freeform_support 1; settings put global force_resizable_activities 1"
        )
        return ShizukuHelper.exec("am start --windowingMode 5 -n '$comp'")
    }

    fun resetFreeform(): ShellResult = ShizukuHelper.exec(
        "settings delete global enable_freeform_support; " +
            "settings delete global force_resizable_activities; " +
            "settings delete global freeform_window_management"
    )

    fun forceStop(pkg: String): ShellResult {
        if (!safe(pkg)) return ShellResult(false, "", "Argumen tidak valid")
        return ShizukuHelper.exec("am force-stop $pkg")
    }

    /** Mengembalikan aplikasi ke layar penuh (windowing mode 1). */
    fun bringFullscreen(context: Context, pkg: String): ShellResult {
        val comp = context.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            ?: return ShellResult(false, "", "Aplikasi tidak punya launcher")
        if (!safe(pkg) || !safe(comp.replace("$", ""))) return ShellResult(false, "", "Argumen tidak valid")
        return ShizukuHelper.exec("am start --windowingMode 1 -n '$comp'")
    }

    fun maxRefreshRate(context: Context): Float {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val d = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY) ?: return 60f
        return d.supportedModes.maxOfOrNull { it.refreshRate } ?: d.refreshRate
    }
}

/**
 * Menerapkan mode benar-benar ke HP:
 * - Hemat daya: Penghemat Baterai HP menyala.
 * - Seimbang: kondisi normal; Penghemat Baterai dan mode kinerja dimatikan, tidak ada yang lain.
 * - Performa: aplikasi latar belakang dihentikan (AISZ dan game tidak ikut), mode kinerja HP menyala,
 *   Game Mode performa untuk game yang sedang dibuka.
 */
object ModeController {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun applyAsync(
        context: Context,
        p: GamingProfile,
        gamePkg: String?,
        onProgress: ((Float) -> Unit)? = null,
        onDone: ((String) -> Unit)? = null
    ) {
        val app = context.applicationContext
        executor.execute {
            val msg = applyBlocking(app, p, gamePkg) { f ->
                if (onProgress != null) main.post { onProgress(f) }
            }
            if (onDone != null) main.post { onDone(msg) }
        }
    }

    fun applyBlocking(ctx: Context, p: GamingProfile, gamePkg: String?, progress: (Float) -> Unit = {}): String {
        GameSettings(ctx).profile = p
        val parts = mutableListOf<String>()
        val shizuku = ShizukuHelper.hasPermission()
        progress(0.1f)

        // 1) Penghemat Baterai HP
        when (setBatterySaver(ctx, p == GamingProfile.HEMAT)) {
            true -> if (p == GamingProfile.HEMAT) parts += "Penghemat Baterai ON"
            false -> parts += "Penghemat Baterai gagal"
            null -> parts += "aktifkan Penghemat Baterai di layar yang terbuka"
        }
        progress(0.35f)

        // 2) Performa: hentikan aplikasi latar belakang, kecuali AISZ dan game
        if (p == GamingProfile.PERFORMA) {
            val freed = cleanBackground(ctx, setOf(gamePkg)) { f -> progress(0.35f + 0.3f * f) }
            parts += if (freed > 0) "app latar dihentikan (+$freed MB)" else "app latar sudah bersih"
        }
        progress(0.65f)

        // 3) Mode kinerja HP + Game Mode
        if (shizuku) {
            val perf = ShellTools.setFixedPerformance(p == GamingProfile.PERFORMA)
            if (p == GamingProfile.PERFORMA) {
                parts += if (perf.ok) "mode kinerja HP ON" else "mode kinerja tidak didukung HP ini"
            }
            if (gamePkg != null) {
                val gm = ShellTools.setGameMode(gamePkg, p.gameMode)
                parts += if (gm.ok) "Game Mode ${p.gameMode}" else "Game Mode tidak didukung game ini"
            }
        } else if (p == GamingProfile.PERFORMA) {
            parts += "mode kinerja HP butuh Shizuku"
        }
        progress(1f)
        val body = if (parts.isEmpty()) "tidak ada yang diubah" else parts.joinToString(" • ")
        return "Mode ${p.label}: $body"
    }

    /** true = berhasil, false = gagal, null = pengguna perlu mengaktifkan sendiri (pengaturan dibuka). */
    private fun setBatterySaver(ctx: Context, on: Boolean): Boolean? {
        val v = if (on) 1 else 0
        if (ShizukuHelper.hasPermission()) return ShellTools.setBatterySaver(on).ok
        if (ShellTools.hasSecureSettings(ctx)) {
            return try {
                Settings.Global.putInt(ctx.contentResolver, "low_power", v)
            } catch (e: Exception) {
                false
            }
        }
        if (on) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
            return null
        }
        return true
    }

    /**
     * Menghentikan proses latar belakang (cache). Aplikasi yang sedang tampil, AISZ (layanan latar
     * depan), dan game tidak ikut dihentikan. Mengembalikan MB memori yang bertambah.
     */
    fun cleanBackground(ctx: Context, keepExtra: Set<String?>, onStep: (Float) -> Unit = {}): Long {
        val pm = PerformanceMonitor(ctx)
        val before = pm.memory().availMb
        onStep(0.1f)
        if (ShizukuHelper.hasPermission()) {
            ShizukuHelper.exec("am kill-all")
        } else {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val keep = keepExtra + ctx.packageName
            ctx.packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            ).map { it.activityInfo.packageName }.distinct().filter { it !in keep }.forEach {
                try {
                    am.killBackgroundProcesses(it)
                } catch (_: Exception) {
                }
            }
        }
        onStep(0.6f)
        Thread.sleep(800)
        onStep(1f)
        return (pm.memory().availMb - before).coerceAtLeast(0L)
    }
}
