package com.aisz.gamespace

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import rikka.shizuku.Shizuku
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

data class ShellResult(val ok: Boolean, val output: String, val error: String = "")

/**
 * Akses shell lewat Shizuku. Shizuku bisa dimulai tanpa root lewat Debugging nirkabel
 * (Android 11+) atau lewat ADB dari PC. AISZ hanya memakai Shizuku bila pengguna mengizinkan.
 */
object ShizukuHelper {
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val REQUEST_CODE = 4242

    fun isInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku belum berjalan
        }
    }

    /** Menjalankan perintah shell. Panggil dari thread latar belakang, bukan UI. */
    fun exec(command: String): ShellResult {
        if (!hasPermission()) return ShellResult(false, "", "Shizuku belum aktif atau izin belum diberikan")
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = p.inputStream.bufferedReader().readText().trim()
            val err = p.errorStream.bufferedReader().readText().trim()
            val code = p.waitFor()
            val failed = code != 0 || out.startsWith("Error") || out.contains("Exception") ||
                out.contains("Unknown command")
            ShellResult(!failed, out, err)
        } catch (e: Throwable) {
            ShellResult(false, "", e.message ?: e.javaClass.simpleName)
        }
    }
}

data class FpsResult(val fps: Int?, val note: String)

/** Perintah shell yang dipakai AISZ. Semua argumen divalidasi sebelum masuk ke shell. */
object ShellTools {
    private val SAFE = Regex("[A-Za-z0-9._/]+")

    private fun safe(s: String): Boolean = SAFE.matches(s)

    fun setBatterySaver(on: Boolean): ShellResult =
        ShizukuHelper.exec("settings put global low_power ${if (on) 1 else 0}")

    /** mode: standard | performance | battery (Game Mode bawaan Android 12+). */
    fun setGameMode(pkg: String, mode: String): ShellResult {
        if (!safe(pkg) || mode !in listOf("standard", "performance", "battery")) {
            return ShellResult(false, "", "Argumen tidak valid")
        }
        return ShizukuHelper.exec("cmd game mode $mode $pkg")
    }

    fun lockRefreshRate(hz: Float): ShellResult {
        val v = String.format(Locale.US, "%.1f", hz)
        return ShizukuHelper.exec(
            "settings put system min_refresh_rate $v; settings put system peak_refresh_rate $v"
        )
    }

    fun unlockRefreshRate(): ShellResult = ShizukuHelper.exec(
        "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
    )

    fun setBrightness(value0to255: Int): ShellResult = ShizukuHelper.exec(
        "settings put system screen_brightness_mode 0; " +
            "settings put system screen_brightness ${value0to255.coerceIn(1, 255)}"
    )

    /** Paket aplikasi yang sedang di layar depan (dua cara, yang kedua sebagai cadangan). */
    fun foregroundPackage(): String? {
        val re = Regex("u\\d+\\s+([A-Za-z0-9._]+)/")
        val a = ShizukuHelper.exec(
            "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 2"
        ).output
        re.find(a)?.groupValues?.get(1)?.let { return it }
        val b = ShizukuHelper.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -n 3").output
        return re.find(b)?.groupValues?.get(1)
    }

    private val layerCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    /**
     * FPS game dari SurfaceFlinger. Penting: `--list` menampilkan nama layer dengan akhiran "#id",
     * sedangkan `--latency` membandingkan nama TANPA akhiran itu, jadi kedua bentuk dicoba.
     * Selalu mengembalikan alasan bila angka tidak tersedia.
     */
    fun measureFps(pkg: String): FpsResult {
        if (!safe(pkg)) return FpsResult(null, "nama paket tidak valid")
        val cached = layerCache[pkg]
        if (cached != null) {
            val f = latencyFps(cached)
            if (f != null) return FpsResult(f, "ok")
            layerCache.remove(pkg)
        }
        val listed = ShizukuHelper.exec("dumpsys SurfaceFlinger --list")
        val layers = listed.output.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (layers.isEmpty()) return FpsResult(null, "daftar layer kosong ${listed.error.take(40)}".trim())
        val candidates = layers
            .filter {
                it.contains(pkg) && !it.startsWith("Background") && !it.startsWith("Bounds") &&
                    !it.startsWith("Dim")
            }
            .sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        if (candidates.isEmpty()) return FpsResult(null, "layer game belum ada (${layers.size} layer)")
        var best: Int? = null
        var bestName: String? = null
        for (layer in candidates.take(4)) {
            val variants = listOf(layer.replace(Regex("#\\d+$"), ""), layer).distinct()
            for (name in variants) {
                val f = latencyFps(name)
                val cur = best
                if (f != null && (cur == null || f > cur)) {
                    best = f
                    bestName = name
                }
                if (f != null) break
            }
        }
        val result = best
        val name = bestName
        if (result == null || name == null) return FpsResult(null, "data frame kosong (${candidates.size} layer)")
        layerCache[pkg] = name
        return FpsResult(result, "ok")
    }

    private fun latencyFps(name: String): Int? {
        if (name.contains("'")) return null
        val lines = ShizukuHelper.exec("dumpsys SurfaceFlinger --latency '$name'").output.lines()
        val times = lines.drop(1).mapNotNull { l ->
            val parts = l.trim().split(Regex("\\s+"))
            val t = parts.getOrNull(1)?.toLongOrNull()
            if (t == null || t <= 0L || t == Long.MAX_VALUE) null else t
        }.takeLast(90)
        if (times.size < 5) return null
        val span = times.last() - times.first()
        if (span <= 0L) return null
        return ((times.size - 1) * 1_000_000_000.0 / span).toInt().coerceIn(0, 240)
    }

    /**
     * Membuka aplikasi dalam jendela mengambang (freeform). Bentuk jendela (sudut persegi/bulat)
     * dan latar belakang ditentukan sistem, bukan aplikasi ini.
     */
    fun launchFreeform(context: Context, pkg: String): ShellResult {
        val comp = context.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            ?: return ShellResult(false, "", "Aplikasi tidak punya launcher")
        if (!safe(pkg) || !safe(comp.replace("$", ""))) return ShellResult(false, "", "Argumen tidak valid")
        val first = ShizukuHelper.exec("am start --windowingMode 5 -n '$comp'")
        if (first.ok) return first
        // Hanya bila gagal: aktifkan dukungan freeform lalu coba lagi.
        ShizukuHelper.exec(
            "settings put global enable_freeform_support 1; settings put global force_resizable_activities 1"
        )
        return ShizukuHelper.exec("am start --windowingMode 5 -n '$comp'")
    }

    /** Mengembalikan pengaturan freeform sistem ke bawaan (untuk masalah layar hitam). */
    fun resetFreeform(): ShellResult = ShizukuHelper.exec(
        "settings delete global enable_freeform_support; " +
            "settings delete global force_resizable_activities; " +
            "settings delete global freeform_window_management"
    )

    fun forceStop(pkg: String): ShellResult {
        if (!safe(pkg)) return ShellResult(false, "", "Argumen tidak valid")
        return ShizukuHelper.exec("am force-stop $pkg")
    }

    /** Mengembalikan aplikasi ke layar penuh (windowing mode 1). */
    fun bringFullscreen(context: Context, pkg: String): ShellResult {
        val comp = context.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            ?: return ShellResult(false, "", "Aplikasi tidak punya launcher")
        if (!safe(pkg) || !safe(comp.replace("$", ""))) return ShellResult(false, "", "Argumen tidak valid")
        return ShizukuHelper.exec("am start --windowingMode 1 -n '$comp'")
    }

    fun maxRefreshRate(context: Context): Float {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val d = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY) ?: return 60f
        return d.supportedModes.maxOfOrNull { it.refreshRate } ?: d.refreshRate
    }
}

/** Menerapkan mode Hemat daya / Seimbang / Performa. */
object ModeController {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun applyAsync(context: Context, p: GamingProfile, gamePkg: String?, onDone: ((String) -> Unit)? = null) {
        val app = context.applicationContext
        executor.execute {
            val msg = applyBlocking(app, p, gamePkg)
            if (onDone != null) main.post { onDone(msg) }
        }
    }

    fun applyBlocking(ctx: Context, p: GamingProfile, gamePkg: String?): String {
        val r = GameSettings(ctx).applyProfile(p)
        val parts = mutableListOf("Mode ${p.label}")
        if (!r.brightnessApplied) parts += "kecerahan tidak diubah (izin belum ada)"
        if (ShizukuHelper.hasPermission()) {
            val saver = ShellTools.setBatterySaver(p == GamingProfile.HEMAT)
            parts += if (saver.ok) {
                "Penghemat Baterai ${if (p == GamingProfile.HEMAT) "aktif" else "mati"}"
            } else {
                "Penghemat Baterai gagal"
            }
            if (gamePkg != null) {
                val gm = ShellTools.setGameMode(gamePkg, p.gameMode)
                parts += if (gm.ok) "Game Mode ${p.gameMode}" else "Game Mode gagal (game/ROM tidak mendukung)"
            }
        } else {
            parts += "fitur sistem butuh Shizuku"
        }
        return parts.joinToString(", ")
    }
}
