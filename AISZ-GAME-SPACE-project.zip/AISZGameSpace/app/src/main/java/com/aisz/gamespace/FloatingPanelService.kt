package com.aisz.gamespace

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Ikon sederhana digambar dengan kanvas (tanpa file gambar, tanpa risiko resource). */
enum class Glyph { BOLT, TRASH, SHOT, REC, DND, GEAR, TIMER, FRAME, CLOSE }

class IconView(context: Context, private val glyph: Glyph) : View(context) {
    var tint: Int = Color.parseColor("#00B7FF")
        set(value) {
            field = value
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        c.scale(s / 24f, s / 24f)
        p.color = tint
        p.strokeWidth = 1.9f
        path.reset()
        when (glyph) {
            Glyph.BOLT -> {
                path.moveTo(13f, 2f); path.lineTo(5f, 13f); path.lineTo(11f, 13f)
                path.lineTo(10f, 22f); path.lineTo(19f, 10f); path.lineTo(13f, 10f); path.close()
                c.drawPath(path, p)
            }
            Glyph.TRASH -> {
                c.drawLine(4f, 6f, 20f, 6f, p)
                path.moveTo(9f, 6f); path.lineTo(9f, 3.5f); path.lineTo(15f, 3.5f); path.lineTo(15f, 6f)
                c.drawPath(path, p)
                path.reset()
                path.moveTo(6f, 6f); path.lineTo(7f, 20f); path.lineTo(17f, 20f); path.lineTo(18f, 6f)
                c.drawPath(path, p)
                c.drawLine(10f, 10f, 10f, 17f, p)
                c.drawLine(14f, 10f, 14f, 17f, p)
            }
            Glyph.SHOT -> {
                path.moveTo(4f, 9f); path.lineTo(4f, 4f); path.lineTo(9f, 4f)
                path.moveTo(15f, 4f); path.lineTo(20f, 4f); path.lineTo(20f, 9f)
                path.moveTo(20f, 15f); path.lineTo(20f, 20f); path.lineTo(15f, 20f)
                path.moveTo(9f, 20f); path.lineTo(4f, 20f); path.lineTo(4f, 15f)
                c.drawPath(path, p)
                c.drawCircle(12f, 12f, 3f, p)
            }
            Glyph.REC -> {
                c.drawRoundRect(RectF(3f, 6f, 15f, 18f), 2f, 2f, p)
                path.moveTo(15f, 10f); path.lineTo(21f, 7f); path.lineTo(21f, 17f); path.lineTo(15f, 14f)
                c.drawPath(path, p)
            }
            Glyph.DND -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawLine(7f, 12f, 17f, 12f, p)
            }
            Glyph.GEAR -> {
                c.drawCircle(12f, 12f, 3.5f, p)
                c.drawCircle(12f, 12f, 7f, p)
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4.0
                    c.drawLine(
                        12f + 7f * cos(a).toFloat(), 12f + 7f * sin(a).toFloat(),
                        12f + 9.8f * cos(a).toFloat(), 12f + 9.8f * sin(a).toFloat(), p
                    )
                }
            }
            Glyph.TIMER -> {
                c.drawLine(6f, 3f, 18f, 3f, p)
                c.drawLine(6f, 21f, 18f, 21f, p)
                path.moveTo(7f, 3f); path.lineTo(7f, 7f); path.lineTo(12f, 12f); path.lineTo(17f, 7f); path.lineTo(17f, 3f)
                path.moveTo(7f, 21f); path.lineTo(7f, 17f); path.lineTo(12f, 12f); path.lineTo(17f, 17f); path.lineTo(17f, 21f)
                c.drawPath(path, p)
            }
            Glyph.FRAME -> {
                c.drawArc(RectF(3f, 5f, 21f, 23f), 180f, 180f, false, p)
                c.drawLine(12f, 14f, 17f, 9f, p)
                c.drawCircle(12f, 14f, 1.2f, p)
            }
            Glyph.CLOSE -> {
                c.drawLine(6f, 6f, 18f, 18f, p)
                c.drawLine(18f, 6f, 6f, 18f, p)
            }
        }
        c.restore()
    }
}

/** Latar persegi dengan sudut terpotong (gaya HUD). */
class CutDrawable(
    fill: Int,
    stroke: Int,
    private val cut: Float,
    private val strokePx: Float,
    private val tl: Boolean = false,
    private val tr: Boolean = false,
    private val br: Boolean = false,
    private val bl: Boolean = false
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = fill
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokePx
        color = stroke
        strokeJoin = Paint.Join.MITER
    }
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val h = strokePx / 2f
        val l = bounds.left + h
        val t = bounds.top + h
        val r = bounds.right - h
        val b = bounds.bottom - h
        val c = cut
        path.reset()
        if (tl) { path.moveTo(l, t + c); path.lineTo(l + c, t) } else path.moveTo(l, t)
        if (tr) { path.lineTo(r - c, t); path.lineTo(r, t + c) } else path.lineTo(r, t)
        if (br) { path.lineTo(r, b - c); path.lineTo(r - c, b) } else path.lineTo(r, b)
        if (bl) { path.lineTo(l + c, b); path.lineTo(l, b - c) } else path.lineTo(l, b)
        path.close()
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, strokePaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        strokePaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Grafik garis kecil untuk riwayat nilai. */
class MiniGraph(context: Context) : View(context) {
    private var values: List<Float> = emptyList()
    private var color: Int = Color.parseColor("#00B7FF")
    private var ceiling = 60f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2.2f * resources.displayMetrics.density
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply {
        color = Color.parseColor("#22FFFFFF")
        strokeWidth = 1f
    }

    fun setValues(v: List<Float>, c: Int, minCeiling: Float) {
        values = v
        color = c
        ceiling = minCeiling
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawLine(0f, h * 0.5f, w, h * 0.5f, grid)
        canvas.drawLine(0f, h - 1f, w, h - 1f, grid)
        if (values.size < 2) return
        val top = max(ceiling, values.max())
        val step = w / (values.size - 1)
        val lp = Path()
        val fp = Path()
        values.forEachIndexed { i, v ->
            val x = i * step
            val y = h - (v / top).coerceIn(0f, 1f) * h * 0.92f
            if (i == 0) {
                lp.moveTo(x, y)
                fp.moveTo(x, h)
                fp.lineTo(x, y)
            } else {
                lp.lineTo(x, y)
                fp.lineTo(x, y)
            }
        }
        fp.lineTo(w, h)
        fp.close()
        fill.shader = LinearGradient(
            0f, 0f, 0f, h,
            Color.argb(110, Color.red(color), Color.green(color), Color.blue(color)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        line.color = color
        canvas.drawPath(fp, fill)
        canvas.drawPath(lp, line)
    }
}

/**
 * Panel gaming melayang bergaya HUD. Garis putih tipis di tepi layar = pegangan (ketuk buka/tutup,
 * seret untuk memindahkan). Panel berjarak dari tepi layar; ketuk area luar panel untuk menutup.
 */
class FloatingPanelService : Service() {

    private class Tile(val view: LinearLayout, val title: TextView, val sub: TextView?, val icon: IconView)

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var scrimParams: WindowManager.LayoutParams
    private var scrim: View? = null
    private var scrimActive = false
    private var root: LinearLayout? = null
    private lateinit var handle: FrameLayout
    private lateinit var handleBar: View
    private lateinit var panel: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var tvModeTag: TextView
    private lateinit var tvNet: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvFpsBefore: TextView
    private lateinit var tvFpsNote: TextView
    private lateinit var graph: MiniGraph
    private lateinit var seekBright: SeekBar
    private lateinit var tvFooter: TextView
    private lateinit var tileClean: Tile
    private lateinit var tileSpace: Tile
    private lateinit var tileShot: Tile
    private lateinit var tileRec: Tile
    private lateinit var tileDnd: Tile
    private lateinit var tileSettings: Tile
    private lateinit var tileFrame: Tile
    private lateinit var tileTimer: Tile
    private val modeButtons = mutableMapOf<GamingProfile, TextView>()

    private var expanded = false
    private var dockRight = false
    private var tickCount = 0
    private var lastInteraction = 0L
    private val fpsHistory = ArrayList<Float>()
    private var fpsBefore: Int? = null
    @Volatile private var gamePkg: String? = null
    @Volatile private var lastFloating: String? = null
    @Volatile private var gameBeforeFloat: String? = null
    private var homePkg: String? = null
    private var warnedBrightness = false
    private var timerMinutes = 0
    private var timerEndAt = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val slowExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, if (expanded) 2000L else 5000L)
        }
    }
    private val timerDone = Runnable { onTimerDone() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin tampil di atas aplikasi lain belum diberikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) buildOverlay()
        isRunning = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val r = root ?: return
        r.post {
            params.y = (GameSettings(this).panelYFraction * screenSize().second).toInt()
            if (expanded) limitPanelHeight()
            stickToEdge()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        slowExecutor.shutdownNow()
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        scrim?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        scrim = null
        isRunning = false
        super.onDestroy()
    }

    // ------------------------------------------------------------ notifikasi

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val m = getSystemService(NotificationManager::class.java)
            m.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Panel gaming", NotificationManager.IMPORTANCE_LOW))
            m.createNotificationChannel(NotificationChannel(TIMER_CHANNEL, "Timer bermain", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("AISZ GAME SPACE")
            .setContentText("Panel gaming aktif")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(0, "Tutup panel", stop)
            .build()
    }

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ helper

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return b.width() to b.height()
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun circle(fill: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun edgeRadii(r: Float): FloatArray =
        if (dockRight) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)

    private fun cutBg(
        fill: Int, stroke: Int, cutDp: Int,
        tl: Boolean = false, tr: Boolean = false, br: Boolean = true, bl: Boolean = false
    ): CutDrawable = CutDrawable(fill, stroke, dp(cutDp).toFloat(), dp(1).toFloat(), tl, tr, br, bl)

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun margins(v: Int) = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        setMargins(dp(v), dp(v), dp(v), dp(v))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun View.pressable(onClick: () -> Unit) {
        setOnClickListener {
            lastInteraction = SystemClock.elapsedRealtime()
            onClick()
        }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }
            false
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    /** Baris dengan anak berukuran sama: lebar dibagi rata, tinggi tetap, jarak 8dp. */
    private fun rowOf(heightPx: Int, vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach {
                addView(it, lp(0, heightPx, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
        }

    private fun smallButton(label: String, onClick: () -> Unit): TextView =
        text(label, 12f, TEXT).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            background = cutBg(CARD, STROKE, 6)
            pressable(onClick)
        }

    /** Ubin vertikal: ikon di atas, judul di bawah. */
    private fun verticalTile(glyph: Glyph, title: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph).apply { tint = DIM }
        val t = text(title, 10.5f, TEXT).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = cutBg(CARD, STROKE, 7)
            addView(icon, lp(dp(24), dp(24)))
            addView(t, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
            pressable(onClick)
        }
        return Tile(box, t, null, icon)
    }

    /** Ubin horizontal: ikon di kiri, judul + keterangan satu baris. */
    private fun horizontalTile(glyph: Glyph, title: String, sub: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph).apply { tint = DIM }
        val t = text(title, 12f, TEXT, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val s = text(sub, 10f, DIM).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(t)
            addView(s)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(10), 0)
            background = cutBg(CARD, STROKE, 7)
            addView(icon, lp(dp(24), dp(24)).apply { rightMargin = dp(10) })
            addView(col, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            pressable(onClick)
        }
        return Tile(box, t, s, icon)
    }

    private fun setTileActive(t: Tile, active: Boolean, color: Int = NEON) {
        t.view.background = cutBg(if (active) CARD_ON else CARD, if (active) color else STROKE, 7)
        t.icon.tint = if (active) color else DIM
    }

    // ------------------------------------------------------------ susunan panel

    private fun buildStatsCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = cutBg(CARD, STROKE, 8, tr = true, br = false)
        }
        tvNet = text("WLAN", 10f, DIM).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        tvPing = text("-- ms", 10.5f, TEXT, true).apply { setPadding(dp(6), 0, 0, 0) }
        tvTemp = text("-- °C", 10.5f, TEXT, true).apply { setPadding(dp(6), 0, 0, 0) }
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(tvNet, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(tvPing)
            addView(tvTemp)
        })

        graph = MiniGraph(this)
        tvFpsNote = text("", 9.5f, DIM).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val frame = FrameLayout(this).apply {
            addView(graph, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(tvFpsNote, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            ))
        }
        card.addView(frame, lp(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(4)
            bottomMargin = dp(4)
        })

        tvFps = text("-- FPS", 17f, DIM, true)
        tvFpsBefore = text("-- FPS", 17f, DIM, true)
        fun stat(valueView: TextView, caption: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(valueView)
            addView(text(caption, 9.5f, DIM))
        }
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(stat(tvFps, "Sekarang"), lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(stat(tvFpsBefore, "Sebelum mode"), lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        })
        return card
    }

    private fun buildModeRow(): LinearLayout {
        val pills = GamingProfile.values().map { p ->
            val b = text(p.label, 12f, DIM).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                pressable { selectMode(p) }
            }
            modeButtons[p] = b
            b
        }
        return rowOf(dp(38), *pills.toTypedArray())
    }

    private fun buildBrightness(): LinearLayout {
        seekBright = SeekBar(this).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(NEON)
            thumbTintList = ColorStateList.valueOf(NEON)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#26334D"))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        lastInteraction = SystemClock.elapsedRealtime()
                        applyBrightness(progress.coerceAtLeast(1))
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            background = cutBg(CARD, STROKE, 7)
            addView(text("Cerah", 11f, DIM))
            addView(seekBright, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    private fun buildPanel(): LinearLayout {
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        // Judul + tag mode
        tvModeTag = text("Seimbang", 11f, NEON, true).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = cutBg(Color.argb(40, 0, 183, 255), NEON, 5, tl = true, br = true)
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(text("AISZ GAME SPACE", 15f, NEON, true).apply { letterSpacing = 0.08f }, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(tvModeTag)
        }, margins(4))

        // Baris atas: dua ubin kecil + kartu grafik FPS (tinggi sama)
        tileClean = verticalTile(Glyph.BOLT, "Bersihkan memori") { cleanMemory() }
        tileSpace = verticalTile(Glyph.TRASH, "Bebaskan ruang") { freeSpace() }
        val leftCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tileClean.view, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)).apply { bottomMargin = dp(4) })
            addView(tileSpace.view, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)).apply { topMargin = dp(4) })
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(leftCol, lp(dp(84), dp(124)))
            addView(buildStatsCard(), lp(0, dp(124), 1f).apply { leftMargin = dp(8) })
        }, margins(4))

        content.addView(buildModeRow())

        tileShot = verticalTile(Glyph.SHOT, "Screenshot") { takeScreenshot() }
        tileRec = verticalTile(Glyph.REC, "Rekam") { toggleRecord() }
        tileDnd = verticalTile(Glyph.DND, "Jangan ganggu") { toggleDnd() }
        tileSettings = verticalTile(Glyph.GEAR, "Setelan") { openApp() }
        content.addView(rowOf(dp(68), tileShot.view, tileRec.view, tileDnd.view, tileSettings.view))

        tileFrame = horizontalTile(Glyph.FRAME, "Frame tinggi", "Normal") { toggleFrameLock() }
        tileTimer = horizontalTile(Glyph.TIMER, "Timer", "Mati") { toggleTimer() }
        content.addView(rowOf(dp(54), tileFrame.view, tileTimer.view))

        content.addView(buildBrightness(), lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        })
        content.addView(rowOf(
            dp(40),
            smallButton("Vol -") { adjustVolume(AudioManager.ADJUST_LOWER) },
            smallButton("Vol +") { adjustVolume(AudioManager.ADJUST_RAISE) },
            smallButton("Senyap") { adjustVolume(AudioManager.ADJUST_TOGGLE_MUTE) }
        ))

        tvFooter = text("Shizuku: -", 10f, DIM).apply {
            setPadding(dp(6), dp(4), 0, 0)
            pressable { openApp() }
        }
        content.addView(tvFooter)

        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
            setOnTouchListener { _, _ ->
                lastInteraction = SystemClock.elapsedRealtime()
                false
            }
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            addView(dock, lp(dp(46), LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(12) })
            addView(scroll, lp(mainWidth(), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun mainWidth(): Int = max(dp(250), min(dp(320), screenSize().first - dp(46 + 12 + 28 + 20 + 40)))

    private fun stylePanel() {
        panel.background = if (dockRight) {
            cutBg(PANEL_BG, NEON, 12, tl = true, br = true, tr = false)
        } else {
            cutBg(PANEL_BG, NEON, 12, tr = true, bl = true, br = false)
        }
    }

    /** Pegangan putih tipis yang menempel di tepi layar. */
    private fun styleHandle() {
        handleBar.background = GradientDrawable().apply {
            setColor(WHITE)
            cornerRadii = edgeRadii(dp(3).toFloat())
        }
        val lpBar = handleBar.layoutParams as FrameLayout.LayoutParams
        lpBar.gravity = (if (dockRight) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        handleBar.layoutParams = lpBar
    }

    private fun rebuildDock() {
        dock.removeAllViews()
        GameSettings(this).dockApps.take(4).forEach { pkg ->
            val icon = try {
                packageManager.getApplicationIcon(pkg)
            } catch (e: Exception) {
                null
            } ?: return@forEach
            val iv = ImageView(this).apply {
                setImageDrawable(icon)
                background = circle(CARD, STROKE)
                setPadding(dp(5), dp(5), dp(5), dp(5))
                outlineProvider = ViewOutlineProvider.BACKGROUND
                clipToOutline = true
                pressable { openFloating(pkg) }
            }
            dock.addView(iv, lp(dp(42), dp(42)).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
        val plus = text("+", 20f, NEON, true).apply {
            gravity = Gravity.CENTER
            background = circle(CARD, STROKE)
            pressable { openApp() }
        }
        dock.addView(plus, lp(dp(42), dp(42)).apply { setMargins(0, dp(4), 0, dp(4)) })
        if (lastFloating != null) {
            val x = FrameLayout(this).apply {
                background = circle(Color.argb(60, 255, 77, 94), HOT)
                addView(IconView(this@FloatingPanelService, Glyph.CLOSE).apply { tint = HOT },
                    FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
                pressable { recoverScreen() }
            }
            dock.addView(x, lp(dp(42), dp(42)).apply { setMargins(0, dp(10), 0, dp(4)) })
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun WindowManager.LayoutParams.useFullScreenArea() {
        // Tanpa ini Android menggeser overlay menjauhi lubang kamera sehingga pegangan tidak menempel di tepi.
        if (Build.VERSION.SDK_INT >= 30) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addScrim() {
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN && expanded) toggle()
            true
        }
        scrim = v
        scrimParams = WindowManager.LayoutParams(
            1, 1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }
        wm.addView(v, scrimParams)
    }

    private fun setScrim(active: Boolean) {
        val v = scrim ?: return
        scrimActive = active
        val size = if (active) WindowManager.LayoutParams.MATCH_PARENT else 1
        scrimParams.width = size
        scrimParams.height = size
        scrimParams.flags = if (active) {
            scrimParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            scrimParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, scrimParams)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildOverlay() {
        homePkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName

        val gs = GameSettings(this)
        dockRight = gs.panelRight

        handleBar = View(this)
        handle = FrameLayout(this).apply {
            addView(handleBar, FrameLayout.LayoutParams(dp(5), dp(72), Gravity.START or Gravity.CENTER_VERTICAL))
            setOnTouchListener(dragListener)
        }
        panel = buildPanel()
        panel.visibility = View.GONE

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root = container
        arrangeChildren()

        addScrim() // lebih dulu agar berada di bawah panel

        val (_, sh) = screenSize()
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (gs.panelYFraction * sh).toInt()
            useFullScreenArea()
        }
        wm.addView(container, params)
        container.post { stickToEdge() }
        syncModeButtons()
    }

    private fun arrangeChildren() {
        val r = root ?: return
        r.removeAllViews()
        val handleLp = lp(dp(22), dp(96))
        val panelLp = lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        if (dockRight) {
            r.addView(panel, panelLp)
            r.addView(handle, handleLp)
        } else {
            r.addView(handle, handleLp)
            r.addView(panel, panelLp)
        }
        styleHandle()
        stylePanel()
    }

    private fun updateLayout() {
        val r = root ?: return
        val (sw, sh) = screenSize()
        val m = dp(12)
        params.x = params.x.coerceIn(0, max(0, sw - r.width))
        params.y = params.y.coerceIn(m, max(m, sh - r.height - m))
        try {
            wm.updateViewLayout(r, params)
        } catch (_: Exception) {
        }
    }

    private fun stickToEdge() {
        val r = root ?: return
        params.x = if (dockRight) screenSize().first - r.width else 0
        updateLayout()
    }

    private fun limitPanelHeight() {
        val w = mainWidth()
        content.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val limit = screenSize().second - dp(80)
        val lpScroll = scroll.layoutParams
        lpScroll.width = w
        lpScroll.height = min(content.measuredHeight, limit)
        scroll.layoutParams = lpScroll
    }

    private fun slideOffset(): Float = if (dockRight) dp(24).toFloat() else -dp(24).toFloat()

    private fun toggle() {
        expanded = !expanded
        lastInteraction = SystemClock.elapsedRealtime()
        if (expanded) {
            rebuildDock()
            syncModeButtons()
            syncTiles()
            seekBright.progress = GameSettings(this).getBrightnessPercent()
            warnedBrightness = false
            tickCount = 0
            limitPanelHeight()
            panel.visibility = View.VISIBLE
            panel.alpha = 0f
            panel.translationX = slideOffset()
            panel.animate().alpha(1f).translationX(0f).setDuration(170).start()
            setScrim(true)
            tick()
        } else {
            setScrim(false)
            panel.animate().alpha(0f).translationX(slideOffset()).setDuration(130).withEndAction {
                panel.visibility = View.GONE
                root?.post { stickToEdge() }
            }.start()
        }
        root?.post { stickToEdge() }
    }

    private val dragListener = object : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop by lazy { ViewConfiguration.get(this@FloatingPanelService).scaledTouchSlop }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        updateLayout()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        val r = root
                        if (r != null) {
                            val (sw, sh) = screenSize()
                            val right = params.x + r.width / 2 > sw / 2
                            if (right != dockRight) {
                                dockRight = right
                                arrangeChildren()
                            }
                            r.post {
                                stickToEdge()
                                val gs = GameSettings(this@FloatingPanelService)
                                gs.panelRight = dockRight
                                gs.panelYFraction = params.y.toFloat() / sh
                            }
                        }
                    } else {
                        v.performClick()
                        toggle()
                    }
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------ data berkala

    private fun levelColor(level: TempLevel): Int = when (level) {
        TempLevel.NORMAL -> OK
        TempLevel.WARM -> WARN
        TempLevel.HIGH -> HOT
        TempLevel.UNKNOWN -> DIM
    }

    private fun fpsColor(fps: Int?): Int = when {
        fps == null -> DIM
        fps >= 50 -> NEON
        fps >= 30 -> WARN
        else -> HOT
    }

    private fun setFpsText(view: TextView, fps: Int?) {
        val s = if (fps == null) "-- FPS" else "$fps FPS"
        val sp = SpannableString(s)
        sp.setSpan(RelativeSizeSpan(0.6f), s.length - 3, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        view.text = sp
        view.setTextColor(fpsColor(fps))
    }

    private fun setPing(ms: Int?) {
        tvPing.text = if (ms == null) "-- ms" else "$ms ms"
        tvPing.setTextColor(
            when {
                ms == null -> DIM
                ms < 60 -> TEXT
                ms < 120 -> WARN
                else -> HOT
            }
        )
    }

    private fun currentAvgFps(): Int? =
        if (fpsHistory.isEmpty()) null else fpsHistory.takeLast(10).average().toInt()

    private fun tick() {
        if (root == null) return
        val now = SystemClock.elapsedRealtime()
        // Pengaman: lapisan penutup tidak boleh aktif saat panel tertutup.
        if (!expanded && scrimActive) setScrim(false)
        // Tutup otomatis bila tidak disentuh 40 detik.
        if (expanded && now - lastInteraction > 40_000L) {
            toggle()
            return
        }
        val t = TemperatureMonitor(this).read()
        tvTemp.text = if (t.batteryC == null) "N/A" else String.format("%.0f °C", t.batteryC)
        tvTemp.setTextColor(levelColor(t.level))
        syncTiles()
        if (!expanded) return
        if (!busy.compareAndSet(false, true)) return
        val detectForeground = tickCount++ % 3 == 0
        executor.execute {
            try {
                val monitor = NetworkMonitor(this)
                val net = monitor.status()
                val ping = monitor.pingMs()
                var fps: Int? = null
                var note: String
                val granted = ShizukuHelper.hasPermission()
                if (granted) {
                    if (detectForeground) {
                        val fg = ShellTools.foregroundPackage()
                        val ignore = fg == null || fg == packageName || fg == homePkg ||
                            fg.startsWith("com.android.systemui")
                        if (fg != null && fg == lastFloating) {
                            // jendela mengambang di depan: pertahankan game sebelumnya
                        } else {
                            gamePkg = if (ignore) null else fg
                        }
                    }
                    val g = gamePkg
                    if (g != null) {
                        val r = ShellTools.measureFps(g)
                        fps = r.fps
                        note = if (r.fps != null) "" else "FPS N/A: ${r.note}"
                    } else {
                        note = "Buka game untuk melihat FPS"
                    }
                } else {
                    gamePkg = null
                    note = "FPS butuh Shizuku (atur di AISZ > Atur)"
                }
                handler.post {
                    if (root != null) bindStats(net, ping, fps, granted, note)
                }
            } finally {
                busy.set(false)
            }
        }
    }

    private fun bindStats(net: NetStatus, ping: Int?, fps: Int?, shizuku: Boolean, note: String) {
        tvNet.text = when (net.transport) {
            "WLAN" -> buildString {
                append("WLAN")
                if (net.rssiDbm != null) append("  ${net.rssiDbm} dBm")
                if (net.linkMbps != null) append("  ${net.linkMbps} Mbps")
            }
            else -> net.transport
        }
        setPing(ping)
        setFpsText(tvFps, fps)
        setFpsText(tvFpsBefore, fpsBefore)
        tvFpsNote.text = note
        if (fps != null) {
            fpsHistory.add(fps.toFloat())
            if (fpsHistory.size > 30) fpsHistory.removeAt(0)
        }
        graph.setValues(fpsHistory.toList(), NEON, 60f)
        tvFooter.text = if (shizuku) {
            "Shizuku aktif" + (gamePkg?.let { "  •  $it" } ?: "")
        } else {
            "Shizuku belum aktif - ketuk untuk atur"
        }
    }

    private fun syncModeButtons() {
        val current = GameSettings(this).profile
        tvModeTag.text = current.label
        modeButtons.forEach { (p, b) ->
            val sel = p == current
            b.background = if (sel) cutBg(Color.argb(60, 0, 183, 255), NEON, 6, tl = true, br = true)
            else cutBg(CARD, STROKE, 6, tl = true, br = true)
            b.setTextColor(if (sel) NEON else DIM)
        }
    }

    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)

    private fun dndOn(): Boolean {
        val f = nm().currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL &&
            f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    private fun syncTiles() {
        if (root == null) return
        val rec = ScreenRecorderService.isRecording
        tileRec.title.text = if (rec) "Berhenti" else "Rekam"
        setTileActive(tileRec, rec, HOT)
        setTileActive(tileDnd, dndOn())
        val locked = GameSettings(this).frameLock
        tileFrame.sub?.text = if (locked) "Terkunci" else "Normal"
        setTileActive(tileFrame, locked)
        val left = if (timerEndAt > 0L) (timerEndAt - SystemClock.elapsedRealtime()) / 1000L else 0L
        tileTimer.sub?.text = if (left > 0L) String.format(Locale.US, "Sisa %d:%02d", left / 60, left % 60) else "Mati"
        setTileActive(tileTimer, left > 0L)
    }

    // ------------------------------------------------------------ aksi

    private fun openApp() {
        if (expanded) toggle()
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    private fun adjustVolume(direction: Int) {
        try {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        } catch (e: SecurityException) {
            toast("Tidak dapat mengubah volume.")
        }
    }

    private fun applyBrightness(percent: Int) {
        val gs = GameSettings(this)
        if (gs.canWriteSystemSettings()) {
            gs.setBrightnessPercent(percent)
        } else if (ShizukuHelper.hasPermission()) {
            executor.execute { ShellTools.setBrightness(percent * 255 / 100) }
        } else if (!warnedBrightness) {
            warnedBrightness = true
            toast("Kecerahan butuh izin \"Ubah pengaturan sistem\" atau Shizuku (atur di AISZ > Atur).")
        }
    }

    private fun selectMode(p: GamingProfile) {
        val gs = GameSettings(this)
        fpsBefore = currentAvgFps()
        gs.profile = p
        syncModeButtons()
        ModeController.applyAsync(this, p, gamePkg) { msg ->
            toast(msg)
            if (root != null) seekBright.progress = gs.getBrightnessPercent()
        }
    }

    private fun cleanMemory() {
        toast("Membersihkan memori...")
        executor.execute {
            val pm = PerformanceMonitor(this)
            val before = pm.memory().availMb
            if (ShizukuHelper.hasPermission()) {
                ShizukuHelper.exec("am kill-all") // hanya proses cache/latar belakang yang aman dihentikan
            } else {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val keep = setOf(packageName, homePkg, gamePkg, lastFloating)
                packageManager.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
                ).map { it.activityInfo.packageName }.distinct().filter { it !in keep }.forEach {
                    try {
                        am.killBackgroundProcesses(it)
                    } catch (_: Exception) {
                    }
                }
            }
            Thread.sleep(800)
            val after = pm.memory().availMb
            val diff = after - before
            handler.post {
                toast(if (diff > 0) "Memori bebas +$diff MB (sekarang $after MB)" else "Memori sudah bersih ($after MB bebas)")
            }
        }
    }

    private fun freeSpace() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Bebaskan ruang butuh Shizuku. Membuka pengaturan penyimpanan.")
            try {
                startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
            return
        }
        toast("Mengosongkan cache aplikasi...")
        slowExecutor.execute {
            val before = StatFs(Environment.getDataDirectory().path).availableBytes
            val r = ShizukuHelper.exec("pm trim-caches 8G")
            val after = StatFs(Environment.getDataDirectory().path).availableBytes
            val freed = (after - before) / (1024L * 1024L)
            handler.post {
                toast(if (r.ok || freed > 0) "Ruang bebas +$freed MB" else "Gagal: ${r.error.ifBlank { r.output }.take(60)}")
            }
        }
    }

    private fun takeScreenshot() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Screenshot butuh Shizuku. Pakai tombol bawaan HP.")
            return
        }
        if (expanded) toggle()
        val name = "AISZ_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        handler.postDelayed({
            slowExecutor.execute {
                val dir = "/sdcard/Pictures/AISZ"
                val r = ShizukuHelper.exec("mkdir -p $dir && screencap -p $dir/$name")
                if (r.ok) {
                    ShizukuHelper.exec("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$dir/$name")
                }
                handler.post {
                    toast(if (r.ok) "Screenshot tersimpan di Pictures/AISZ" else "Gagal screenshot: ${r.error.ifBlank { r.output }.take(60)}")
                }
            }
        }, 500L)
    }

    private fun toggleRecord() {
        if (ScreenRecorderService.isRecording) {
            startService(Intent(this, ScreenRecorderService::class.java).setAction(ScreenRecorderService.ACTION_STOP))
        } else {
            if (expanded) toggle() // sembunyikan panel agar tidak ikut terekam
            startActivity(Intent(this, RecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun toggleFrameLock() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Frame tinggi butuh Shizuku (atur di AISZ > Atur).")
            return
        }
        val gs = GameSettings(this)
        val target = !gs.frameLock
        executor.execute {
            val r = if (target) ShellTools.lockRefreshRate(ShellTools.maxRefreshRate(this)) else ShellTools.unlockRefreshRate()
            handler.post {
                if (r.ok) {
                    gs.frameLock = target
                    syncTiles()
                    toast(if (target) "Refresh rate dikunci ke maksimum" else "Refresh rate dikembalikan")
                } else {
                    toast("Gagal: ${r.error.ifBlank { r.output }}")
                }
            }
        }
    }

    private fun toggleDnd() {
        if (!nm().isNotificationPolicyAccessGranted) {
            toast("Beri izin akses Jangan Ganggu dulu.")
            try {
                startActivity(
                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
            return
        }
        nm().setInterruptionFilter(
            if (dndOn()) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        syncTiles()
    }

    /** Timer bermain: Mati -> 30 -> 60 -> 90 menit -> Mati. Berbunyi (getar + notifikasi) saat habis. */
    private fun toggleTimer() {
        val options = listOf(0, 30, 60, 90)
        val next = options[(options.indexOf(timerMinutes) + 1) % options.size]
        handler.removeCallbacks(timerDone)
        timerMinutes = next
        if (next == 0) {
            timerEndAt = 0L
            toast("Timer dimatikan")
        } else {
            timerEndAt = SystemClock.elapsedRealtime() + next * 60_000L
            handler.postDelayed(timerDone, next * 60_000L)
            toast("Timer $next menit dimulai")
        }
        syncTiles()
    }

    private fun onTimerDone() {
        timerMinutes = 0
        timerEndAt = 0L
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(700)
            }
        } catch (_: Exception) {
        }
        val n = NotificationCompat.Builder(this, TIMER_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("Waktu bermain habis")
            .setContentText("Timer AISZ GAME SPACE selesai.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            nm().notify(2001, n)
        } catch (_: Exception) {
        }
        toast("Waktu bermain habis")
        if (root != null) syncTiles()
    }

    private fun openFloating(pkg: String) {
        if (expanded) toggle()
        gameBeforeFloat = gamePkg
        executor.execute {
            if (ShizukuHelper.hasPermission()) {
                val r = ShellTools.launchFreeform(this, pkg)
                if (r.ok) {
                    lastFloating = pkg
                    return@execute
                }
                handler.post { toast("Jendela mengambang tidak didukung ROM ini, dibuka biasa.") }
            } else {
                handler.post { toast("Jendela mengambang butuh Shizuku, dibuka biasa.") }
            }
            handler.post { GameLauncher(this).launch(pkg, applyProfile = false) }
        }
    }

    /** Pemulihan: tutup aplikasi jendela mengambang terakhir dan kembalikan game ke layar penuh. */
    private fun recoverScreen() {
        val floating = lastFloating
        val game = gameBeforeFloat
        if (expanded) toggle()
        executor.execute {
            if (ShizukuHelper.hasPermission()) {
                if (floating != null) ShellTools.forceStop(floating)
                if (game != null) ShellTools.bringFullscreen(this, game)
            }
            lastFloating = null
            handler.post { toast("Layar dipulihkan") }
        }
    }

    companion object {
        const val ACTION_STOP = "com.aisz.gamespace.action.STOP_PANEL"
        private const val CHANNEL_ID = "aisz_panel"
        private const val TIMER_CHANNEL = "aisz_timer"
        private const val NOTIF_ID = 1001

        private val NEON = Color.parseColor("#00B7FF")
        private val TEXT = Color.parseColor("#E6F4FF")
        private val DIM = Color.parseColor("#8AA4BF")
        private val CARD = Color.parseColor("#0A1428")
        private val CARD_ON = Color.parseColor("#0F2A4A")
        private val STROKE = Color.parseColor("#1F4D80")
        private val PANEL_BG = Color.parseColor("#F4050A14")
        private val WHITE = Color.parseColor("#F2FFFFFF")
        private val OK = Color.parseColor("#2BE38B")
        private val WARN = Color.parseColor("#FFB020")
        private val HOT = Color.parseColor("#FF4D5E")

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingPanelService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingPanelService::class.java))
        }
    }
}
