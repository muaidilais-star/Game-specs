# AISZ GAME SPACE v1.6.0

Aplikasi Android (Kotlin + Jetpack Compose): dashboard bertema hitam-biru, panel gaming melayang,
game launcher dengan profil per game, monitor FPS/suhu/WLAN/latensi/RAM, rekam layar, Jangan Ganggu,
dan dukungan Shizuku (dimulai lewat ADB nirkabel).

- Package: `com.aisz.gamespace` - minSdk 24, target/compileSdk 35
- AGP 8.6.1, Gradle 8.7, Kotlin 1.9.24, Compose BOM 2024.06.00, JDK 17

## Build
- GitHub Actions: `.github/workflows` (APK debug sebagai artifact), atau
- Android Studio: Build > Build APK(s), atau `gradle assembleDebug`.

## Shizuku / ADB nirkabel
Fitur sistem (FPS game, Game Mode, Penghemat Baterai, kunci refresh rate, jendela mengambang)
memakai Shizuku. Mulai Shizuku lewat Debugging nirkabel (Android 11+) atau ADB dari PC, lalu
ketuk "Izinkan" di AISZ > Atur. Tanpa Shizuku fitur tersebut dinonaktifkan dengan pesan jelas.

## Catatan jujur
- Mode Hemat/Seimbang/Performa memakai Game Mode & Penghemat Baterai bawaan Android. Efeknya bergantung
  pada game dan ROM; tidak ada jaminan kenaikan FPS.
- FPS game dibaca dari SurfaceFlinger (best effort); bila tidak terbaca tampil N/A.
- Jendela mengambang memakai `am start --windowingMode 5`; hanya jalan jika ROM mendukung freeform.
- Rekam layar tanpa audio, disimpan di Movies/AISZ.

## Keamanan dan keaslian APK
Repo ini **Public**, jadi kunci tanda tangan dan passwordnya TIDAK PERNAH disimpan sebagai file di repo —
kalau disimpan di sana, siapa pun bisa memakainya untuk menandatangani ulang APK palsu dan tetap lolos
pemeriksaan keaslian. Sebagai gantinya, kunci disimpan sebagai **GitHub Secrets** (tersembunyi, hanya
terbaca saat Actions berjalan, tidak pernah tampil di log).

**Sekali saja, siapkan 4 secret di repo:** buka repo > **Settings** > **Secrets and variables** > **Actions**
> **New repository secret**, lalu tambahkan satu per satu (nama harus persis sama):
- `KEYSTORE_BASE64` — isi keystore dalam bentuk teks base64 (gw berikan terpisah di chat, jangan di-screenshot
  atau dibagikan ke tempat lain)
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

Workflow `.github/workflows/build.yml` akan mengubah `KEYSTORE_BASE64` kembali jadi file keystore saat
build, lalu memakainya untuk menandatangani APK. Tanpa keempat secret ini, build akan GAGAL dengan pesan
jelas (disengaja), supaya tanda tangan tidak pernah diam-diam berubah ke kunci lain.

- `IntegrityCheck.kt` membandingkan tanda tangan APK yang berjalan dengan `EXPECTED_SHA256` (nilai ini
  boleh diketahui publik — ini cuma hash, bukan kunci privat). Kalau APK ini diambil, diubah, lalu
  ditandatangani ulang dengan kunci lain untuk dibagikan ulang, aplikasi menampilkan peringatan layar
  penuh dan panel Game Space tidak menyala.
- Bila keystore pernah diganti (hilang/bocor), buat keystore baru, hitung ulang SHA-256 sertifikatnya,
  tempel ke `EXPECTED_SHA256` di `IntegrityCheck.kt`, lalu perbarui keempat secret di atas.
- `IntegrityCheck.watermark()` adalah kode identitas proyek ini, tampil di tab Profil > Kode proyek,
  sebagai bukti kepemilikan bila ada yang mengklaim membuat aplikasi ini.
- Batasannya: pemeriksaan ini mendeteksi APK yang sudah ditandatangani ulang, tapi tidak bisa mencegah
  seseorang yang cukup paham membongkar APK (decompile) dan menghapus kode pemeriksaannya sendiri sebelum
  menandatangani ulang. Tidak ada proteksi APK Android yang benar-benar tidak bisa ditembus; ini menaikkan
  usaha yang dibutuhkan dan membuat modifikasi kasar atau kebocoran kunci lewat repo publik tidak mungkin
  terjadi lagi.
