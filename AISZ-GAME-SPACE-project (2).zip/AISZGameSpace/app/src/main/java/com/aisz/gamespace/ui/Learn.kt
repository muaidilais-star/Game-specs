package com.aisz.gamespace.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.GamingProfile
import com.aisz.gamespace.ModeLearner
import com.aisz.gamespace.SettingChange
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun counts(ctx: Context) =
    ModeLearner.count(ctx, GamingProfile.HEMAT) to ModeLearner.count(ctx, GamingProfile.PERFORMA)

@Composable
private fun LearnRow(label: String, count: Int, onLearn: () -> Unit, onClear: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            "$label: ${if (count > 0) "$count pengaturan tersimpan" else "belum dipelajari"}",
            color = if (count > 0) AiszColors.Ok else AiszColors.TextDim, fontSize = 13.sp,
            modifier = Modifier.weight(1f)
        )
        GhostButton("Pelajari", onClick = onLearn)
        if (count > 0) {
            Spacer(Modifier.padding(start = 6.dp))
            GhostButton("Hapus", onClick = onClear)
        }
    }
}

/**
 * Mengajari AISZ cara menyalakan Hemat daya / mode kinerja BAWAAN HP: AISZ membandingkan pengaturan sistem
 * sebelum dan sesudah Anda menyalakan fiturnya sendiri, lalu memutar ulang perubahan itu saat mode dipilih.
 */
@Composable
fun ModeLearnCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cnt by remember { mutableStateOf(counts(ctx)) }
    var step by remember { mutableStateOf(0) } // 0 diam, 1 konfirmasi, 2 tunggu, 3 tinjau
    var target by remember { mutableStateOf(GamingProfile.HEMAT) }
    var base by remember { mutableStateOf<Map<String, String>?>(null) }
    var changes by remember { mutableStateOf<List<SettingChange>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var busy by remember { mutableStateOf(false) }
    val what = if (target == GamingProfile.HEMAT) "Penghemat Baterai (Hemat daya)" else "Mode kinerja / Performa"

    GlowCard {
        SectionTitle("Belajar mode dari HP")
        Text(
            "Jika Hemat daya atau Performa di AISZ belum mengubah fitur bawaan HP, ajari AISZ sekali: " +
                "AISZ mencatat pengaturan yang berubah saat Anda menyalakan fitur itu sendiri, lalu " +
                "memutarnya otomatis. Butuh Shizuku aktif.",
            color = AiszColors.TextDim, fontSize = 11.sp
        )
        Spacer(Modifier.height(8.dp))
        LearnRow("Hemat daya", cnt.first,
            onLearn = { target = GamingProfile.HEMAT; step = 1 },
            onClear = { ModeLearner.clear(ctx, GamingProfile.HEMAT); cnt = counts(ctx) })
        LearnRow("Performa", cnt.second,
            onLearn = { target = GamingProfile.PERFORMA; step = 1 },
            onClear = { ModeLearner.clear(ctx, GamingProfile.PERFORMA); cnt = counts(ctx) })
    }

    val dialogColors = Triple(AiszColors.Surface, AiszColors.Neon, AiszColors.Text)

    if (step == 1) {
        AlertDialog(
            onDismissRequest = { step = 0 },
            containerColor = dialogColors.first, titleContentColor = dialogColors.second, textContentColor = dialogColors.third,
            title = { Text("Pelajari: $what") },
            text = {
                Text(
                    if (target == GamingProfile.HEMAT) "Pastikan Penghemat Baterai di HP sedang MATI, lalu tekan Mulai."
                    else "Pastikan mode kinerja HP di posisi normal/Seimbang, lalu tekan Mulai."
                )
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        base = withContext(Dispatchers.IO) { ModeLearner.snapshot() }
                        busy = false
                        if (base == null) {
                            Toast.makeText(ctx, "Butuh Shizuku aktif.", Toast.LENGTH_LONG).show()
                            step = 0
                        } else {
                            step = 2
                        }
                    }
                }) { Text(if (busy) "Membaca..." else "Mulai", color = AiszColors.Neon) }
            },
            dismissButton = { TextButton(onClick = { step = 0 }) { Text("Batal", color = AiszColors.TextDim) } }
        )
    }

    if (step == 2) {
        AlertDialog(
            onDismissRequest = { step = 0 },
            containerColor = dialogColors.first, titleContentColor = dialogColors.second, textContentColor = dialogColors.third,
            title = { Text("Nyalakan sekarang") },
            text = {
                Text(
                    "Buka Pengaturan HP dan AKTIFKAN $what. Setelah aktif, kembali ke AISZ dan tekan Selesai."
                )
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        val before = base
                        val after = withContext(Dispatchers.IO) { ModeLearner.snapshot() }
                        busy = false
                        if (before == null || after == null) {
                            Toast.makeText(ctx, "Gagal membaca pengaturan.", Toast.LENGTH_LONG).show()
                            step = 0
                        } else {
                            val d = ModeLearner.diff(before, after)
                            changes = d
                            selected = d.filter { ModeLearner.looksRelevant(it) }.map { it.id }.toSet()
                            step = 3
                        }
                    }
                }) { Text(if (busy) "Membaca..." else "Selesai", color = AiszColors.Neon) }
            },
            dismissButton = {
                TextButton(onClick = {
                    ctx.safeStart(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                }) { Text("Buka pengaturan baterai", color = AiszColors.TextDim) }
            }
        )
    }

    if (step == 3) {
        AlertDialog(
            onDismissRequest = { step = 0 },
            containerColor = dialogColors.first, titleContentColor = dialogColors.second, textContentColor = dialogColors.third,
            title = { Text("Pengaturan yang berubah") },
            text = {
                if (changes.isEmpty()) {
                    Text("Tidak ada perubahan terdeteksi. Pastikan fiturnya benar-benar sudah dinyalakan, lalu ulangi.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(changes, key = { it.id }) { c ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    selected = if (c.id in selected) selected - c.id else selected + c.id
                                }.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = c.id in selected, onCheckedChange = null,
                                    colors = CheckboxDefaults.colors(checkedColor = AiszColors.Neon, checkmarkColor = AiszColors.Black)
                                )
                                Text(
                                    "${c.id}: ${c.oldValue ?: "-"} → ${c.newValue}",
                                    color = AiszColors.Text, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = changes.isNotEmpty(), onClick = {
                    val chosen = changes.filter { it.id in selected }
                    ModeLearner.save(ctx, target, chosen)
                    cnt = counts(ctx)
                    step = 0
                    // Kembalikan HP ke kondisi semula; mode akan dinyalakan lagi dari panel/AISZ.
                    scope.launch(Dispatchers.IO) { ModeLearner.apply(ctx, target, false) }
                    Toast.makeText(ctx, "${chosen.size} pengaturan tersimpan.", Toast.LENGTH_LONG).show()
                }) { Text("Simpan", color = AiszColors.Neon, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { step = 0 }) { Text("Batal", color = AiszColors.TextDim) } }
        )
    }
}

/** Laporan FPS terakhir yang direkam panel saat angka FPS tidak terbaca (untuk dikirim ke pembuat). */
@Composable
fun FpsDiagCard() {
    val ctx = LocalContext.current
    val gs = remember { GameSettings(ctx) }
    var text by remember { mutableStateOf(gs.fpsDiag) }
    WhileActive {
        while (true) {
            text = gs.fpsDiag
            delay(3000)
        }
    }
    GlowCard {
        SectionTitle("Diagnostik FPS")
        if (text.isBlank()) {
            Text(
                "Belum ada laporan. Buka game lewat panel melayang dan tunggu beberapa detik; bila FPS tidak " +
                    "terbaca, panel merekam laporan di sini.",
                color = AiszColors.TextDim, fontSize = 11.sp
            )
        } else {
            Text(text, color = AiszColors.TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Salin laporan") {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("AISZ diagnostik FPS", text))
                    Toast.makeText(ctx, "Laporan disalin.", Toast.LENGTH_SHORT).show()
                }
                GhostButton("Hapus") {
                    gs.fpsDiag = ""
                    text = ""
                }
            }
        }
    }
}
