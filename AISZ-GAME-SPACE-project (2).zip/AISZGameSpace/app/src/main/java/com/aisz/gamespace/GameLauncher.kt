package com.aisz.gamespace

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class GameInfo(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap?,
    val isFavorite: Boolean,
    val profile: GamingProfile? = null,
    val launches: Int = 0,
    val lastLaunch: Long = 0L
)

/**
 * Mendeteksi game terpasang (kategori GAME resmi dari Android), mengelola daftar
 * manual, favorit, profil per game, dan membuka game. Tanpa root, tanpa QUERY_ALL_PACKAGES.
 */
class GameLauncher(private val context: Context) {

    private val pm: PackageManager = context.packageManager
    private val prefs = context.getSharedPreferences("aisz_games", Context.MODE_PRIVATE)

    private class AppEntry(val pkg: String, val label: String, val info: ApplicationInfo)

    private fun readSet(key: String): MutableSet<String> =
        HashSet(prefs.getStringSet(key, emptySet()) ?: emptySet())

    private fun writeSet(key: String, value: Set<String>) {
        prefs.edit().putStringSet(key, value).apply()
    }

    private fun launchableApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                AppEntry(
                    ri.activityInfo.packageName,
                    ri.loadLabel(pm).toString(),
                    ri.activityInfo.applicationInfo
                )
            }
    }

    @Suppress("DEPRECATION")
    private fun isGame(info: ApplicationInfo): Boolean {
        val byCategory = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            info.category == ApplicationInfo.CATEGORY_GAME
        val byFlag = (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        return byCategory || byFlag
    }

    private fun iconOf(pkg: String): ImageBitmap? = try {
        pm.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap()
    } catch (e: Exception) {
        null
    }

    fun getProfile(pkg: String): GamingProfile? {
        val name = prefs.getString("profile_$pkg", null) ?: return null
        return GamingProfile.values().firstOrNull { it.name == name }
    }

    /** Siklus profil per game: tanpa profil -> Hemat -> Seimbang -> Performa -> tanpa profil. */
    fun cycleProfile(pkg: String) {
        val order: List<GamingProfile?> = listOf(null) + GamingProfile.values().toList()
        val next = order[(order.indexOf(getProfile(pkg)) + 1) % order.size]
        prefs.edit().apply {
            if (next == null) remove("profile_$pkg") else putString("profile_$pkg", next.name)
        }.apply()
    }

    /** Daftar game = (terdeteksi otomatis + ditambah manual) - dihapus pengguna. */
    fun loadGames(withIcons: Boolean = true): List<GameInfo> {
        val manual = readSet(KEY_MANUAL)
        val removed = readSet(KEY_REMOVED)
        val favorites = readSet(KEY_FAV)
        return launchableApps()
            .filter { it.pkg !in removed && (it.pkg in manual || isGame(it.info)) }
            .map {
                GameInfo(
                    packageName = it.pkg,
                    label = it.label,
                    icon = if (withIcons) iconOf(it.pkg) else null,
                    isFavorite = it.pkg in favorites,
                    profile = getProfile(it.pkg),
                    launches = prefs.getInt("launches_${it.pkg}", 0),
                    lastLaunch = prefs.getLong("last_${it.pkg}", 0L)
                )
            }
            .sortedWith(compareByDescending<GameInfo> { it.isFavorite }.thenBy { it.label.lowercase() })
    }

    /** Aplikasi ber-launcher yang belum ada di daftar game (untuk ditambah manual). */
    fun loadAddableApps(): List<GameInfo> {
        val current = loadGames(withIcons = false).map { it.packageName }.toSet()
        return launchableApps()
            .filter { it.pkg !in current }
            .map { GameInfo(it.pkg, it.label, iconOf(it.pkg), false) }
            .sortedBy { it.label.lowercase() }
    }

    /** Semua aplikasi ber-launcher (untuk memilih dock jendela mengambang). */
    fun allApps(): List<GameInfo> =
        launchableApps().map { GameInfo(it.pkg, it.label, iconOf(it.pkg), false) }
            .sortedBy { it.label.lowercase() }

    fun addGame(pkg: String) {
        writeSet(KEY_MANUAL, readSet(KEY_MANUAL).apply { add(pkg) })
        writeSet(KEY_REMOVED, readSet(KEY_REMOVED).apply { remove(pkg) })
    }

    /** Menghapus dari daftar AISZ saja; aplikasi TIDAK di-uninstall. */
    fun removeGame(pkg: String) {
        writeSet(KEY_MANUAL, readSet(KEY_MANUAL).apply { remove(pkg) })
        writeSet(KEY_REMOVED, readSet(KEY_REMOVED).apply { add(pkg) })
        writeSet(KEY_FAV, readSet(KEY_FAV).apply { remove(pkg) })
    }

    fun toggleFavorite(pkg: String) {
        val fav = readSet(KEY_FAV)
        if (!fav.add(pkg)) fav.remove(pkg)
        writeSet(KEY_FAV, fav)
    }

    /**
     * Membuka game. Jika game punya profil, profil diterapkan lebih dulu
     * (kecerahan, volume media, layar tetap menyala; sesuai izin yang ada).
     */
    fun launch(pkg: String, applyProfile: Boolean = true): Boolean {
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (applyProfile) getProfile(pkg)?.let { ModeController.applyAsync(context, it, pkg) }
            context.startActivity(intent)
            prefs.edit()
                .putInt("launches_$pkg", prefs.getInt("launches_$pkg", 0) + 1)
                .putLong("last_$pkg", System.currentTimeMillis())
                .apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    private companion object {
        const val KEY_MANUAL = "manual"
        const val KEY_REMOVED = "removed"
        const val KEY_FAV = "favorites"
    }
}
