package com.aisz.gamespace

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Merekam layar (tanpa audio) ke Movies/AISZ memakai MediaProjection resmi. */
class ScreenRecorderService : Service() {

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var vdisplay: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var legacyFile: File? = null
    private var finishing = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) startRecording(intent) else finishRecording(save = true)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (isRecording) finishRecording(save = true)
        super.onDestroy()
    }

    private fun toast(msg: String) {
        handler.post {
            if (!FloatingPanelService.announce(msg)) {
                Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Rekam layar", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ScreenRecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("AISZ GAME SPACE")
            .setContentText("Merekam layar")
            .setOngoing(true)
            .addAction(0, "Berhenti", stop)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else MediaRecorder()

    @Suppress("DEPRECATION")
    private fun readData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)

    private fun startRecording(intent: Intent) {
        if (isRecording) return
        finishing = false
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
        try {
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = readData(intent) ?: throw IllegalStateException("Data izin hilang")
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mgr.getMediaProjection(code, data)
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post { finishRecording(save = true) }
                }
            }, handler)
            projection = proj

            val dm = resources.displayMetrics
            val scale = minOf(1f, 1280f / maxOf(dm.widthPixels, dm.heightPixels))
            val w = ((dm.widthPixels * scale).toInt() / 2) * 2
            val h = ((dm.heightPixels * scale).toInt() / 2) * 2

            val rec = newRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(w, h)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(6_000_000)
            attachOutput(rec)
            rec.prepare()
            vdisplay = proj.createVirtualDisplay(
                "AISZ-Rec", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, handler
            )
            rec.start()
            recorder = rec
            isRecording = true
            toast("Mulai merekam layar")
        } catch (e: Exception) {
            toast("Gagal merekam: ${e.message}")
            cleanup(delete = true)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun attachOutput(rec: MediaRecorder) {
        val name = "AISZ_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AISZ")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("Gagal membuat file")
            uri = u
            val fd = contentResolver.openFileDescriptor(u, "w")
                ?: throw IllegalStateException("Gagal membuka file")
            pfd = fd
            rec.setOutputFile(fd.fileDescriptor)
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            dir.mkdirs()
            val f = File(dir, name)
            legacyFile = f
            rec.setOutputFile(f.absolutePath)
        }
    }

    private fun finishRecording(save: Boolean) {
        if (finishing) return
        finishing = true
        val was = isRecording
        isRecording = false
        var failed = !save
        try {
            recorder?.stop()
        } catch (e: RuntimeException) {
            failed = true // rekaman terlalu singkat / dihentikan sistem
        }
        cleanup(delete = failed)
        if (was) toast(if (failed) "Rekaman tidak tersimpan (terlalu singkat)" else "Rekaman disimpan di Movies/AISZ")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup(delete: Boolean) {
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { vdisplay?.release() } catch (_: Exception) {}
        vdisplay = null
        val p = projection
        projection = null
        try { p?.stop() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        val u = uri
        if (u != null) {
            try {
                if (delete) {
                    contentResolver.delete(u, null, null)
                } else {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(u, v, null, null)
                }
            } catch (_: Exception) {}
        }
        uri = null
        val f = legacyFile
        if (f != null && delete) f.delete()
        legacyFile = null
    }

    companion object {
        const val ACTION_START = "com.aisz.gamespace.action.REC_START"
        const val ACTION_STOP = "com.aisz.gamespace.action.REC_STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL_ID = "aisz_record"
        private const val NOTIF_ID = 1002

        @Volatile
        var isRecording: Boolean = false
            private set
    }
}
