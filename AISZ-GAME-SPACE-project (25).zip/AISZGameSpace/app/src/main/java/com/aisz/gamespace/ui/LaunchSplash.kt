package com.aisz.gamespace.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

/** Roket kecil menghadap kanan; 1 satuan = 1 dp. Titik (0,0) di tengah badan roket. */
private fun DrawScope.drawRocket(center: Offset, flame: Float) {
    translate(center.x, center.y) {
        scale(density, density, pivot = Offset.Zero) {
            val outer = Path().apply {
                moveTo(-18f, -5f)
                lineTo(-18f - 16f * flame, 0f)
                lineTo(-18f, 5f)
                close()
            }
            drawPath(outer, Color(0xFFFFA726))
            val inner = Path().apply {
                moveTo(-18f, -2.5f)
                lineTo(-18f - 9f * flame, 0f)
                lineTo(-18f, 2.5f)
                close()
            }
            drawPath(inner, Color(0xFFFFE082))
            val finTop = Path().apply {
                moveTo(-16f, -8f)
                lineTo(-26f, -17f)
                lineTo(-6f, -8f)
                close()
            }
            val finBottom = Path().apply {
                moveTo(-16f, 8f)
                lineTo(-26f, 17f)
                lineTo(-6f, 8f)
                close()
            }
            drawPath(finTop, Color(0xFF2B7FFF))
            drawPath(finBottom, Color(0xFF2B7FFF))
            drawOval(Color(0xFFECF2FA), topLeft = Offset(-20f, -9f), size = Size(40f, 18f))
            val nose = Path().apply {
                moveTo(10f, -8f)
                quadraticBezierTo(24f, -6f, 32f, 0f)
                quadraticBezierTo(24f, 6f, 10f, 8f)
                close()
            }
            drawPath(nose, Color(0xFFE5484D))
            drawCircle(Color(0xFF2B7FFF), radius = 4.2f, center = Offset(2f, 0f))
            drawCircle(Color(0xFFBFE0FF), radius = 2f, center = Offset(1f, -1f))
        }
    }
}

/**
 * Layar pembuka game: latar gelap solid berbintang, kotak di bawah berisi nama game dan bilah kemajuan,
 * dan roket yang meluncur di sepanjang bilah. Selesai otomatis lalu memanggil [onDone].
 */
@Composable
fun LaunchSplashScreen(gameName: String, icon: ImageBitmap?, onCancel: () -> Unit, onDone: () -> Unit) {
    BackHandler { onCancel() }
    val enter = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    val fx = rememberInfiniteTransition(label = "fx")
    val flame by fx.animateFloat(
        0.6f, 1.25f,
        infiniteRepeatable(tween(110, easing = LinearEasing), RepeatMode.Reverse), label = "flame"
    )
    val twinkle by fx.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "twinkle"
    )
    val stars = remember { List(40) { Triple(Random.nextFloat(), Random.nextFloat() * 0.65f, Random.nextFloat()) } }

    LaunchedEffect(Unit) {
        enter.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
        progress.animateTo(1f, tween(1700, easing = FastOutSlowInEasing))
        delay(180)
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF05070D), Color(0xFF0A1730), Color(0xFF0E2447))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            stars.forEach { (sx, sy, ph) ->
                val a = 0.25f + 0.75f * (0.5f + 0.5f * kotlin.math.sin((twinkle + ph) * 6.2832f))
                drawCircle(
                    Color.White.copy(alpha = a.coerceIn(0f, 1f)),
                    radius = (0.8f + 1.6f * ph) * density,
                    center = Offset(sx * size.width, sy * size.height)
                )
            }
        }

        val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .graphicsLayer { translationY = (1f - enter.value) * 520f }
                .clip(shape)
                .background(AiszColors.Surface)
                .border(1.dp, AiszColors.Neon.copy(alpha = 0.5f), shape)
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Image(
                        bitmap = icon,
                        contentDescription = null,
                        modifier = Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))
                    )
                    Spacer(Modifier.width(14.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("Meluncurkan", color = AiszColors.TextDim, fontSize = 12.sp)
                    Text(gameName, color = AiszColors.Text, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                Text(
                    "${(progress.value * 100).toInt()}%",
                    color = AiszColors.Neon, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(Modifier.height(10.dp))
            Canvas(Modifier.fillMaxWidth().height(66.dp)) {
                val trackY = size.height * 0.78f
                val left = 10.dp.toPx()
                val right = size.width - 10.dp.toPx()
                val x = left + (right - left) * progress.value
                val stroke = 8.dp.toPx()
                drawLine(AiszColors.SurfaceHigh, Offset(left, trackY), Offset(right, trackY), stroke, StrokeCap.Round)
                if (x > left) {
                    drawLine(
                        Brush.horizontalGradient(listOf(AiszColors.Neon, AiszColors.NeonSoft), startX = left, endX = right),
                        Offset(left, trackY), Offset(x, trackY), stroke, StrokeCap.Round
                    )
                }
                for (i in 1..5) {
                    val tx = x - 34.dp.toPx() - i * 13.dp.toPx()
                    if (tx > left) {
                        drawCircle(
                            AiszColors.NeonSoft.copy(alpha = (0.55f - i * 0.1f).coerceAtLeast(0.05f)),
                            radius = (4.2f - i * 0.6f).coerceAtLeast(1f) * density,
                            center = Offset(tx, trackY - 22.dp.toPx() + (i % 2) * 3.dp.toPx())
                        )
                    }
                }
                drawRocket(Offset(x, trackY - 22.dp.toPx()), flame)
            }
        }
    }
}
