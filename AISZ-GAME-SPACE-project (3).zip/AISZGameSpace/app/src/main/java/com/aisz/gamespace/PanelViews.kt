package com.aisz.gamespace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.hypot
import kotlin.math.max

/** Menggambar crosshair gaya 0..4 di pusat (cx, cy) dengan ukuran s. Dipakai overlay dan pratinjau. */
internal fun drawCrosshair(
    c: Canvas, style: Int, cx: Float, cy: Float, s: Float, color: Int, alpha: Int, density: Float
) {
    val sw = max(1.6f * density, s * 0.045f)
    val half = s / 2f
    val main = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = sw
        this.color = color
        this.alpha = alpha
    }
    val edge = Paint(main).apply {
        strokeWidth = sw + 2.2f * density
        this.color = Color.BLACK
        this.alpha = (alpha * 0.45f).toInt()
    }
    fun both(draw: (Paint) -> Unit) {
        draw(edge)
        draw(main)
    }
    when (style) {
        0 -> both { p ->
            c.drawLine(cx - half, cy, cx + half, cy, p)
            c.drawLine(cx, cy - half, cx, cy + half, p)
        }
        1 -> both { p ->
            p.pathEffect = DashPathEffect(floatArrayOf(sw * 2.4f, sw * 2.4f), 0f)
            c.drawLine(cx - half, cy, cx + half, cy, p)
            c.drawLine(cx, cy - half, cx, cy + half, p)
            p.pathEffect = null
        }
        2 -> both { p ->
            val gap = half * 0.3f
            c.drawLine(cx - half, cy, cx - gap, cy, p)
            c.drawLine(cx + gap, cy, cx + half, cy, p)
            c.drawLine(cx, cy - half, cx, cy - gap, p)
            c.drawLine(cx, cy + gap, cx, cy + half, p)
        }
        3 -> {
            val r = max(2f * density, s * 0.09f)
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.FILL }
            dot.color = Color.BLACK
            dot.alpha = (alpha * 0.45f).toInt()
            c.drawCircle(cx, cy, r + 1.2f * density, dot)
            dot.color = color
            dot.alpha = alpha
            c.drawCircle(cx, cy, r, dot)
        }
        else -> {
            val r = half * 0.5f
            both { p ->
                c.drawCircle(cx, cy, r, p)
                c.drawLine(cx - half, cy, cx - r * 0.55f, cy, p)
                c.drawLine(cx + r * 0.55f, cy, cx + half, cy, p)
                c.drawLine(cx, cy - half, cx, cy - r * 0.55f, p)
                c.drawLine(cx, cy + r * 0.55f, cx, cy + half, p)
            }
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.FILL }
            dot.color = color
            dot.alpha = alpha
            c.drawCircle(cx, cy, max(1.4f * density, s * 0.03f), dot)
        }
    }
}

/**
 * Crosshair: dipakai sebagai overlay di layar (ukuran = bentuk + bantalan) dan sebagai pratinjau kecil
 * (padPx = 0). Saat editing, bisa diseret dan memiliki tombol centang untuk menyimpan posisi.
 */
class CrosshairView(context: Context) : View(context) {
    var style: Int = 0
        set(v) { field = v; invalidate() }
    var color: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    var shapeAlpha: Int = 255
        set(v) { field = v; invalidate() }
    var shapeSizePx: Int = 0
        set(v) { field = v; requestLayout(); invalidate() }
    var padPx: Int = 0
        set(v) { field = v; requestLayout() }
    var editing: Boolean = false
        set(v) { field = v; invalidate() }
    var onCheck: (() -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        color = Color.argb(190, 255, 255, 255)
        pathEffect = DashPathEffect(floatArrayOf(6f * d, 4f * d), 0f)
    }
    private val chip = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E65B9BE0") }
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2.2f
        color = Color.WHITE
    }
    private val gp = Path()
    private val rect = RectF()
    private var lastX = 0f
    private var lastY = 0f
    private var checkDown = false

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val s = shapeSizePx + 2 * padPx
        setMeasuredDimension(resolveSize(s, widthSpec), resolveSize(s, heightSpec))
    }

    private fun chipCx() = width - 16f * d
    private fun chipCy() = 16f * d

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        drawCrosshair(c, style, cx, cy, shapeSizePx.toFloat(), color, shapeAlpha, d)
        if (editing) {
            val r = shapeSizePx / 2f + 8f * d
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawRoundRect(rect, 10f * d, 10f * d, border)
            c.drawCircle(chipCx(), chipCy(), 14f * d, chip)
            val gs = 16f * d
            c.save()
            c.translate(chipCx() - gs / 2f, chipCy() - gs / 2f)
            c.scale(gs / 24f, gs / 24f)
            drawGlyph(c, Glyph.CHECK, glyphPaint, gp)
            c.restore()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                checkDown = hypot(e.x - chipCx(), e.y - chipCy()) <= 20f * d
            }
            MotionEvent.ACTION_MOVE -> {
                if (!checkDown) {
                    onDrag?.invoke(e.rawX - lastX, e.rawY - lastY)
                    lastX = e.rawX
                    lastY = e.rawY
                }
            }
            MotionEvent.ACTION_UP -> {
                if (checkDown && hypot(e.x - chipCx(), e.y - chipCy()) <= 24f * d) onCheck?.invoke()
                else onDragEnd?.invoke()
                checkDown = false
            }
            MotionEvent.ACTION_CANCEL -> {
                onDragEnd?.invoke()
                checkDown = false
            }
        }
        return true
    }
}

/** Saklar hidup/mati dengan animasi halus. */
class ToggleSwitch(context: Context) : View(context) {
    var accent: Int = Color.parseColor("#5B9BE0")
        set(v) { field = v; invalidate() }
    var onToggle: ((Boolean) -> Unit)? = null
    private var checked = false
    private var pos = 0f
    private var anim: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()

    fun setCheckedSilently(c: Boolean) {
        anim?.cancel()
        checked = c
        pos = if (c) 1f else 0f
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        track.color = ColorUtils.blendARGB(Color.parseColor("#4A5260"), accent, pos)
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, track)
        val cx = r + (w - 2f * r) * pos
        c.drawCircle(cx, r, r - 3f * d, thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP &&
            e.x in 0f..width.toFloat() && e.y in 0f..height.toFloat()
        ) {
            checked = !checked
            anim?.cancel()
            anim = ValueAnimator.ofFloat(pos, if (checked) 1f else 0f).apply {
                duration = 160
                addUpdateListener {
                    pos = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
            onToggle?.invoke(checked)
        }
        return true
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}
