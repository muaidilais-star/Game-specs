package com.aisz.gamespace.ui

import android.content.ClipData
import android.content.Intent
import android.content.ClipboardManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.MainActivity
import com.aisz.gamespace.NetworkMonitor
import com.aisz.gamespace.PerformanceMonitor
import com.aisz.gamespace.IntegrityCheck
import com.aisz.gamespace.ShizukuHelper
import com.aisz.gamespace.TemperatureMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.util.Locale

private class NetInfo(val text: String, val v4: String, val v6: String, val shizuku: String)

private fun deviceName(ctx: Context): String = try {
    Settings.Global.getString(ctx.contentResolver, "device_name")?.takeIf { it.isNotBlank() } ?: Build.MODEL
} catch (_: Exception) {
    Build.MODEL
}

private fun formatUptime(): String {
    val s = SystemClock.elapsedRealtime() / 1000
    val d = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    return if (d > 0) "${d} hari ${h} jam ${m} menit" else "${h} jam ${m} menit"
}

private fun storageText(): String = try {
    val st = StatFs(Environment.getDataDirectory().path)
    val total = st.totalBytes / 1_000_000_000.0
    val free = st.availableBytes / 1_000_000_000.0
    String.format(Locale.US, "%.1f GB bebas dari %.1f GB", free, total)
} catch (_: Exception) {
    "-"
}

private fun readNet(ctx: Context, nm: NetworkMonitor): NetInfo {
    val st = nm.status()
    val txt = buildString {
        append(st.transport)
        if (st.rssiDbm != null) append("  ${st.rssiDbm} dBm")
        if (st.linkMbps != null) append("  ${st.linkMbps} Mbps")
        if (st.band != null) append("  ${st.band}")
    }
    var v4 = "-"
    var v6 = "-"
    try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val lp = cm.getLinkProperties(cm.activeNetwork)
        lp?.linkAddresses?.forEach { la ->
            val a = la.address
            if (a.isLoopbackAddress || a.isLinkLocalAddress) return@forEach
            val h = a.hostAddress?.substringBefore('%') ?: return@forEach
            if (a is Inet4Address) {
                if (v4 == "-") v4 = h
            } else if (v6 == "-") {
                v6 = h
            }
        }
    } catch (_: Exception) {
    }
    val sh = when {
        !ShizukuHelper.isInstalled(ctx) -> "Belum dipasang"
        ShizukuHelper.isRunning() && ShizukuHelper.hasPermission() -> "Aktif"
        ShizukuHelper.isRunning() -> "Berjalan, izin belum diberikan"
        else -> "Belum berjalan"
    }
    return NetInfo(txt, v4, v6, sh)
}

@Composable
private fun ProfileRow(label: String, value: String, copyable: Boolean = false) {
    val ctx = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .then(
                if (copyable && value != "-") Modifier.clickable {
                    val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cb.setPrimaryClip(ClipData.newPlainText(label, value))
                    Toast.makeText(ctx, "$label disalin", Toast.LENGTH_SHORT).show()
                } else Modifier
            )
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = AiszColors.TextDim, fontSize = 13.sp, modifier = Modifier.width(120.dp))
        Text(
            value, color = AiszColors.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End, modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun SocialLinkButton(label: String, accent: Color, url: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(accent.copy(alpha = 0.18f))
            .border(1.dp, accent.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .clickable {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (_: Exception) {
                }
            }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(label, color = AiszColors.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ProfileScreen(activity: MainActivity) {
    val ctx = LocalContext.current
    val perf = remember { PerformanceMonitor(ctx) }
    val thermalMonitor = remember { TemperatureMonitor(ctx) }
    val netMonitor = remember { NetworkMonitor(ctx) }
    val device = remember { perf.deviceInfo() }
    val name = remember { deviceName(ctx) }
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
    }
    var memory by remember { mutableStateOf(perf.memory()) }
    var battery by remember { mutableStateOf(perf.battery()) }
    var tempC by remember { mutableStateOf(thermalMonitor.read().batteryC) }
    var net by remember { mutableStateOf("...") }
    var ipv4 by remember { mutableStateOf("-") }
    var ipv6 by remember { mutableStateOf("-") }
    var shizuku by remember { mutableStateOf("...") }
    var uptime by remember { mutableStateOf(formatUptime()) }
    val storage = remember { storageText() }

    WhileActive {
        while (true) {
            memory = perf.memory()
            battery = perf.battery()
            tempC = thermalMonitor.read().batteryC
            uptime = formatUptime()
            val info = withContext(Dispatchers.IO) { readNet(ctx, netMonitor) }
            net = info.text
            ipv4 = info.v4
            ipv6 = info.v6
            shizuku = info.shizuku
            delay(3000)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        GlowCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(AiszColors.Neon, AiszColors.NeonSoft))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        name.firstOrNull()?.uppercase() ?: "A",
                        color = AiszColors.Black, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold
                    )
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = AiszColors.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("${device.manufacturer} ${device.model}", color = AiszColors.TextDim, fontSize = 13.sp, maxLines = 1)
                    Text("AISZ GAME SPACE v$version", color = AiszColors.Neon, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SocialLinkButton(
                "Saluran WhatsApp", Color(0xFF25D366),
                "https://whatsapp.com/channel/0029VbDMe9ABKfhyuBAsQT3A",
                Modifier.weight(1f)
            )
            SocialLinkButton(
                "TikTok", AiszColors.Text,
                "https://www.tiktok.com/@developer.aiszgamespesc",
                Modifier.weight(1f)
            )
        }

        GlowCard {
            SectionTitle("Jaringan")
            ProfileRow("IP perangkat", ipv4, copyable = true)
            ProfileRow("IPv6", ipv6, copyable = true)
            ProfileRow("Koneksi", net)
        }

        GlowCard {
            SectionTitle("Perangkat")
            ProfileRow("Nama", name)
            ProfileRow("Merek", device.manufacturer.replaceFirstChar { it.uppercase() })
            ProfileRow("Model", device.model)
            ProfileRow("Nama kode", Build.DEVICE)
            ProfileRow(
                "Prosesor",
                if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank()) Build.SOC_MODEL else Build.HARDWARE
            )
            ProfileRow("Core CPU", "${device.cpuCores} (${device.abi})")
            ProfileRow("Layar", device.screen)
            ProfileRow("Refresh rate", String.format(Locale.US, "%.0f Hz", device.refreshRateHz))
        }

        GlowCard {
            SectionTitle("Sistem")
            ProfileRow("Android", "${device.androidVersion} (API ${device.apiLevel})")
            ProfileRow("Versi sistem", Build.DISPLAY)
            ProfileRow("Tambalan keamanan", if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH else "-")
            ProfileRow("Kernel", System.getProperty("os.version") ?: "-")
            ProfileRow("Menyala sejak", uptime)
        }

        GlowCard {
            SectionTitle("Memori dan baterai")
            ProfileRow("RAM", "${memory.availMb} MB bebas dari ${memory.totalMb} MB")
            ProfileRow("Penyimpanan", storage)
            ProfileRow("Baterai", battery.levelPercent?.let { "$it%" + if (battery.charging) " (mengisi)" else "" } ?: "-")
            ProfileRow("Suhu baterai", tempC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "-")
        }

        GlowCard {
            SectionTitle("AISZ")
            ProfileRow("Versi aplikasi", version)
            ProfileRow("Shizuku", shizuku)
            ProfileRow("Kode proyek", IntegrityCheck.watermark())
            ProfileRow("Keaslian APK", if (IntegrityCheck.check(ctx).ok) "Asli (tanda tangan sesuai)" else "TIDAK SESUAI")
        }

        Text(
            "Ketuk IP perangkat untuk menyalin.",
            color = AiszColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}
