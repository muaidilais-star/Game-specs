package com.aisz.gamespace

import android.os.IBinder
import android.os.SystemClock
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructPollfd
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.File
import java.io.FileDescriptor
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Berjalan sebagai proses terpisah dengan identitas shell (dinyalakan lewat Shizuku, `app_process`).
 * Membaca keyboard/mouse dari /dev/input, lalu menyuntikkan sentuhan multi-jari sesuai pemetaan.
 * Tidak memakai Context; hanya kelas framework.
 */
object InputServer {
    @JvmStatic
    fun main(args: Array<String>) {
        val dir = File(if (args.isNotEmpty()) args[0] else "/sdcard")
        try {
            Server(dir).run()
        } catch (t: Throwable) {
            try {
                File(dir, "aisz_map_server.log").appendText("crash: $t\n")
            } catch (_: Throwable) {
            }
        }
        System.exit(0)
    }
}

private const val ID_JOY = 0
private const val ID_LOOK = 1
private const val ID_FIRE = 2
private const val ID_SCOPE = 3
private const val ID_KEY0 = 4
private const val BTN_LEFT = 272
private const val BTN_RIGHT = 273
private const val EVIOCGRAB = 0x40044590

private class Server(private val dir: File) {
    private val cfgFile = File(dir, "aisz_map.cfg")
    private val statusFile = File(dir, "aisz_map_status.txt")
    private val lock = Any()
    @Volatile private var cfg = MapConfig()
    private var cfgMtime = -1L
    @Volatile private var active = false
    @Volatile private var alive = true
    @Volatile private var lastKey = 0
    @Volatile private var lastKeyAt = 0L
    private val devices = HashMap<String, DeviceReader>()
    @Volatile private var rawSeen = ""
    @Volatile private var procError = ""
    private val dx = AtomicInteger(0)
    private val dy = AtomicInteger(0)
    private var jU = false
    private var jL = false
    private var jD = false
    private var jR = false
    private var lookX = 0f
    private var lookY = 0f
    private var lastLookAt = 0L
    private var winStart = 0L
    private var winCount = 0
    @Volatile private var limited = false
    @Volatile private var injectError = ""

    private val ids = ArrayList<Int>()
    private val px = HashMap<Int, Float>()
    private val py = HashMap<Int, Float>()
    private var downTime = 0L
    private var inputMgr: Any? = null
    private var injectM: Method? = null

    fun run() {
        initInjector()
        reloadCfg(true)
        active = cfg.enabled
        val pump = Thread { pumpLoop() }
        pump.isDaemon = true
        pump.start()
        var tick = 0
        var prevEnabled = cfg.enabled
        while (alive) {
            reloadCfg(false)
            if (cfg.quit || !dir.exists()) break
            if (cfg.enabled != prevEnabled) {
                prevEnabled = cfg.enabled
                synchronized(lock) {
                    active = cfg.enabled
                    if (!active) releaseAll()
                }
            }
            if (tick % 30 == 0) scanDevices()
            if (tick % 5 == 0) writeStatus()
            tick++
            try {
                Thread.sleep(100)
            } catch (_: InterruptedException) {
            }
        }
        alive = false
        synchronized(lock) { releaseAll() }
        synchronized(devices) { devices.values.forEach { it.stopReader() } }
        try {
            statusFile.writeText("hb=0\n")
        } catch (_: Throwable) {
        }
    }

    // ---------------------------------------------------------------- konfigurasi

    private fun reloadCfg(force: Boolean) {
        try {
            val m = cfgFile.lastModified()
            if (force || m != cfgMtime) {
                cfgMtime = m
                cfg = MapConfig.parse(cfgFile.readText())
            }
        } catch (_: Throwable) {
        }
    }

    // ---------------------------------------------------------------- perangkat input

    private fun scanDevices() {
        val text = try {
            val t = File("/proc/bus/input/devices").readText()
            procError = ""
            t
        } catch (e: Throwable) {
            procError = "Tidak bisa membaca /proc/bus/input/devices: ${e.javaClass.simpleName} ${e.message ?: ""}".trim()
            ""
        }
        val found = HashMap<String, String>()
        val seenAll = ArrayList<String>() // diagnosa: semua perangkat kbd/mouse sebelum disaring, dipakai bila 0 lolos
        for (block in text.split("\n\n")) {
            var name = ""
            var sysfs = ""
            var handlers = ""
            for (line in block.lines()) {
                when {
                    line.startsWith("N: Name=") -> name = line.substringAfter("Name=").trim().trim('"')
                    line.startsWith("S: Sysfs=") -> sysfs = line.substringAfter("Sysfs=")
                    line.startsWith("H: Handlers=") -> handlers = line.substringAfter("Handlers=")
                }
            }
            val isKbd = handlers.contains("kbd")
            val isMouse = handlers.contains("mouse") || handlers.contains("mice")
            if (!isKbd && !isMouse) continue
            seenAll.add("$name [${handlers.trim()}]")
            // Mouse: HP tidak punya mouse bawaan sama sekali, jadi handler "mouse"/"mice" selalu berarti OTG/Bluetooth.
            // Keyboard: disaring, karena tombol volume/daya HP juga memakai handler "kbd".
            val external = isMouse || sysfs.contains("usb", true) || sysfs.contains("uhid", true) || sysfs.contains("bluetooth", true)
            if (!external) continue
            val node = Regex("event\\d+").find(handlers)?.value ?: continue
            found[node] = name
        }
        rawSeen = seenAll.joinToString("; ")
        synchronized(devices) {
            for ((node, name) in found) {
                if (node !in devices) {
                    val r = DeviceReader(node, name)
                    devices[node] = r
                    r.start()
                }
            }
            for (n in devices.keys.filter { it !in found }) devices.remove(n)?.stopReader()
        }
    }

    private fun wantGrab(): Boolean = active && cfg.enabled

    private fun tryGrab(fd: FileDescriptor): Boolean = try {
        val os = Class.forName("libcore.io.Libcore").getField("os").get(null)
        val ms = os.javaClass.methods.filter { it.name == "ioctlInt" }
        val two = ms.firstOrNull { it.parameterTypes.size == 2 }
        if (two != null) {
            // Argumen bukan nol (penunjuk) berarti "ambil alih" pada EVIOCGRAB; melepas dilakukan dengan menutup berkas.
            two.invoke(os, fd, EVIOCGRAB)
            true
        } else {
            val three = ms.firstOrNull { it.parameterTypes.size == 3 }
            if (three == null) {
                false
            } else {
                val ref = three.parameterTypes[2].getConstructor(Int::class.javaPrimitiveType).newInstance(1)
                three.invoke(os, fd, EVIOCGRAB, ref)
                true
            }
        }
    } catch (_: Throwable) {
        false
    }

    private inner class DeviceReader(val node: String, val devName: String) : Thread("in-$node") {
        @Volatile private var running = true
        @Volatile var grabbed = false

        fun stopReader() {
            running = false
        }

        override fun run() {
            val evSize = if (android.os.Process.is64Bit()) 24 else 16
            val buf = ByteArray(evSize * 32)
            var fd: FileDescriptor? = null
            try {
                while (running && alive) {
                    if (fd == null) {
                        fd = Os.open("/dev/input/$node", OsConstants.O_RDONLY or OsConstants.O_NONBLOCK, 0)
                        grabbed = false
                    }
                    val cur: FileDescriptor = fd ?: break
                    val want = wantGrab()
                    if (want && !grabbed) {
                        grabbed = tryGrab(cur)
                    } else if (!want && grabbed) {
                        try {
                            Os.close(cur)
                        } catch (_: Throwable) {
                        }
                        fd = null
                        grabbed = false
                        continue
                    }
                    val pfd = StructPollfd()
                    pfd.fd = cur
                    pfd.events = OsConstants.POLLIN.toShort()
                    if (Os.poll(arrayOf(pfd), 200) <= 0) continue
                    val r = try {
                        Os.read(cur, buf, 0, buf.size)
                    } catch (e: ErrnoException) {
                        if (e.errno == OsConstants.EAGAIN) continue
                        throw e
                    }
                    if (r <= 0) break
                    var off = 0
                    while (off + evSize <= r) {
                        val t = (buf[off + evSize - 8].toInt() and 0xFF) or ((buf[off + evSize - 7].toInt() and 0xFF) shl 8)
                        val c = (buf[off + evSize - 6].toInt() and 0xFF) or ((buf[off + evSize - 5].toInt() and 0xFF) shl 8)
                        val v = (buf[off + evSize - 4].toInt() and 0xFF) or ((buf[off + evSize - 3].toInt() and 0xFF) shl 8) or
                            ((buf[off + evSize - 2].toInt() and 0xFF) shl 16) or ((buf[off + evSize - 1].toInt() and 0xFF) shl 24)
                        handle(t, c, v)
                        off += evSize
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try {
                    fd?.let { Os.close(it) }
                } catch (_: Throwable) {
                }
                grabbed = false
                synchronized(devices) {
                    if (devices[node] === this) devices.remove(node)
                }
            }
        }
    }

    // ---------------------------------------------------------------- pemetaan

    private fun handle(type: Int, code: Int, value: Int) {
        if (type == 1) { // EV_KEY
            if (value == 2) return // tahan otomatis, abaikan
            val down = value == 1
            if (down && code < 255) {
                lastKey = code
                lastKeyAt = System.currentTimeMillis()
            }
            onKey(code, down)
        } else if (type == 2 && active) { // EV_REL
            if (code == 0) dx.addAndGet(value) else if (code == 1) dy.addAndGet(value)
        }
    }

    private fun onKey(code: Int, down: Boolean) {
        synchronized(lock) {
            val c = cfg
            if (down && code == c.toggleKey) {
                active = !active
                if (!active) releaseAll()
                return
            }
            if (!active || !c.enabled) return
            when (code) {
                c.joyUp -> {
                    jU = down
                    updateJoy()
                    return
                }
                c.joyLeft -> {
                    jL = down
                    updateJoy()
                    return
                }
                c.joyDown -> {
                    jD = down
                    updateJoy()
                    return
                }
                c.joyRight -> {
                    jR = down
                    updateJoy()
                    return
                }
                BTN_LEFT -> {
                    touch(ID_FIRE, c.fireX, c.fireY, down)
                    return
                }
                BTN_RIGHT -> {
                    touch(ID_SCOPE, c.scopeX, c.scopeY, down)
                    return
                }
            }
            val idx = c.keys.indexOfFirst { it.code == code }
            if (idx >= 0) touch(ID_KEY0 + idx, c.keys[idx].x, c.keys[idx].y, down)
        }
    }

    private fun touch(id: Int, fx: Float, fy: Float, down: Boolean) {
        if (down) down(id, fx * cfg.w, fy * cfg.h) else up(id)
    }

    private fun updateJoy() {
        val c = cfg
        var vx = (if (jR) 1f else 0f) - (if (jL) 1f else 0f)
        var vy = (if (jD) 1f else 0f) - (if (jU) 1f else 0f)
        if (vx == 0f && vy == 0f) {
            up(ID_JOY)
            return
        }
        val len = sqrt(vx * vx + vy * vy)
        vx /= len
        vy /= len
        val cx = c.joyX * c.w
        val cy = c.joyY * c.h
        val r = c.joyR * c.h
        if (!isDown(ID_JOY)) down(ID_JOY, cx, cy)
        move(ID_JOY, cx + vx * r, cy + vy * r)
    }

    private fun pumpLoop() {
        while (alive) {
            try {
                Thread.sleep(8)
                val mx = dx.getAndSet(0)
                val my = dy.getAndSet(0)
                synchronized(lock) {
                    if (active && cfg.enabled) lookStep(mx, my)
                }
            } catch (_: InterruptedException) {
            } catch (_: Throwable) {
            }
        }
    }

    private fun lookStep(mx: Int, my: Int) {
        val c = cfg
        val w = c.w.toFloat()
        val h = c.h.toFloat()
        val now = SystemClock.uptimeMillis()
        if (mx == 0 && my == 0) {
            if (isDown(ID_LOOK) && now - lastLookAt > 150) up(ID_LOOK)
            return
        }
        val cx = c.lookX * w
        val cy = c.lookY * h
        if (!isDown(ID_LOOK)) {
            lookX = cx
            lookY = cy
            down(ID_LOOK, lookX, lookY)
        }
        lookX += mx * c.sens
        lookY += my * c.sens
        lastLookAt = now
        if (abs(lookX - cx) > 0.15f * w || abs(lookY - cy) > 0.30f * h) {
            // jari virtual mendekati tepi: angkat lalu taruh lagi di tengah
            up(ID_LOOK)
            lookX = cx
            lookY = cy
            down(ID_LOOK, lookX, lookY)
        } else {
            move(ID_LOOK, lookX, lookY)
        }
    }

    private fun releaseAll() {
        jU = false
        jL = false
        jD = false
        jR = false
        for (id in ids.toList()) up(id)
    }

    // ---------------------------------------------------------------- penyuntik sentuhan

    private fun initInjector() {
        try {
            val binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            val im = Class.forName("android.hardware.input.IInputManager\$Stub")
                .getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            inputMgr = im
            injectM = im!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            return
        } catch (_: Throwable) {
        }
        try {
            val imc = Class.forName("android.hardware.input.InputManager")
            inputMgr = imc.getMethod("getInstance").invoke(null)
            injectM = imc.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (t: Throwable) {
            injectError = "tidak bisa menyuntik: " + t.javaClass.simpleName
        }
    }

    private fun isDown(id: Int) = ids.contains(id)

    private fun down(id: Int, x: Float, y: Float) {
        if (ids.contains(id)) return
        if (ids.isEmpty()) downTime = SystemClock.uptimeMillis()
        ids.add(id)
        px[id] = x
        py[id] = y
        send(if (ids.size == 1) MotionEvent.ACTION_DOWN else MotionEvent.ACTION_POINTER_DOWN, id)
    }

    private fun move(id: Int, x: Float, y: Float) {
        if (!ids.contains(id)) return
        px[id] = x
        py[id] = y
        send(MotionEvent.ACTION_MOVE, id)
    }

    private fun up(id: Int) {
        if (!ids.contains(id)) return
        send(if (ids.size == 1) MotionEvent.ACTION_UP else MotionEvent.ACTION_POINTER_UP, id)
        ids.remove(id)
        px.remove(id)
        py.remove(id)
    }

    private fun send(action: Int, changed: Int) {
        if (action == MotionEvent.ACTION_MOVE && !rateOk()) return // penahan: hanya gerakan yang boleh dibuang
        val n = ids.size
        if (n == 0) return
        val props = Array(n) { MotionEvent.PointerProperties() }
        val coords = Array(n) { MotionEvent.PointerCoords() }
        for (i in 0 until n) {
            val id = ids[i]
            props[i].id = id
            props[i].toolType = MotionEvent.TOOL_TYPE_FINGER
            coords[i].x = px[id] ?: 0f
            coords[i].y = py[id] ?: 0f
            coords[i].pressure = 1f
            coords[i].size = 1f
        }
        val idx = ids.indexOf(changed)
        val act = if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_POINTER_UP) {
            action or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        } else action
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), act, n, props, coords, 0, 0, 1f, 1f, 0, 0,
            InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            injectM?.invoke(inputMgr, ev, 0)
        } catch (t: Throwable) {
            injectError = "gagal menyuntik: " + (t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName)
        } finally {
            ev.recycle()
        }
    }

    /** Maksimum 600 gerakan per detik; lebih dari itu dibuang agar sistem tidak kebanjiran (pelajaran dari makro lama). */
    private fun rateOk(): Boolean {
        val now = SystemClock.uptimeMillis()
        if (now - winStart > 1000) {
            winStart = now
            winCount = 0
        }
        winCount++
        limited = winCount > 600
        return !limited
    }

    // ---------------------------------------------------------------- status

    private fun writeStatus() {
        val names: List<String>
        val grabbedCount: Int
        val total: Int
        synchronized(devices) {
            names = devices.values.map { it.devName }
            grabbedCount = devices.values.count { it.grabbed }
            total = devices.size
        }
        val sb = StringBuilder()
        sb.append("hb=").append(System.currentTimeMillis()).append('\n')
        sb.append("active=").append(if (active) 1 else 0).append('\n')
        sb.append("devices=").append(names.joinToString(";")).append('\n')
        sb.append("grab=").append(grabbedCount).append('/').append(total).append('\n')
        sb.append("lastkey=").append(lastKey).append('\n')
        sb.append("lastkeyat=").append(lastKeyAt).append('\n')
        sb.append("inject=").append(if (injectError.isEmpty()) "ok" else injectError).append('\n')
        sb.append("limited=").append(if (limited) 1 else 0).append('\n')
        sb.append("procerror=").append(procError).append('\n')
        sb.append("rawseen=").append(rawSeen).append('\n')
        try {
            statusFile.writeText(sb.toString())
        } catch (_: Throwable) {
        }
    }
}
