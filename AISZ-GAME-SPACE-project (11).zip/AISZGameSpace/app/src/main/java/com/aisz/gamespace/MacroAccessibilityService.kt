package com.aisz.gamespace

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

/**
 * Mengetuk layar untuk fitur Makro lewat dispatchGesture (resmi, tanpa root). Tidak membaca isi layar.
 * Android hanya menjalankan satu gestur pada satu waktu, jadi satu makro aktif per saat.
 */
class MacroAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var repeating = false
    @Volatile private var holding = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopAll()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopAll()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopAll()
        instance = null
        super.onDestroy()
    }

    /** Menghentikan ketukan beruntun dan tahan yang sedang berjalan. */
    fun stopAll() {
        repeating = false
        holding = false
    }

    private fun pointPath(x: Float, y: Float) = Path().apply { moveTo(x, y) }

    @Volatile private var cancelStreak = 0

    private fun warn(msg: String) {
        handler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    /** count ketukan berurutan di (x, y), jeda intervalMs (1..100 ms). */
    fun tap(x: Float, y: Float, count: Int, intervalMs: Long): Boolean {
        stopAll()
        val iv = max(1L, intervalMs)
        val d = (iv / 2).coerceIn(1L, 20L)
        val n = count.coerceIn(1, GestureDescription.getMaxStrokeCount())
        val b = GestureDescription.Builder()
        for (i in 0 until n) {
            b.addStroke(GestureDescription.StrokeDescription(pointPath(x, y), i * iv, d))
        }
        return dispatchGesture(b.build(), null, null)
    }

    /**
     * Ketukan beruntun dengan jeda intervalMs (1..100 ms) sampai dihentikan.
     * Tiap kiriman memuat banyak ketukan sekaligus (maks. 20) supaya tidak ada jeda antar kiriman yang berarti.
     */
    fun startRepeat(x: Float, y: Float, intervalMs: Int) {
        stopAll()
        repeating = true
        cancelStreak = 0
        val iv = max(1, intervalMs).toLong()
        val d = (iv / 2).coerceIn(1L, 20L)
        val batch = ((250L + iv - 1) / iv).toInt().coerceIn(2, GestureDescription.getMaxStrokeCount())
        fun next() {
            if (!repeating || instance == null) return
            val b = GestureDescription.Builder()
            for (i in 0 until batch) {
                b.addStroke(GestureDescription.StrokeDescription(pointPath(x, y), i * iv, d))
            }
            val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    cancelStreak = 0
                    next()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    cancelStreak++
                    if (cancelStreak == 6) {
                        warn("Android membatalkan ketukan saat jari menahan tombol. Coba mode Beruntun (toggle).")
                    }
                    handler.postDelayed({ next() }, 15L)
                }
            }, handler)
            if (!ok) handler.postDelayed({ next() }, 30L)
        }
        next()
    }

    fun stopRepeat() {
        repeating = false
    }

    /** Menahan sentuhan di (x, y) sampai stopHold() dipanggil. Android 8+ menahan terus; di bawahnya 0,7 detik. */
    fun startHold(x: Float, y: Float) {
        stopAll()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(pointPath(x, y), 0, 700L))
                    .build(),
                null, null
            )
            return
        }
        holding = true
        fun send(s: GestureDescription.StrokeDescription) {
            val ok = dispatchGesture(GestureDescription.Builder().addStroke(s).build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (s.willContinue()) {
                        val keep = holding
                        send(s.continueStroke(pointPath(x, y), 0, if (keep) HOLD_SEG else 10L, keep))
                    }
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    holding = false
                }
            }, handler)
            if (!ok) holding = false
        }
        send(GestureDescription.StrokeDescription(pointPath(x, y), 0, HOLD_SEG, true))
    }

    fun stopHold() {
        holding = false
    }

    companion object {
        private const val TAP_MS = 30L
        private const val HOLD_SEG = 250L

        @Volatile
        var instance: MacroAccessibilityService? = null
            private set
    }
}
