package com.aisz.gamespace

import android.content.Context
import android.content.Intent
import android.app.NotificationManager
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings

enum class GamingProfile(
    val label: String,
    val description: String,
    val brightness: Int,
    val mediaVolume: Int,
    val keepScreenOn: Boolean,
    val gameMode: String
) {
    HEMAT("Hemat daya", "Menyalakan Penghemat Baterai HP.", 40, 50, false, "battery"),
    SEIMBANG("Seimbang", "Kondisi normal: Penghemat Baterai dan mode kinerja dimatikan, tidak ada yang lain.", 65, 70, true, "standard"),
    PERFORMA("Performa", "Menutup aplikasi latar (AISZ dan game tidak ikut), mengaktifkan mode kinerja HP dan Game Mode performa.", 90, 90, true, "performance");

    companion object {
        fun fromName(name: String?): GamingProfile =
            values().firstOrNull { it.name == name } ?: SEIMBANG
    }
}

enum class OrientationMode(val label: String, val androidValue: Int) {
    AUTO("Otomatis", ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED),
    PORTRAIT("Potret", ActivityInfo.SCREEN_ORIENTATION_PORTRAIT),
    LANDSCAPE("Lanskap", ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

    companion object {
        fun fromName(name: String?): OrientationMode =
            values().firstOrNull { it.name == name } ?: AUTO
    }
}

data class ProfileResult(val brightnessApplied: Boolean, val volumeApplied: Boolean)

class GameSettings(private val context: Context) {

    private val prefs = context.getSharedPreferences("aisz_settings", Context.MODE_PRIVATE)
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    var profile: GamingProfile
        get() = GamingProfile.fromName(prefs.getString("profile", null))
        set(value) { prefs.edit().putString("profile", value.name).apply() }

    var orientation: OrientationMode
        get() = OrientationMode.fromName(prefs.getString("orientation", null))
        set(value) { prefs.edit().putString("orientation", value.name).apply() }

    var keepScreenOn: Boolean
        get() = prefs.getBoolean("keep_screen_on", false)
        set(value) { prefs.edit().putBoolean("keep_screen_on", value).apply() }

    /** Aplikasi di dock jendela mengambang (maks. 4), urutan tersimpan. */
    var dockApps: List<String>
        get() = (prefs.getString("dock", "") ?: "").split(",").filter { it.isNotBlank() }
        set(value) { prefs.edit().putString("dock", value.joinToString(",")).apply() }

    /** Posisi terakhir panel melayang: sisi kanan? dan tinggi (pecahan 0..1 dari tinggi layar). */
    var panelRight: Boolean
        get() = prefs.getBoolean("panel_right", false)
        set(value) { prefs.edit().putBoolean("panel_right", value).apply() }

    var panelYFraction: Float
        get() = prefs.getFloat("panel_y", 0.33f)
        set(value) { prefs.edit().putFloat("panel_y", value).apply() }

    /** Game terakhir yang terdeteksi di layar depan oleh panel (untuk diagnostik). */
    var lastGamePkg: String?
        get() = prefs.getString("last_game", null)
        set(value) { prefs.edit().putString("last_game", value).apply() }

    /** Laporan diagnostik FPS terakhir yang direkam panel saat FPS tidak terbaca. */
    var fpsDiag: String
        get() = prefs.getString("fps_diag", "") ?: ""
        set(value) { prefs.edit().putString("fps_diag", value).apply() }

    // ---- Crosshair ----
    var chEnabled: Boolean
        get() = prefs.getBoolean("ch_on", false)
        set(value) { prefs.edit().putBoolean("ch_on", value).apply() }
    var chStyle: Int
        get() = prefs.getInt("ch_style", 0)
        set(value) { prefs.edit().putInt("ch_style", value).apply() }
    var chColor: Int
        get() = prefs.getInt("ch_color", -1)
        set(value) { prefs.edit().putInt("ch_color", value).apply() }
    var chSize: Int
        get() = prefs.getInt("ch_size", 30)
        set(value) { prefs.edit().putInt("ch_size", value).apply() }
    var chOpacity: Int
        get() = prefs.getInt("ch_op", 90)
        set(value) { prefs.edit().putInt("ch_op", value).apply() }
    var chPosX: Float
        get() = prefs.getFloat("ch_x", 0.5f)
        set(value) { prefs.edit().putFloat("ch_x", value).apply() }
    var chPosY: Float
        get() = prefs.getFloat("ch_y", 0.5f)
        set(value) { prefs.edit().putFloat("ch_y", value).apply() }

    fun resetCrosshair() {
        prefs.edit().remove("ch_style").remove("ch_color").remove("ch_size")
            .remove("ch_op").remove("ch_x").remove("ch_y").apply()
    }

    // ---- Monitor (HUD) ----
    var monEnabled: Boolean
        get() = prefs.getBoolean("mon_on", false)
        set(value) { prefs.edit().putBoolean("mon_on", value).apply() }
    var monItems: List<String>
        get() = (prefs.getString("mon_items", "FPS,CPU,BATT,TEMP") ?: "").split(",").filter { it.isNotBlank() }
        set(value) { prefs.edit().putString("mon_items", value.joinToString(",")).apply() }
    var monColor: Int
        get() = prefs.getInt("mon_color", 0xFF5B9BE0.toInt())
        set(value) { prefs.edit().putInt("mon_color", value).apply() }
    var monSize: Int
        get() = prefs.getInt("mon_size", 1)
        set(value) { prefs.edit().putInt("mon_size", value).apply() }
    var monPosX: Float
        get() = prefs.getFloat("mon_x", 0.02f)
        set(value) { prefs.edit().putFloat("mon_x", value).apply() }
    var monPosY: Float
        get() = prefs.getFloat("mon_y", 0.03f)
        set(value) { prefs.edit().putFloat("mon_y", value).apply() }

    fun resetMonitor() {
        prefs.edit().remove("mon_items").remove("mon_color").remove("mon_size")
            .remove("mon_x").remove("mon_y").apply()
    }

    // ---- Makro ----
    var macroEnabled: Boolean
        get() = prefs.getBoolean("mac_on", false)
        set(value) { prefs.edit().putBoolean("mac_on", value).apply() }
    var macroSize: Int
        get() = prefs.getInt("mac_size", 56)
        set(value) { prefs.edit().putInt("mac_size", value).apply() }
    var macroOpacity: Int
        get() = prefs.getInt("mac_op", 45)
        set(value) { prefs.edit().putInt("mac_op", value).apply() }

    fun macroSlotEnabled(i: Int): Boolean = prefs.getBoolean("mac_${i}_on", i < 4)
    fun setMacroSlotEnabled(i: Int, v: Boolean) { prefs.edit().putBoolean("mac_${i}_on", v).apply() }
    fun macroMode(i: Int): Int = prefs.getInt("mac_${i}_mode", when (i) { 0 -> 4; 1 -> 0; 2 -> 1; 3 -> 3; else -> 0 })
    fun setMacroMode(i: Int, v: Int) { prefs.edit().putInt("mac_${i}_mode", v).apply() }
    /** Jeda antar ketukan dalam milidetik (1..100). */
    fun macroMs(i: Int): Int = prefs.getInt("mac_${i}_ms", 20).coerceIn(1, 100)
    fun setMacroMs(i: Int, v: Int) { prefs.edit().putInt("mac_${i}_ms", v.coerceIn(1, 100)).apply() }
    fun macroBx(i: Int): Float = prefs.getFloat("mac_${i}_bx", 0.92f - 0.10f * (i / 3))
    fun macroBy(i: Int): Float = prefs.getFloat("mac_${i}_by", 0.25f + 0.2f * (i % 3))
    fun setMacroBtnPos(i: Int, x: Float, y: Float) {
        prefs.edit().putFloat("mac_${i}_bx", x).putFloat("mac_${i}_by", y).apply()
    }
    fun macroTx(i: Int): Float = prefs.getFloat("mac_${i}_tx", 0.80f - 0.06f * i)
    fun macroTy(i: Int): Float = prefs.getFloat("mac_${i}_ty", 0.62f)
    fun setMacroTarget(i: Int, x: Float, y: Float) {
        prefs.edit().putFloat("mac_${i}_tx", x).putFloat("mac_${i}_ty", y).apply()
    }
    fun resetMacros() {
        val e = prefs.edit()
        prefs.all.keys.filter { it.startsWith("mac_") && it != "mac_on" }.forEach { e.remove(it) }
        e.apply()
    }

    // ---- Tekstur Ringan ----
    var texLevel: Int
        get() = prefs.getInt("tex_level", 2).coerceIn(1, 3)
        set(value) { prefs.edit().putInt("tex_level", value.coerceIn(1, 3)).apply() }
    var texSharp: Boolean
        get() = prefs.getBoolean("tex_sharp", false)
        set(value) { prefs.edit().putBoolean("tex_sharp", value).apply() }

    // ---- Ukuran jendela mengambang ----
    var floatScale: Int
        get() = prefs.getInt("float_scale", 60)
        set(value) { prefs.edit().putInt("float_scale", value).apply() }
    var floatRatio: Int
        get() = prefs.getInt("float_ratio", 0)
        set(value) { prefs.edit().putInt("float_ratio", value).apply() }

    var onboardingDone: Boolean
        get() = prefs.getBoolean("onboarding_done", false)
        set(value) { prefs.edit().putBoolean("onboarding_done", value).apply() }

    var frameLock: Boolean
        get() = prefs.getBoolean("frame_lock", false)
        set(value) { prefs.edit().putBoolean("frame_lock", value).apply() }

    // ---- Kecerahan (butuh izin "Ubah pengaturan sistem") ----
    fun canWriteSystemSettings(): Boolean = Settings.System.canWrite(context)

    fun writeSettingsIntent(): Intent =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))

    fun getBrightnessPercent(): Int {
        val raw = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        } catch (e: Exception) {
            128
        }
        return (raw * 100 / 255).coerceIn(0, 100)
    }

    fun setBrightnessPercent(percent: Int): Boolean {
        if (!canWriteSystemSettings()) return false
        return try {
            val cr = context.contentResolver
            Settings.System.putInt(
                cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, percent.coerceIn(1, 100) * 255 / 100)
        } catch (e: Exception) {
            false
        }
    }

    // ---- Volume ----
    fun getVolumePercent(stream: Int): Int {
        val max = audio.getStreamMaxVolume(stream)
        return if (max > 0) audio.getStreamVolume(stream) * 100 / max else 0
    }

    fun setVolumePercent(stream: Int, percent: Int): Boolean = try {
        val max = audio.getStreamMaxVolume(stream)
        audio.setStreamVolume(stream, percent.coerceIn(0, 100) * max / 100, 0)
        true
    } catch (e: SecurityException) {
        false
    }

    // ---- Jangan Ganggu (butuh izin akses Jangan Ganggu dari pengguna) ----
    private val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun hasDndAccess(): Boolean = nm.isNotificationPolicyAccessGranted

    fun dndIntent(): Intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)

    fun isDndOn(): Boolean {
        val f = nm.currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL &&
            f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    fun setDnd(on: Boolean): Boolean {
        if (!hasDndAccess()) return false
        return try {
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            true
        } catch (e: SecurityException) {
            false
        }
    }

    /** Hanya menyimpan pilihan mode; efek ke HP diterapkan oleh ModeController. */
    fun applyProfile(p: GamingProfile): ProfileResult {
        profile = p
        return ProfileResult(false, false)
    }

    companion object {
        const val MACRO_SLOTS = 6

        /** Shortcut ke pengaturan sistem: judul to action. */
        val shortcuts: List<Pair<String, String>> = listOf(
            "Layar" to Settings.ACTION_DISPLAY_SETTINGS,
            "Suara" to Settings.ACTION_SOUND_SETTINGS,
            "Baterai" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
            "Semua" to Settings.ACTION_SETTINGS
        )
    }
}
