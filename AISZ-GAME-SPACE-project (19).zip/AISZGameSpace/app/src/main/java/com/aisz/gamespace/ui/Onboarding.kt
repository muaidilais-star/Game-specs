package com.aisz.gamespace.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.aisz.gamespace.MainActivity
import com.aisz.gamespace.ShellTools
import com.aisz.gamespace.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun StepCard(
    n: Int,
    title: String,
    done: Boolean,
    doneText: String,
    content: @Composable ColumnScope.() -> Unit
) {
    GlowCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(32.dp).clip(CircleShape)
                    .background(if (done) AiszColors.Ok.copy(alpha = 0.25f) else AiszColors.SurfaceHigh)
                    .border(1.dp, if (done) AiszColors.Ok else AiszColors.Neon.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (done) "✓" else "$n", color = if (done) AiszColors.Ok else AiszColors.Neon,
                    fontWeight = FontWeight.Bold, fontSize = 15.sp
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = AiszColors.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (done) doneText else "Belum",
                    color = if (done) AiszColors.Ok else AiszColors.Warn, fontSize = 12.sp
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
private fun Desc(text: String) {
    Text(text, color = AiszColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
}

/** Panduan awal: izin dan pengaturan yang dibutuhkan agar semua fitur berjalan. Muncul otomatis saat pertama dibuka. */
@Composable
fun OnboardingScreen(activity: MainActivity, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = activity.resumeTick.value
    var notifOk by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(false) }
    var devOk by remember { mutableStateOf(false) }
    var ffOk by remember { mutableStateOf(false) }
    var frOk by remember { mutableStateOf(false) }
    var shInstalled by remember { mutableStateOf(false) }
    var shRunning by remember { mutableStateOf(false) }
    var shGranted by remember { mutableStateOf(false) }
    var recheck by remember { mutableStateOf(0) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { recheck++ }

    LaunchedEffect(tick, recheck) {
        while (true) {
            notifOk = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
            overlayOk = Settings.canDrawOverlays(ctx)
            val cr = ctx.contentResolver
            devOk = Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
            ffOk = Settings.Global.getInt(cr, "enable_freeform_support", 0) == 1
            frOk = Settings.Global.getInt(cr, "force_resizable_activities", 0) == 1
            shInstalled = ShizukuHelper.isInstalled(ctx)
            shRunning = ShizukuHelper.isRunning()
            shGranted = withContext(Dispatchers.IO) { ShizukuHelper.hasPermission() }
            delay(1500)
        }
    }

    Column(
        Modifier.fillMaxSize().background(AiszColors.Black).systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Panduan awal", color = AiszColors.Neon, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "Ikuti langkah di bawah agar semua fitur AISZ GAME SPACE berjalan. Setiap langkah berubah menjadi centang hijau saat selesai.",
            color = AiszColors.TextDim, fontSize = 13.sp
        )

        StepCard(1, "Notifikasi", notifOk, "Diizinkan") {
            Desc("Dibutuhkan agar panel melayang tetap berjalan dan pesan seperti rekam layar dan timer terlihat.")
            GhostButton("Izinkan notifikasi", Modifier.fillMaxWidth()) {
                if (Build.VERSION.SDK_INT >= 33) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    ctx.safeStart(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    )
                }
            }
        }

        StepCard(2, "Tampilkan di atas aplikasi lain", overlayOk, "Diizinkan") {
            Desc("Wajib untuk panel melayang, crosshair, dan monitor. Di HyperOS/MIUI, aktifkan juga \"Tampilkan jendela pop-up saat berjalan di latar belakang\" di Info aplikasi > Izin lainnya.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Buka pengaturan", Modifier.weight(1f)) {
                    ctx.safeStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
                GhostButton("Info aplikasi", Modifier.weight(1f)) {
                    ctx.safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }
            }
        }

        StepCard(3, "Shizuku", shGranted, "Aktif dan diizinkan") {
            Desc("Dibutuhkan untuk FPS game, mode performa, jendela mengambang, screenshot, dan bersihkan ruang. Shizuku dimulai tanpa root lewat Debugging nirkabel (Android 11+).")
            when {
                !shInstalled -> {
                    Desc("1. Pasang aplikasi Shizuku.")
                    GhostButton("Pasang Shizuku", Modifier.fillMaxWidth()) {
                        ctx.safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
                    }
                }
                !shRunning -> {
                    Desc("2. Aktifkan Opsi pengembang > Debugging nirkabel (sambungkan Wi-Fi). 3. Buka Shizuku > Mulai lewat Debugging nirkabel, ikuti langkah pairing. Shizuku berhenti saat Wi-Fi putus atau HP restart, ulangi langkah ini bila perlu.")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GhostButton("Buka Shizuku", Modifier.weight(1f)) {
                            val i = ctx.packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE)
                            if (i != null) ctx.safeStart(i)
                        }
                        GhostButton("Opsi pengembang", Modifier.weight(1f)) {
                            ctx.safeStart(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                        }
                    }
                }
                else -> {
                    Desc("4. Izinkan AISZ memakai Shizuku.")
                    NeonButton("Izinkan AISZ", Modifier.fillMaxWidth()) { ShizukuHelper.requestPermission() }
                }
            }
        }

        StepCard(4, "Jendela mengambang (Opsi pengembang)", ffOk && frOk, "Freeform aktif") {
            Desc("Jendela mengambang butuh dua opsi: \"Aktifkan jendela freeform\" dan \"Paksa aktivitas agar dapat diubah ukurannya\". Cara membuka Opsi pengembang: Pengaturan > Tentang ponsel > ketuk versi OS 7 kali. Setelah menyalakannya, mulai ulang HP sekali. HP RAM rendah (Android Go) tidak mendukung jendela mengambang sama sekali.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Opsi pengembang: " + if (devOk) "aktif" else "belum",
                    color = if (devOk) AiszColors.Ok else AiszColors.Warn, fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Buka Opsi pengembang", Modifier.weight(1f)) {
                    ctx.safeStart(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                }
                GhostButton("Aktifkan otomatis", Modifier.weight(1f)) {
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { ShellTools.enableFreeformSupport() }
                        Toast.makeText(
                            ctx,
                            if (r.ok) "Diterapkan. Sebagian HP perlu dimulai ulang agar berlaku." else "Butuh Shizuku aktif.",
                            Toast.LENGTH_LONG
                        ).show()
                        recheck++
                    }
                }
            }
        }

        StepCard(5, "Opsional: kecerahan sistem", false, "") {
            Desc("Untuk mengubah kecerahan sistem dari panel, beri izin \"Ubah pengaturan sistem\" di tab Atur.")
        }

        NeonButton("Selesai", Modifier.fillMaxWidth(), onClick = onClose)
        Spacer(Modifier.height(12.dp))
    }
}
