package com.aisz.gamespace

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** Membuka pemilih berkas untuk menambahkan lagu dari penyimpanan HP. */
class MusicPickActivity : ComponentActivity() {

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val songs = uris.map { u ->
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                MusicEngine.Song(u.toString(), titleOf(u))
            }
            val n = MusicEngine.add(this, songs)
            Toast.makeText(this, if (n > 0) "$n lagu ditambahkan" else "Lagu itu sudah ada di daftar", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MusicEngine.ensureLoaded(this)
        picker.launch(arrayOf("audio/*"))
    }

    private fun titleOf(u: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (_: Exception) {
        }
        val n = name ?: u.lastPathSegment ?: "Lagu"
        return n.substringBeforeLast('.', n).ifBlank { n }
    }
}
