package com.aisz.gamespace

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// Palet panel (mengikuti gaya Game Turbo): gelap, aksen kuning-olive, judul biru
private val C_ACC = Color.parseColor("#D8DB3A")
private val C_ACC_DIM = Color.parseColor("#8E9124")
private val C_HOT = Color.parseColor("#FF4D5E")
private val C_DIM = Color.parseColor("#8C94A3")
// Warna per mode (lembut, tidak ngejreng)
private val C_GREEN = Color.parseColor("#5CBF8A")
private val C_BLUE = Color.parseColor("#5B9BE0")
private val C_RED = Color.parseColor("#E0605E")

/** Ikon sederhana digambar dengan kanvas (tanpa file gambar, tanpa risiko resource). */
enum class Glyph { BOLT, TRASH, SHOT, REC, DND, GEAR, TIMER, FRAME, CLOSE, SUN, SPEAKER, SPEAKER_OFF, RESTORE }

/** Menggambar ikon pada kisi 24x24 (kanvas sudah di-translate dan di-scale oleh pemanggil). */
internal fun drawGlyph(c: Canvas, glyph: Glyph, p: Paint, path: Path) {
    path.reset()
    when (glyph) {
        Glyph.BOLT -> {
            path.moveTo(13f, 2f); path.lineTo(5f, 13f); path.lineTo(11f, 13f)
            path.lineTo(10f, 22f); path.lineTo(19f, 10f); path.lineTo(13f, 10f); path.close()
            c.drawPath(path, p)
        }
        Glyph.TRASH -> {
            c.drawLine(4f, 6f, 20f, 6f, p)
            path.moveTo(9f, 6f); path.lineTo(9f, 3.5f); path.lineTo(15f, 3.5f); path.lineTo(15f, 6f)
            c.drawPath(path, p)
            path.reset()
            path.moveTo(6f, 6f); path.lineTo(7f, 20f); path.lineTo(17f, 20f); path.lineTo(18f, 6f)
            c.drawPath(path, p)
            c.drawLine(10f, 10f, 10f, 17f, p)
            c.drawLine(14f, 10f, 14f, 17f, p)
        }
        Glyph.SHOT -> {
            path.moveTo(4f, 9f); path.lineTo(4f, 4f); path.lineTo(9f, 4f)
            path.moveTo(15f, 4f); path.lineTo(20f, 4f); path.lineTo(20f, 9f)
            path.moveTo(20f, 15f); path.lineTo(20f, 20f); path.lineTo(15f, 20f)
            path.moveTo(9f, 20f); path.lineTo(4f, 20f); path.lineTo(4f, 15f)
            c.drawPath(path, p)
            c.drawCircle(12f, 12f, 3f, p)
        }
        Glyph.REC -> {
            c.drawRoundRect(RectF(3f, 6f, 15f, 18f), 2f, 2f, p)
            path.moveTo(15f, 10f); path.lineTo(21f, 7f); path.lineTo(21f, 17f); path.lineTo(15f, 14f)
            c.drawPath(path, p)
        }
        Glyph.DND -> {
            c.drawCircle(12f, 12f, 9f, p)
            c.drawLine(7f, 12f, 17f, 12f, p)
        }
        Glyph.GEAR -> {
            c.drawCircle(12f, 12f, 3.5f, p)
            c.drawCircle(12f, 12f, 7f, p)
            for (k in 0 until 8) {
                val a = k * Math.PI / 4.0
                c.drawLine(
                    12f + 7f * cos(a).toFloat(), 12f + 7f * sin(a).toFloat(),
                    12f + 9.8f * cos(a).toFloat(), 12f + 9.8f * sin(a).toFloat(), p
                )
            }
        }
        Glyph.TIMER -> {
            c.drawLine(6f, 3f, 18f, 3f, p)
            c.drawLine(6f, 21f, 18f, 21f, p)
            path.moveTo(7f, 3f); path.lineTo(7f, 7f); path.lineTo(12f, 12f); path.lineTo(17f, 7f); path.lineTo(17f, 3f)
            path.moveTo(7f, 21f); path.lineTo(7f, 17f); path.lineTo(12f, 12f); path.lineTo(17f, 17f); path.lineTo(17f, 21f)
            c.drawPath(path, p)
        }
        Glyph.FRAME -> {
            c.drawArc(RectF(3f, 5f, 21f, 23f), 180f, 180f, false, p)
            c.drawLine(12f, 14f, 17f, 9f, p)
            c.drawCircle(12f, 14f, 1.2f, p)
        }
        Glyph.CLOSE -> {
            c.drawLine(6f, 6f, 18f, 18f, p)
            c.drawLine(18f, 6f, 6f, 18f, p)
        }
        Glyph.RESTORE -> {
            c.drawArc(RectF(4f, 4f, 20f, 20f), 40f, 280f, false, p)
            path.moveTo(20f, 4f); path.lineTo(20f, 9f); path.lineTo(15f, 9f)
            c.drawPath(path, p)
        }
        Glyph.SUN -> {
            c.drawCircle(12f, 12f, 4f, p)
            for (k in 0 until 8) {
                val a = k * Math.PI / 4.0
                c.drawLine(
                    12f + 6.8f * cos(a).toFloat(), 12f + 6.8f * sin(a).toFloat(),
                    12f + 9.6f * cos(a).toFloat(), 12f + 9.6f * sin(a).toFloat(), p
                )
            }
        }
        Glyph.SPEAKER, Glyph.SPEAKER_OFF -> {
            path.moveTo(4f, 9.5f); path.lineTo(8f, 9.5f); path.lineTo(13f, 5f)
            path.lineTo(13f, 19f); path.lineTo(8f, 14.5f); path.lineTo(4f, 14.5f); path.close()
            c.drawPath(path, p)
            if (glyph == Glyph.SPEAKER) {
                c.drawArc(RectF(10f, 8f, 18f, 16f), -50f, 100f, false, p)
                c.drawArc(RectF(8f, 5f, 21f, 19f), -50f, 100f, false, p)
            } else {
                c.drawLine(16f, 9f, 21f, 15f, p)
                c.drawLine(21f, 9f, 16f, 15f, p)
            }
        }
    }
}

class IconView(context: Context, private val glyph: Glyph) : View(context) {
    var tint: Int = Color.parseColor("#C9CED8")
        set(value) {
            field = value
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        c.scale(s / 24f, s / 24f)
        p.color = tint
        drawGlyph(c, glyph, p, path)
        c.restore()
    }
}

/** Latar persegi dengan sudut terpotong (gaya HUD). */
class CutDrawable(
    fill: Int,
    stroke: Int,
    private val cut: Float,
    private val strokePx: Float,
    private val tl: Boolean = false,
    private val tr: Boolean = false,
    private val br: Boolean = false,
    private val bl: Boolean = false
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = fill
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokePx
        color = stroke
        strokeJoin = Paint.Join.MITER
    }
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val h = strokePx / 2f
        val l = bounds.left + h
        val t = bounds.top + h
        val r = bounds.right - h
        val b = bounds.bottom - h
        val c = cut
        path.reset()
        if (tl) { path.moveTo(l, t + c); path.lineTo(l + c, t) } else path.moveTo(l, t)
        if (tr) { path.lineTo(r - c, t); path.lineTo(r, t + c) } else path.lineTo(r, t)
        if (br) { path.lineTo(r, b - c); path.lineTo(r - c, b) } else path.lineTo(r, b)
        if (bl) { path.lineTo(l + c, b); path.lineTo(l, b - c) } else path.lineTo(l, b)
        path.close()
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, strokePaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        strokePaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Grafik area FPS bergaya Game Turbo: sumbu 0..puncak, isian kuning, bergeser halus tiap sampel baru. */
class MiniGraph(context: Context) : View(context) {
    private var values: List<Float> = emptyList()
    private var minTop = 60f
    private var slide = 0f
    private var accent = C_BLUE
    private var shaderH = 0f
    private var anim: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.8f * d
        color = C_ACC
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply {
        color = Color.parseColor("#33FFFFFF")
        strokeWidth = 1f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = C_DIM
        textSize = 8f * d
        textAlign = Paint.Align.LEFT
    }
    private val plot = RectF()

    fun setValues(v: List<Float>, minCeiling: Float) {
        val appended = v.size > values.size && v.size > 1
        values = v
        minTop = minCeiling
        anim?.cancel()
        if (appended) {
            anim = ValueAnimator.ofFloat(1f, 0f).apply {
                duration = 600
                interpolator = LinearInterpolator()
                addUpdateListener {
                    slide = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            slide = 0f
            invalidate()
        }
    }

    private fun rebuildShader() {
        if (shaderH <= 0f) return
        fill.shader = LinearGradient(
            0f, 0f, 0f, shaderH,
            Color.argb(210, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Color.argb(10, Color.red(accent), Color.green(accent), Color.blue(accent)), Shader.TileMode.CLAMP
        )
    }

    fun setAccent(c: Int) {
        accent = c
        line.color = c
        rebuildShader()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        shaderH = h.toFloat()
        rebuildShader()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val lm = 22f * d
        val top = ceil(max(minTop, values.maxOrNull() ?: 0f) / 30f) * 30f
        plot.set(lm, 4f * d, w, h - 2f * d)
        canvas.drawLine(lm, plot.top, w, plot.top, grid)
        canvas.drawLine(lm, (plot.top + plot.bottom) / 2f, w, (plot.top + plot.bottom) / 2f, grid)
        canvas.drawLine(lm, plot.bottom, w, plot.bottom, grid)
        canvas.drawText("${top.toInt()}", 0f, plot.top + 6f * d, label)
        canvas.drawText("${(top / 2f).toInt()}", 0f, (plot.top + plot.bottom) / 2f + 3f * d, label)
        canvas.drawText("0", 0f, plot.bottom, label)
        if (values.size < 2) return
        val step = plot.width() / (values.size - 1)
        canvas.save()
        canvas.clipRect(plot.left, 0f, plot.right, h)
        canvas.translate(slide * step, 0f)
        val lp = Path()
        val fp = Path()
        values.forEachIndexed { i, v ->
            val x = plot.left + i * step
            val y = plot.bottom - (v / top).coerceIn(0f, 1f) * plot.height()
            if (i == 0) {
                lp.moveTo(x, y)
                fp.moveTo(x, plot.bottom)
                fp.lineTo(x, y)
            } else {
                lp.lineTo(x, y)
                fp.lineTo(x, y)
            }
        }
        fp.lineTo(plot.left + (values.size - 1) * step, plot.bottom)
        fp.close()
        canvas.drawPath(fp, fill)
        canvas.drawPath(lp, line)
        canvas.restore()
    }
}

/** Slider berbentuk pil (gaya panel cepat): ikon bulat di kiri, isian membesar ke kanan. */
class PillSlider(context: Context, private var glyph: Glyph) : View(context) {
    var onChange: ((Int, Boolean) -> Unit)? = null
    var onIconTap: (() -> Unit)? = null
    private var progress = 0
    private var dragging = false
    private var iconDown = false
    private var downX = 0f
    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A2F38") }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DCE0E8") }
    private val circleP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D91A1F28") }
    private val glyphP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
        color = Color.WHITE
    }
    private val clip = Path()
    private val rect = RectF()
    private val gp = Path()

    fun setGlyph(g: Glyph) {
        if (g != glyph) {
            glyph = g
            invalidate()
        }
    }

    fun setProgressSilently(p: Int) {
        if (dragging) return
        val v = p.coerceIn(0, 100)
        if (v != progress) {
            progress = v
            invalidate()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, track)
        val fw = h + (w - h) * progress / 100f
        c.save()
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(clip)
        c.drawRect(0f, 0f, fw, h, fillP)
        c.restore()
        c.drawCircle(r, r, r - 5f * d, circleP)
        val gs = 20f * d
        c.save()
        c.translate(r - gs / 2f, r - gs / 2f)
        c.scale(gs / 24f, gs / 24f)
        drawGlyph(c, glyph, glyphP, gp)
        c.restore()
    }

    private fun setFromX(x: Float) {
        val p = ((x / max(1, width)) * 100f).roundToInt().coerceIn(0, 100)
        if (p != progress) {
            progress = p
            invalidate()
            onChange?.invoke(p, true)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x
                iconDown = onIconTap != null && e.x < height
                dragging = !iconDown
                if (!iconDown) setFromX(e.x)
            }
            MotionEvent.ACTION_MOVE -> {
                if (iconDown && abs(e.x - downX) > slop) {
                    iconDown = false
                    dragging = true
                }
                if (dragging) setFromX(e.x)
            }
            MotionEvent.ACTION_UP -> {
                if (iconDown) onIconTap?.invoke()
                iconDown = false
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                iconDown = false
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }
}

/** Cincin status tugas: berputar saat berjalan, busur menyesuaikan kemajuan, lalu menampilkan hasil. */
class TaskRing(context: Context) : View(context) {
    private var state = 0 // 0 diam, 1 berjalan, 2 selesai, 3 gagal
    private var angle = 0f
    private var progress = 0f
    private var label = ""
    var accent: Int = C_BLUE
        set(v) {
            field = v
            invalidate()
        }
    private var animator: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        strokeCap = Paint.Cap.ROUND
        color = C_ACC
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 9f * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private val oval = RectF()
    private val reset = Runnable {
        state = 0
        label = ""
        invalidate()
    }

    fun start() {
        removeCallbacks(reset)
        state = 1
        progress = 0f
        label = ""
        if (animator == null) {
            animator = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 900
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    angle = it.animatedValue as Float
                    invalidate()
                }
            }
        }
        animator?.start()
        invalidate()
    }

    fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        invalidate()
    }

    fun finish(text: String, ok: Boolean) {
        animator?.cancel()
        state = if (ok) 2 else 3
        label = text
        invalidate()
        removeCallbacks(reset)
        postDelayed(reset, 3000L)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        removeCallbacks(reset)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 3f * d
        oval.set(cx - r, cy - r, cx + r, cy + r)
        ring.color = when (state) {
            2 -> accent
            3 -> C_HOT
            else -> Color.parseColor("#4A5260")
        }
        c.drawCircle(cx, cy, r, ring)
        if (state == 1) {
            arc.color = accent
            c.drawArc(oval, angle, 70f + 220f * progress, false, arc)
        }
        val text = when (state) {
            1 -> if (progress > 0.01f) "${(progress * 100).toInt()}" else ""
            2, 3 -> label
            else -> ""
        }
        if (text.isNotEmpty()) {
            txt.color = if (state == 3) C_HOT else Color.parseColor("#EDEFF2")
            c.drawText(text, cx, cy - (txt.descent() + txt.ascent()) / 2f, txt)
        } else if (state == 0) {
            txt.color = C_DIM
            c.drawText("•", cx, cy - (txt.descent() + txt.ascent()) / 2f, txt)
        }
    }
}

/**
 * Panel gaming melayang bergaya Game Turbo. Pegangan putih tipis menempel di tepi layar dan tidak
 * berpindah saat panel dibuka (jendela terpisah). Dock jendela mengambang berdiri sendiri di sisi
 * kiri panel. Ketuk area luar panel untuk menutup.
 */
class FloatingPanelService : Service() {

    private class Tile(val view: LinearLayout, val title: TextView, val sub: TextView?, val icon: IconView, val flat: Boolean)

    private lateinit var wm: WindowManager
    private lateinit var handleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var scrimParams: WindowManager.LayoutParams
    private var scrim: View? = null
    private var scrimActive = false
    private lateinit var handle: FrameLayout
    private lateinit var handleBar: View
    private var handleAdded = false
    private lateinit var panel: LinearLayout
    private var panelAttached = false
    private lateinit var dockBox: LinearLayout
    private lateinit var dockScroll: ScrollView
    private lateinit var dock: LinearLayout
    private lateinit var mainBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var ring: TaskRing
    private lateinit var tvModeTag: TextView
    private lateinit var btnStop: TextView
    private lateinit var tvSub: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvFpsBefore: TextView
    private lateinit var tvFpsNote: TextView
    private lateinit var graph: MiniGraph
    private lateinit var sliderBright: PillSlider
    private lateinit var sliderVol: PillSlider
    private lateinit var tvFooter: TextView
    private lateinit var tileClean: Tile
    private lateinit var tileSpace: Tile
    private lateinit var tileDnd: Tile
    private lateinit var tileShot: Tile
    private lateinit var tileRec: Tile
    private lateinit var tileSettings: Tile
    private lateinit var tileRestore: Tile
    private lateinit var tileFrame: Tile
    private lateinit var tileTimer: Tile
    private var hudView: TextView? = null
    private var accent = C_BLUE
    private var accentDim = Color.argb(140, 91, 155, 224)
    private lateinit var statsCard: LinearLayout
    private lateinit var modeMark: View
    private val dots = mutableListOf<View>()

    private var expanded = false
    private var dockRight = false
    private var tickCount = 0
    private var lastInteraction = 0L
    private val fpsHistory = ArrayList<Float>()
    private var fpsBefore: Int? = null
    private var fpsShown: Int? = null
    private var fpsAnim: ValueAnimator? = null
    private var lastNet: NetStatus? = null
    private var lastPing: Int? = null
    private var lastTemp: ThermalReading? = null
    @Volatile private var gamePkg: String? = null
    @Volatile private var lastFloating: String? = null
    @Volatile private var gameBeforeFloat: String? = null
    private var homePkg: String? = null
    private var warnedBrightness = false
    private var timerMinutes = 0
    private var timerEndAt = 0L
    private var receiverRegistered = false

    private val handler = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val slowExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, if (expanded) 1000L else 5000L)
        }
    }
    private val timerDone = Runnable { onTimerDone() }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (!handleAdded) return
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (expanded) toggle()
                    handle.visibility = View.GONE
                }
                Intent.ACTION_USER_PRESENT -> handle.visibility = View.VISIBLE
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        ShellTools.init(this)
        instance = this
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin tampil di atas aplikasi lain belum diberikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!handleAdded) buildOverlay()
        if (!receiverRegistered) {
            val f = IntentFilter(Intent.ACTION_SCREEN_OFF).apply { addAction(Intent.ACTION_USER_PRESENT) }
            ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        isRunning = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!handleAdded) return
        handle.post {
            if (expanded) toggle()
            handleParams.y = (GameSettings(this).panelYFraction * screenSize().second).toInt()
            positionHandle()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        fpsAnim?.cancel()
        executor.shutdownNow()
        slowExecutor.shutdownNow()
        if (receiverRegistered) {
            try {
                unregisterReceiver(screenReceiver)
            } catch (_: Exception) {
            }
        }
        removeSafely(hudView)
        if (panelAttached) removeSafely(panel)
        if (handleAdded) removeSafely(handle)
        removeSafely(scrim)
        panelAttached = false
        handleAdded = false
        scrim = null
        instance = null
        isRunning = false
        super.onDestroy()
    }

    private fun removeSafely(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ notifikasi

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val m = getSystemService(NotificationManager::class.java)
            m.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Panel gaming", NotificationManager.IMPORTANCE_LOW))
            m.createNotificationChannel(NotificationChannel(TIMER_CHANNEL, "Timer bermain", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("AISZ GAME SPACE")
            .setContentText("Panel gaming aktif")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(0, "Tutup panel", stop)
            .build()
    }

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ helper

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return b.width() to b.height()
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun edgeRadii(r: Float): FloatArray =
        if (dockRight) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)

    /** Kotak bersudut membulat (nama lama dipertahankan agar pemanggil tidak berubah). */
    private fun cutBg(
        fill: Int, stroke: Int, cutDp: Int,
        tl: Boolean = false, tr: Boolean = false, br: Boolean = true, bl: Boolean = false
    ): GradientDrawable = rounded(fill, (cutDp * 1.9f).toInt().coerceAtLeast(10), stroke)

    private fun withAlpha(c: Int, a: Float): Int =
        Color.argb((a * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun margins(v: Int) = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        setMargins(dp(v), dp(v), dp(v), dp(v))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun View.pressable(onClick: () -> Unit) {
        setOnClickListener {
            lastInteraction = SystemClock.elapsedRealtime()
            onClick()
        }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }
            false
        }
    }

    /** Pesan singkat berupa lapisan sendiri: tetap terlihat di dalam game (toast biasa sering tidak tampil). */
    private fun showHud(msg: String) {
        handler.post {
            if (!handleAdded) return@post
            removeSafely(hudView)
            val tv = text(msg, 13f, TEXT, true).apply {
                gravity = Gravity.CENTER
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                maxWidth = screenSize().first - dp(48)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = cutBg(HUD_BG, accent, 8, tl = true, br = true)
                alpha = 0f
            }
            val lpHud = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(28)
                useFullScreenArea()
            }
            try {
                wm.addView(tv, lpHud)
            } catch (_: Exception) {
                return@post
            }
            hudView = tv
            tv.animate().alpha(1f).setDuration(150).start()
            handler.postDelayed({
                tv.animate().alpha(0f).setDuration(200).withEndAction {
                    removeSafely(tv)
                    if (hudView === tv) hudView = null
                }.start()
            }, 3000L)
        }
    }

    private fun toast(msg: String) = showHud(msg)

    /** Ubin vertikal bergaris (kotak): ikon di atas, judul di bawah. */
    private fun boxTile(glyph: Glyph, title: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph)
        val t = text(title, 10.5f, TEXT).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = cutBg(TILE_BG, TILE_STROKE, 7)
            addView(icon, lp(dp(24), dp(24)))
            addView(t, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
            pressable(onClick)
        }
        return Tile(box, t, null, icon, false)
    }

    /** Ubin datar (tanpa garis) untuk baris ikon dalam satu wadah. */
    private fun flatTile(glyph: Glyph, title: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph)
        val t = text(title, 10f, TEXT).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(4), dp(2), dp(4))
            addView(icon, lp(dp(24), dp(24)))
            addView(t, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
            pressable(onClick)
        }
        return Tile(box, t, null, icon, true)
    }

    private fun wideTile(glyph: Glyph, title: String, sub: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph)
        val t = text(title, 12f, TEXT, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val s = text(sub, 10f, DIM).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(t)
            addView(s)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(10), 0)
            background = cutBg(TILE_BG, TILE_STROKE, 7)
            addView(icon, lp(dp(24), dp(24)).apply { rightMargin = dp(10) })
            addView(col, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            pressable(onClick)
        }
        return Tile(box, t, s, icon, false)
    }

    private fun setTileActive(t: Tile, active: Boolean, color: Int = accent) {
        if (t.flat) {
            t.view.background = if (active) rounded(withAlpha(color, 0.22f), 12) else null
        } else {
            t.view.background = cutBg(if (active) withAlpha(color, 0.16f) else TILE_BG, if (active) color else TILE_STROKE, 7)
        }
        t.icon.tint = if (active) color else ICON
    }

    // ------------------------------------------------------------ susunan panel

    /** Kartu grafik FPS: chip mode, grafik area, Setelah/Sebelum, tombol Hentikan. */
    private fun buildStatsCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = cutBg(TILE_BG, accentDim, 10, tl = true, br = true)
        }
        statsCard = card
        tvModeTag = text("Seimbang", 12f, accent, true).apply {
            setPadding(dp(8), dp(2), dp(8), dp(2))
            pressable { cycleMode() }
        }
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(View(this@FloatingPanelService), lp(0, 1, 1f))
            addView(tvModeTag)
            modeMark = View(this@FloatingPanelService).apply { background = rounded(accent, 4) }
            addView(modeMark, lp(dp(18), dp(8)).apply { leftMargin = dp(4) })
        })

        graph = MiniGraph(this)
        tvFpsNote = text("", 9.5f, DIM).apply {
            gravity = Gravity.CENTER
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(24), 0, 0, 0)
        }
        val frame = FrameLayout(this).apply {
            addView(graph, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(tvFpsNote, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            ))
        }
        card.addView(frame, lp(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(2)
            bottomMargin = dp(4)
        })

        tvFps = text("-- FPS", 16f, DIM, true)
        tvFpsBefore = text("-- FPS", 16f, DIM, true)
        fun stat(valueView: TextView, caption: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(valueView)
            addView(LinearLayout(this@FloatingPanelService).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val dot = View(this@FloatingPanelService).apply {
                    background = circle(Color.TRANSPARENT, accent)
                }
                dots.add(dot)
                addView(dot, lp(dp(6), dp(6)).apply { rightMargin = dp(4) })
                addView(text(caption, 9.5f, DIM))
            })
        }
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(stat(tvFps, "Setelah"), lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(stat(tvFpsBefore, "Sebelum"), lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        })

        btnStop = text("Hentikan", 13f, accent, true).apply {
            gravity = Gravity.CENTER
            background = cutBg(Color.parseColor("#4B4D12"), accent, 6, tl = true, br = true)
            pressable { stopOrBoost() }
        }
        card.addView(btnStop, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(26)).apply { topMargin = dp(4) })
        return card
    }

    private fun circle(fill: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun buildPanel(): LinearLayout {
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Judul + cincin tugas
        ring = TaskRing(this)
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(text("AISZ GAME SPACE", 15f, TITLE, true).apply { letterSpacing = 0.08f }, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(ring, lp(dp(36), dp(36)))
        }, margins(4))
        tvSub = text("WLAN  --   -- ms   -- °C", 10f, DIM).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        content.addView(tvSub, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(5), 0, dp(4), dp(2))
        })

        // Baris atas: dua ubin + kartu grafik FPS
        tileClean = boxTile(Glyph.BOLT, "Bersihkan memori") { cleanMemory() }
        tileSpace = boxTile(Glyph.TRASH, "Bebaskan ruang") { freeSpace() }
        val leftCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tileClean.view, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(63)).apply { bottomMargin = dp(4) })
            addView(tileSpace.view, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(63)).apply { topMargin = dp(4) })
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(leftCol, lp(dp(82), dp(134)))
            addView(buildStatsCard(), lp(0, dp(134), 1f).apply { leftMargin = dp(8) })
        }, margins(4))

        // Baris ikon dalam satu wadah
        tileDnd = flatTile(Glyph.DND, "Jangan ganggu") { toggleDnd() }
        tileShot = flatTile(Glyph.SHOT, "Screen shot") { takeScreenshot() }
        tileRec = flatTile(Glyph.REC, "Rekam") { toggleRecord() }
        tileSettings = flatTile(Glyph.GEAR, "Setelan") { openApp() }
        tileRestore = flatTile(Glyph.RESTORE, "Pulihkan layar") { recoverScreen() }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = cutBg(TILE_BG, TILE_STROKE, 8, tl = true, br = true)
            listOf(tileDnd, tileShot, tileRec, tileSettings, tileRestore).forEach {
                addView(it.view, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            }
        }, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })

        // Baris bawah: dua ubin lebar
        tileFrame = wideTile(Glyph.FRAME, "Frame tinggi", "Normal") { toggleFrameLock() }
        tileTimer = wideTile(Glyph.TIMER, "Timer", "Mati") { toggleTimer() }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tileFrame.view, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { rightMargin = dp(4) })
            addView(tileTimer.view, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(4) })
        }, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })

        // Slider pil: cerah dan volume
        sliderBright = PillSlider(this, Glyph.SUN).apply {
            onChange = { p, user ->
                if (user) {
                    lastInteraction = SystemClock.elapsedRealtime()
                    applyBrightness(p.coerceAtLeast(1))
                }
            }
        }
        sliderVol = PillSlider(this, Glyph.SPEAKER).apply {
            onChange = { p, user ->
                if (user) {
                    lastInteraction = SystemClock.elapsedRealtime()
                    setVolume(p)
                }
            }
            onIconTap = { toggleMute() }
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(sliderBright, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { rightMargin = dp(4) })
            addView(sliderVol, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(4) })
        }, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })

        tvFooter = text("Shizuku: -", 10f, DIM).apply {
            setPadding(dp(6), dp(2), 0, 0)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            pressable { openShizukuOrApp() }
        }
        content.addView(tvFooter)

        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
            setOnTouchListener { _, _ ->
                lastInteraction = SystemClock.elapsedRealtime()
                false
            }
        }
        mainBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = cutBg(PANEL_BG, PANEL_STROKE, 12, tr = true, bl = true, br = false)
            addView(scroll, lp(mainWidth(), LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        // Dock jendela mengambang: wadah terpisah di sisi kiri
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        dockScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(dock)
            setOnTouchListener { _, _ ->
                lastInteraction = SystemClock.elapsedRealtime()
                false
            }
        }
        dockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(DOCK_BG, 20, TILE_STROKE)
            addView(dockScroll, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(dockBox, lp(dp(60), dp(200)))
            addView(mainBox, lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        }
    }

    /** Lebar isi panel menyesuaikan layar (jarak ke tepi, dock terpisah, dan padding dihitung). */
    private fun mainWidth(): Int {
        val avail = screenSize().first - dp(PANEL_GAP_DP) - dp(12) - dp(60) - dp(8) - dp(24)
        return avail.coerceIn(dp(230), dp(310))
    }

    /** Pegangan putih tipis yang menempel di tepi layar. */
    private fun styleHandle() {
        handleBar.background = GradientDrawable().apply {
            setColor(WHITE)
            cornerRadii = edgeRadii(dp(3).toFloat())
        }
        val lpBar = handleBar.layoutParams as FrameLayout.LayoutParams
        lpBar.gravity = (if (dockRight) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        handleBar.layoutParams = lpBar
    }

    private fun roundOutline(radiusDp: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
        }
    }

    private fun rebuildDock() {
        dock.removeAllViews()
        GameSettings(this).dockApps.take(6).forEach { pkg ->
            val icon = try {
                packageManager.getApplicationIcon(pkg)
            } catch (e: Exception) {
                null
            } ?: return@forEach
            val iv = ImageView(this).apply {
                setImageDrawable(icon)
                outlineProvider = roundOutline(11)
                clipToOutline = true
                pressable { openFloating(pkg) }
            }
            dock.addView(iv, lp(dp(42), dp(42)).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
        val plus = text("+", 20f, accent, true).apply {
            gravity = Gravity.CENTER
            background = rounded(TILE_BG, 11, TILE_STROKE)
            pressable { openApp() }
        }
        dock.addView(plus, lp(dp(42), dp(42)).apply { setMargins(0, dp(5), 0, dp(5)) })
        if (lastFloating != null) {
            val x = FrameLayout(this).apply {
                background = rounded(Color.argb(60, 255, 77, 94), 11, HOT)
                addView(IconView(this@FloatingPanelService, Glyph.CLOSE).apply { tint = HOT },
                    FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
                pressable { recoverScreen() }
            }
            dock.addView(x, lp(dp(42), dp(42)).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun WindowManager.LayoutParams.useFullScreenArea() {
        // Tanpa ini Android menggeser overlay menjauhi lubang kamera sehingga pegangan tidak menempel di tepi.
        if (Build.VERSION.SDK_INT >= 30) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun overlayFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    @SuppressLint("ClickableViewAccessibility")
    private fun addScrim() {
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN && expanded) toggle()
            true
        }
        scrim = v
        scrimParams = WindowManager.LayoutParams(
            1, 1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }
        wm.addView(v, scrimParams)
    }

    private fun setScrim(active: Boolean) {
        val v = scrim ?: return
        scrimActive = active
        val size = if (active) WindowManager.LayoutParams.MATCH_PARENT else 1
        scrimParams.width = size
        scrimParams.height = size
        scrimParams.flags = if (active) {
            scrimParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            scrimParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, scrimParams)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildOverlay() {
        homePkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName

        val gs = GameSettings(this)
        dockRight = gs.panelRight

        handleBar = View(this)
        handle = FrameLayout(this).apply {
            addView(handleBar, FrameLayout.LayoutParams(dp(5), dp(72), Gravity.START or Gravity.CENTER_VERTICAL))
            setOnTouchListener(dragListener)
        }
        panel = buildPanel()
        styleHandle()

        addScrim() // pertama: berada paling bawah

        val (_, sh) = screenSize()
        handleParams = WindowManager.LayoutParams(
            dp(HANDLE_W_DP), dp(96), overlayType(), overlayFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (gs.panelYFraction * sh).toInt()
            useFullScreenArea()
        }
        wm.addView(handle, handleParams)
        handleAdded = true
        positionHandle()

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), overlayFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }
        syncModeButtons()
    }

    /** Pegangan selalu di tepi layar dan tidak ikut bergeser saat panel dibuka. */
    private fun positionHandle() {
        if (!handleAdded) return
        val (sw, sh) = screenSize()
        val m = dp(12)
        handleParams.x = if (dockRight) sw - dp(HANDLE_W_DP) else 0
        handleParams.y = handleParams.y.coerceIn(m, max(m, sh - dp(96) - m))
        try {
            wm.updateViewLayout(handle, handleParams)
        } catch (_: Exception) {
        }
    }

    private fun limitPanelHeight() {
        val w = mainWidth()
        content.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val limit = screenSize().second - dp(72)
        val h = min(content.measuredHeight, limit)
        val lpScroll = scroll.layoutParams
        lpScroll.width = w
        lpScroll.height = h
        scroll.layoutParams = lpScroll
        val lpDock = dockBox.layoutParams
        lpDock.height = h + dp(24)
        dockBox.layoutParams = lpDock
    }

    private fun slideOffset(): Float = if (dockRight) dp(24).toFloat() else -dp(24).toFloat()

    private fun toggle() {
        expanded = !expanded
        lastInteraction = SystemClock.elapsedRealtime()
        if (expanded) showPanel() else hidePanel()
    }

    private fun showPanel() {
        rebuildDock()
        syncModeButtons()
        syncTiles()
        syncSliders()
        warnedBrightness = false
        tickCount = 0
        limitPanelHeight()
        scroll.scrollTo(0, 0)
        dockScroll.scrollTo(0, 0)
        val (sw, sh) = screenSize()
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST)
        )
        val pw = panel.measuredWidth
        val ph = panel.measuredHeight
        val m = dp(12)
        panelParams.x = if (dockRight) sw - dp(PANEL_GAP_DP) - pw else dp(PANEL_GAP_DP)
        val centerY = handleParams.y + dp(48)
        panelParams.y = (centerY - ph / 2).coerceIn(m, max(m, sh - ph - m))
        panel.animate().cancel()
        if (!panelAttached) {
            try {
                wm.addView(panel, panelParams)
                panelAttached = true
            } catch (_: Exception) {
                expanded = false
                return
            }
        } else {
            try {
                wm.updateViewLayout(panel, panelParams)
            } catch (_: Exception) {
            }
        }
        panel.alpha = 0f
        panel.translationX = slideOffset()
        panel.animate().alpha(1f).translationX(0f).setDuration(170).start()
        setScrim(true)
        tick()
    }

    private fun hidePanel() {
        setScrim(false)
        panel.animate().cancel()
        panel.animate().alpha(0f).translationX(slideOffset()).setDuration(130).withEndAction {
            if (!expanded && panelAttached) {
                removeSafely(panel)
                panelAttached = false
            }
        }.start()
    }

    private val dragListener = object : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop by lazy { ViewConfiguration.get(this@FloatingPanelService).scaledTouchSlop }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = handleParams.x
                    startY = handleParams.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                        dragging = true
                        if (expanded) toggle()
                    }
                    if (dragging) {
                        val (sw, sh) = screenSize()
                        val m = dp(12)
                        handleParams.x = (startX + dx).toInt().coerceIn(0, max(0, sw - dp(HANDLE_W_DP)))
                        handleParams.y = (startY + dy).toInt().coerceIn(m, max(m, sh - dp(96) - m))
                        try {
                            wm.updateViewLayout(handle, handleParams)
                        } catch (_: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        val (sw, sh) = screenSize()
                        val right = handleParams.x + dp(HANDLE_W_DP) / 2 > sw / 2
                        if (right != dockRight) {
                            dockRight = right
                            styleHandle()
                        }
                        positionHandle()
                        val gs = GameSettings(this@FloatingPanelService)
                        gs.panelRight = dockRight
                        gs.panelYFraction = handleParams.y.toFloat() / sh
                    } else {
                        v.performClick()
                        toggle()
                    }
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------ data berkala

    private fun levelColor(level: TempLevel): Int = when (level) {
        TempLevel.NORMAL -> OK
        TempLevel.WARM -> WARN
        TempLevel.HIGH -> HOT
        TempLevel.UNKNOWN -> DIM
    }

    private fun fpsColor(fps: Int?): Int = if (fps == null) DIM else accent

    private fun setFpsText(view: TextView, fps: Int?) {
        val s = if (fps == null) "-- FPS" else "$fps FPS"
        val sp = SpannableString(s)
        sp.setSpan(RelativeSizeSpan(0.6f), s.length - 3, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        view.text = sp
        view.setTextColor(fpsColor(fps))
    }

    /** Angka FPS berubah dengan hitung naik/turun halus. */
    private fun showFps(target: Int?) {
        fpsAnim?.cancel()
        if (target == null) {
            fpsShown = null
            setFpsText(tvFps, null)
            return
        }
        val from = fpsShown ?: target
        if (from == target) {
            fpsShown = target
            setFpsText(tvFps, target)
            return
        }
        fpsAnim = ValueAnimator.ofInt(from, target).apply {
            duration = 350
            addUpdateListener {
                val x = it.animatedValue as Int
                fpsShown = x
                setFpsText(tvFps, x)
            }
            start()
        }
    }

    private fun currentAvgFps(): Int? =
        if (fpsHistory.isEmpty()) null else fpsHistory.takeLast(10).average().toInt()

    private fun tick() {
        if (!handleAdded) return
        val now = SystemClock.elapsedRealtime()
        // Sembunyikan di layar kunci.
        val locked = try {
            (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
        } catch (e: Exception) {
            false
        }
        if (locked) {
            if (expanded) toggle()
            handle.visibility = View.GONE
            return
        } else if (handle.visibility != View.VISIBLE) {
            handle.visibility = View.VISIBLE
        }
        // Pengaman: lapisan penutup tidak boleh aktif saat panel tertutup.
        if (!expanded && scrimActive) setScrim(false)
        // Tutup otomatis bila tidak disentuh 40 detik.
        if (expanded && now - lastInteraction > 40_000L) {
            toggle()
            return
        }
        if (!expanded) return

        lastTemp = TemperatureMonitor(this).read()
        syncTiles()
        syncSliders()
        if (!busy.compareAndSet(false, true)) return
        val idx = tickCount++
        executor.execute {
            try {
                if (idx % 3 == 0) {
                    val monitor = NetworkMonitor(this)
                    lastNet = monitor.status()
                    lastPing = monitor.pingMs()
                }
                var fps: Int? = null
                var note: String
                val shizuku = ShizukuHelper.hasPermission()
                if (shizuku && !ShellTools.hasDump(this) && idx % 10 == 1) {
                    ShellTools.ensureSelfPermissions(this)
                }
                if (ShellTools.canRead()) {
                    if (idx % 4 == 0) {
                        val fg = ShellTools.foregroundPackage()
                        val ignore = fg == null || fg == packageName || fg == homePkg ||
                            fg.startsWith("com.android.systemui")
                        if (fg != null && fg == lastFloating) {
                            // jendela mengambang di depan: pertahankan game sebelumnya
                        } else {
                            gamePkg = if (ignore) null else fg
                        }
                    }
                    val g = gamePkg
                    if (g != null) {
                        val gsx = GameSettings(this)
                        if (gsx.lastGamePkg != g) gsx.lastGamePkg = g
                        val r = ShellTools.measureFps(g)
                        fps = r.fps
                        if (r.fps == null && idx % 12 == 6) gsx.fpsDiag = ShellTools.fpsDiagnostics(this, g)
                        note = if (r.fps != null) "" else "FPS N/A: ${r.note}"
                    } else {
                        note = "Buka game untuk melihat FPS"
                    }
                } else {
                    gamePkg = null
                    note = if (!ShizukuHelper.isRunning()) {
                        "Shizuku mati (ADB nirkabel terputus). Ketuk teks paling bawah untuk memulai ulang."
                    } else {
                        "FPS butuh izin Shizuku (atur di AISZ > Atur)"
                    }
                }
                val footer = when {
                    shizuku -> "Shizuku aktif" + (gamePkg?.let { "  •  $it" } ?: "")
                    ShellTools.canRead() -> "Shizuku mati  •  FPS lewat izin mandiri"
                    else -> "Shizuku mati - ketuk untuk membuka Shizuku"
                }
                handler.post {
                    if (handleAdded) bindStats(fps, footer, note)
                }
            } finally {
                busy.set(false)
            }
        }
    }

    private fun bindStats(fps: Int?, footer: String, note: String) {
        val net = lastNet
        val t = lastTemp
        val netText = when {
            net == null -> "WLAN"
            net.transport == "WLAN" -> buildString {
                append("WLAN")
                if (net.rssiDbm != null) append(" ${net.rssiDbm} dBm")
                if (net.linkMbps != null) append(" ${net.linkMbps} Mbps")
            }
            else -> net.transport
        }
        val pingText = lastPing?.let { "$it ms" } ?: "-- ms"
        val tempText = if (t?.batteryC == null) "N/A" else String.format("%.0f °C", t.batteryC)
        tvSub.text = "$netText   $pingText   $tempText"
        showFps(fps)
        setFpsText(tvFpsBefore, fpsBefore)
        tvFpsBefore.setTextColor(if (fpsBefore == null) DIM else TEXT)
        tvFpsNote.text = note
        if (fps != null) {
            fpsHistory.add(fps.toFloat())
            if (fpsHistory.size > 40) fpsHistory.removeAt(0)
        }
        graph.setValues(fpsHistory.toList(), 60f)
        tvFooter.text = footer
    }

    private fun applyAccent() {
        accent = when (GameSettings(this).profile) {
            GamingProfile.HEMAT -> C_GREEN
            GamingProfile.SEIMBANG -> C_BLUE
            GamingProfile.PERFORMA -> C_RED
        }
        accentDim = withAlpha(accent, 0.6f)
        ring.accent = accent
        graph.setAccent(accent)
        tvModeTag.setTextColor(accent)
        modeMark.background = rounded(accent, 4)
        dots.forEach { it.background = circle(Color.TRANSPARENT, accent) }
        statsCard.background = cutBg(TILE_BG, accentDim, 10)
        btnStop.setTextColor(accent)
        btnStop.background = cutBg(withAlpha(accent, 0.2f), accent, 6)
        setFpsText(tvFps, fpsShown)
    }

    private fun syncModeButtons() {
        val current = GameSettings(this).profile
        tvModeTag.text = current.label
        btnStop.text = if (current == GamingProfile.SEIMBANG) "Aktifkan Performa" else "Hentikan"
        applyAccent()
    }

    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)

    private fun dndOn(): Boolean {
        val f = nm().currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL &&
            f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    private fun syncTiles() {
        if (!handleAdded) return
        val rec = ScreenRecorderService.isRecording
        tileRec.title.text = if (rec) "Berhenti" else "Rekam"
        setTileActive(tileRec, rec, HOT)
        setTileActive(tileDnd, dndOn())
        setTileActive(tileShot, false)
        setTileActive(tileSettings, false)
        setTileActive(tileRestore, false)
        setTileActive(tileClean, false)
        setTileActive(tileSpace, false)
        val locked = GameSettings(this).frameLock
        tileFrame.sub?.text = if (locked) "Terkunci" else "Normal"
        setTileActive(tileFrame, locked)
        val left = if (timerEndAt > 0L) (timerEndAt - SystemClock.elapsedRealtime()) / 1000L else 0L
        tileTimer.sub?.text = if (left > 0L) String.format(Locale.US, "Sisa %d:%02d", left / 60, left % 60) else "Mati"
        setTileActive(tileTimer, left > 0L)
    }

    private fun audio(): AudioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun syncSliders() {
        if (!handleAdded) return
        sliderBright.setProgressSilently(GameSettings(this).getBrightnessPercent())
        val am = audio()
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val p = if (mx > 0) am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / mx else 0
        sliderVol.setProgressSilently(p)
        sliderVol.setGlyph(if (p == 0) Glyph.SPEAKER_OFF else Glyph.SPEAKER)
    }

    // ------------------------------------------------------------ aksi

    private fun openApp() {
        if (expanded) toggle()
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    /** Shizuku mati: buka aplikasi Shizuku agar bisa dimulai ulang dengan sekali ketuk. */
    private fun openShizukuOrApp() {
        if (expanded) toggle()
        val i = if (ShizukuHelper.isInstalled(this) && !ShizukuHelper.isRunning()) {
            packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE)
        } else {
            null
        }
        if (i != null) {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            openApp()
        }
    }

    private fun setVolume(percent: Int) {
        try {
            val am = audio()
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent * mx / 100.0).roundToInt(), 0)
            sliderVol.setGlyph(if (percent == 0) Glyph.SPEAKER_OFF else Glyph.SPEAKER)
        } catch (e: SecurityException) {
            toast("Tidak dapat mengubah volume.")
        }
    }

    private fun toggleMute() {
        try {
            audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
        } catch (_: SecurityException) {
        }
        handler.postDelayed({ syncSliders() }, 150L)
    }

    private fun applyBrightness(percent: Int) {
        val gs = GameSettings(this)
        if (gs.canWriteSystemSettings()) {
            gs.setBrightnessPercent(percent)
        } else if (ShizukuHelper.hasPermission()) {
            executor.execute { ShellTools.setBrightness(percent * 255 / 100) }
        } else if (!warnedBrightness) {
            warnedBrightness = true
            toast("Kecerahan butuh izin \"Ubah pengaturan sistem\" atau Shizuku (atur di AISZ > Atur).")
        }
    }

    /** Chip mode: Hemat daya -> Seimbang -> Performa -> Hemat daya. */
    private fun cycleMode() {
        val all = GamingProfile.values()
        val cur = GameSettings(this).profile
        selectMode(all[(cur.ordinal + 1) % all.size])
    }

    /** Hentikan = kembali ke Seimbang; saat sudah Seimbang, tombol mengaktifkan Performa. */
    private fun stopOrBoost() {
        val cur = GameSettings(this).profile
        selectMode(if (cur == GamingProfile.SEIMBANG) GamingProfile.PERFORMA else GamingProfile.SEIMBANG)
    }

    /** Mode benar-benar diterapkan ke HP; cincin di judul menunjukkan kemajuannya. */
    private fun selectMode(p: GamingProfile) {
        fpsBefore = currentAvgFps()
        GameSettings(this).profile = p
        syncModeButtons()
        ring.start()
        ModeController.applyAsync(this, p, gamePkg, { f -> ring.setProgress(f) }) { msg ->
            ring.finish("OK", true)
            toast(msg)
        }
    }

    private fun cleanMemory() {
        ring.start()
        toast("Membersihkan memori...")
        executor.execute {
            val pm = PerformanceMonitor(this)
            val freed = ModeController.cleanBackground(this, setOf(gamePkg, lastFloating, homePkg)) { f ->
                handler.post { ring.setProgress(f) }
            }
            val after = pm.memory().availMb
            handler.post {
                ring.finish(if (freed > 0) "+${freed}M" else "OK", true)
                toast(if (freed > 0) "Memori bebas +$freed MB (sekarang $after MB)" else "Memori sudah bersih ($after MB bebas)")
            }
        }
    }

    private fun freeSpace() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Bebaskan ruang butuh Shizuku. Membuka pengaturan penyimpanan.")
            try {
                startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
            return
        }
        ring.start()
        toast("Mengosongkan cache aplikasi...")
        slowExecutor.execute {
            val before = StatFs(Environment.getDataDirectory().path).availableBytes
            val r = ShizukuHelper.exec("pm trim-caches 8G")
            val after = StatFs(Environment.getDataDirectory().path).availableBytes
            val freed = max((after - before) / (1024L * 1024L), 0L)
            handler.post {
                if (r.ok || freed > 0) {
                    ring.finish("+${freed}M", true)
                    toast("Ruang bebas +$freed MB")
                } else {
                    ring.finish("!", false)
                    toast("Gagal: ${r.error.ifBlank { r.output }.take(60)}")
                }
            }
        }
    }

    private fun takeScreenshot() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Screenshot butuh Shizuku. Pakai tombol bawaan HP.")
            return
        }
        if (expanded) toggle()
        val name = "AISZ_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        handler.postDelayed({
            slowExecutor.execute {
                val dir = "/sdcard/Pictures/AISZ"
                val r = ShizukuHelper.exec("mkdir -p $dir && screencap -p $dir/$name")
                if (r.ok) {
                    ShizukuHelper.exec("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$dir/$name")
                }
                handler.post {
                    toast(if (r.ok) "Screenshot tersimpan di Pictures/AISZ" else "Gagal screenshot: ${r.error.ifBlank { r.output }.take(60)}")
                }
            }
        }, 500L)
    }

    private fun toggleRecord() {
        if (ScreenRecorderService.isRecording) {
            startService(Intent(this, ScreenRecorderService::class.java).setAction(ScreenRecorderService.ACTION_STOP))
        } else {
            if (expanded) toggle() // sembunyikan panel agar tidak ikut terekam
            startActivity(Intent(this, RecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun toggleFrameLock() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Frame tinggi butuh Shizuku (atur di AISZ > Atur).")
            return
        }
        val gs = GameSettings(this)
        val target = !gs.frameLock
        executor.execute {
            val r = if (target) ShellTools.lockRefreshRate(ShellTools.maxRefreshRate(this)) else ShellTools.unlockRefreshRate()
            handler.post {
                if (r.ok) {
                    gs.frameLock = target
                    syncTiles()
                    toast(if (target) "Refresh rate dikunci ke maksimum" else "Refresh rate dikembalikan")
                } else {
                    toast("Gagal: ${r.error.ifBlank { r.output }}")
                }
            }
        }
    }

    private fun toggleDnd() {
        if (!nm().isNotificationPolicyAccessGranted) {
            toast("Beri izin akses Jangan Ganggu dulu.")
            try {
                startActivity(
                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
            return
        }
        nm().setInterruptionFilter(
            if (dndOn()) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        syncTiles()
    }

    /** Timer bermain: Mati -> 30 -> 60 -> 90 menit -> Mati. Berbunyi (getar + notifikasi) saat habis. */
    private fun toggleTimer() {
        val options = listOf(0, 30, 60, 90)
        val next = options[(options.indexOf(timerMinutes) + 1) % options.size]
        handler.removeCallbacks(timerDone)
        timerMinutes = next
        if (next == 0) {
            timerEndAt = 0L
            toast("Timer dimatikan")
        } else {
            timerEndAt = SystemClock.elapsedRealtime() + next * 60_000L
            handler.postDelayed(timerDone, next * 60_000L)
            toast("Timer $next menit dimulai")
        }
        syncTiles()
    }

    private fun onTimerDone() {
        timerMinutes = 0
        timerEndAt = 0L
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(700)
            }
        } catch (_: Exception) {
        }
        val n = NotificationCompat.Builder(this, TIMER_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("Waktu bermain habis")
            .setContentText("Timer AISZ GAME SPACE selesai.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            nm().notify(2001, n)
        } catch (_: Exception) {
        }
        toast("Waktu bermain habis")
        if (handleAdded) syncTiles()
    }

    private fun openFloating(pkg: String) {
        if (expanded) toggle()
        gameBeforeFloat = gamePkg
        executor.execute {
            if (ShizukuHelper.hasPermission()) {
                val r = ShellTools.launchFreeform(this, pkg)
                if (r.ok) {
                    lastFloating = pkg
                    return@execute
                }
                handler.post { toast("Jendela mengambang tidak didukung ROM ini, dibuka biasa.") }
            } else {
                handler.post { toast("Jendela mengambang butuh Shizuku, dibuka biasa.") }
            }
            handler.post { GameLauncher(this).launch(pkg, applyProfile = false) }
        }
    }

    /** Pemulihan: tutup aplikasi jendela mengambang terakhir dan kembalikan game ke layar penuh. */
    private fun recoverScreen() {
        val floating = lastFloating
        val game = gameBeforeFloat ?: gamePkg
        if (expanded) toggle()
        executor.execute {
            if (ShizukuHelper.hasPermission()) {
                if (floating != null) ShellTools.forceStop(floating)
                if (game != null) ShellTools.bringFullscreen(this, game)
                lastFloating = null
                handler.post { toast("Layar dipulihkan") }
            } else {
                handler.post { toast("Pulihkan layar butuh Shizuku aktif.") }
            }
        }
    }

    companion object {
        const val ACTION_STOP = "com.aisz.gamespace.action.STOP_PANEL"
        private const val CHANNEL_ID = "aisz_panel"
        private const val TIMER_CHANNEL = "aisz_timer"
        private const val NOTIF_ID = 1001
        private const val HANDLE_W_DP = 22
        private const val PANEL_GAP_DP = 36

        private val TITLE = Color.parseColor("#43A8F0")
        private val TEXT = Color.parseColor("#EDEFF2")
        private val DIM = Color.parseColor("#8C94A3")
        private val ICON = Color.parseColor("#C9CED8")
        private val TILE_BG = Color.parseColor("#0F141C")
        private val TILE_ON = Color.parseColor("#232610")
        private val TILE_STROKE = Color.parseColor("#4A5260")
        private val PANEL_BG = Color.parseColor("#F40C1118")
        private val PANEL_STROKE = Color.parseColor("#3A4252")
        private val DOCK_BG = Color.parseColor("#F40E131A")
        private val HUD_BG = Color.parseColor("#F00C1118")
        private val WHITE = Color.parseColor("#F2FFFFFF")
        private val OK = Color.parseColor("#2BE38B")
        private val WARN = Color.parseColor("#FFB020")
        private val HOT = Color.parseColor("#FF4D5E")

        @Volatile
        private var instance: FloatingPanelService? = null

        /** Menampilkan pesan lewat panel (terlihat di dalam game). False bila panel tidak aktif. */
        fun announce(msg: String): Boolean {
            val i = instance ?: return false
            i.showHud(msg)
            return true
        }

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingPanelService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingPanelService::class.java))
        }
    }
}
