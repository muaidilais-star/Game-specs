package com.aisz.gamespace

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// Palet panel (mengikuti gaya Game Turbo): gelap, aksen kuning-olive, judul biru
private val C_ACC = Color.parseColor("#D8DB3A")
private val C_ACC_DIM = Color.parseColor("#8E9124")
private val C_HOT = Color.parseColor("#FF4D5E")
private val C_DIM = Color.parseColor("#8C94A3")
// Warna per mode (lembut, tidak ngejreng)
private val C_GREEN = Color.parseColor("#5CBF8A")
private val C_BLUE = Color.parseColor("#5B9BE0")
private val C_RED = Color.parseColor("#E0605E")

/** Ikon sederhana digambar dengan kanvas (tanpa file gambar, tanpa risiko resource). */
enum class Glyph {
    BOLT, TRASH, SHOT, REC, DND, GEAR, TIMER, FRAME, CLOSE, SUN, SPEAKER, SPEAKER_OFF, RESTORE,
    BACK, GRID, CROSSHAIR, MONITOR, CHIP, GPU, BATTERY, THERMO, RAM, PING, MOVE, CHECK, OPACITY, MIC, WINDOW, TAP, TEXTURE, NOTE
}

/** Menggambar ikon pada kisi 24x24 (kanvas sudah di-translate dan di-scale oleh pemanggil). */
internal fun drawGlyph(c: Canvas, glyph: Glyph, p: Paint, path: Path) {
    path.reset()
    when (glyph) {
        Glyph.BOLT -> {
            path.moveTo(13f, 2f); path.lineTo(5f, 13f); path.lineTo(11f, 13f)
            path.lineTo(10f, 22f); path.lineTo(19f, 10f); path.lineTo(13f, 10f); path.close()
            c.drawPath(path, p)
        }
        Glyph.TRASH -> {
            c.drawLine(4f, 6f, 20f, 6f, p)
            path.moveTo(9f, 6f); path.lineTo(9f, 3.5f); path.lineTo(15f, 3.5f); path.lineTo(15f, 6f)
            c.drawPath(path, p)
            path.reset()
            path.moveTo(6f, 6f); path.lineTo(7f, 20f); path.lineTo(17f, 20f); path.lineTo(18f, 6f)
            c.drawPath(path, p)
            c.drawLine(10f, 10f, 10f, 17f, p)
            c.drawLine(14f, 10f, 14f, 17f, p)
        }
        Glyph.SHOT -> {
            path.moveTo(4f, 9f); path.lineTo(4f, 4f); path.lineTo(9f, 4f)
            path.moveTo(15f, 4f); path.lineTo(20f, 4f); path.lineTo(20f, 9f)
            path.moveTo(20f, 15f); path.lineTo(20f, 20f); path.lineTo(15f, 20f)
            path.moveTo(9f, 20f); path.lineTo(4f, 20f); path.lineTo(4f, 15f)
            c.drawPath(path, p)
            c.drawCircle(12f, 12f, 3f, p)
        }
        Glyph.REC -> {
            c.drawRoundRect(RectF(3f, 6f, 15f, 18f), 2f, 2f, p)
            path.moveTo(15f, 10f); path.lineTo(21f, 7f); path.lineTo(21f, 17f); path.lineTo(15f, 14f)
            c.drawPath(path, p)
        }
        Glyph.DND -> {
            c.drawCircle(12f, 12f, 9f, p)
            c.drawLine(7f, 12f, 17f, 12f, p)
        }
        Glyph.GEAR -> {
            c.drawCircle(12f, 12f, 3.5f, p)
            c.drawCircle(12f, 12f, 7f, p)
            for (k in 0 until 8) {
                val a = k * Math.PI / 4.0
                c.drawLine(
                    12f + 7f * cos(a).toFloat(), 12f + 7f * sin(a).toFloat(),
                    12f + 9.8f * cos(a).toFloat(), 12f + 9.8f * sin(a).toFloat(), p
                )
            }
        }
        Glyph.TIMER -> {
            c.drawLine(6f, 3f, 18f, 3f, p)
            c.drawLine(6f, 21f, 18f, 21f, p)
            path.moveTo(7f, 3f); path.lineTo(7f, 7f); path.lineTo(12f, 12f); path.lineTo(17f, 7f); path.lineTo(17f, 3f)
            path.moveTo(7f, 21f); path.lineTo(7f, 17f); path.lineTo(12f, 12f); path.lineTo(17f, 17f); path.lineTo(17f, 21f)
            c.drawPath(path, p)
        }
        Glyph.FRAME -> {
            c.drawArc(RectF(3f, 5f, 21f, 23f), 180f, 180f, false, p)
            c.drawLine(12f, 14f, 17f, 9f, p)
            c.drawCircle(12f, 14f, 1.2f, p)
        }
        Glyph.CLOSE -> {
            c.drawLine(6f, 6f, 18f, 18f, p)
            c.drawLine(18f, 6f, 6f, 18f, p)
        }
        Glyph.RESTORE -> {
            c.drawArc(RectF(4f, 4f, 20f, 20f), 40f, 280f, false, p)
            path.moveTo(20f, 4f); path.lineTo(20f, 9f); path.lineTo(15f, 9f)
            c.drawPath(path, p)
        }
        Glyph.SUN -> {
            c.drawCircle(12f, 12f, 4f, p)
            for (k in 0 until 8) {
                val a = k * Math.PI / 4.0
                c.drawLine(
                    12f + 6.8f * cos(a).toFloat(), 12f + 6.8f * sin(a).toFloat(),
                    12f + 9.6f * cos(a).toFloat(), 12f + 9.6f * sin(a).toFloat(), p
                )
            }
        }
        Glyph.TEXTURE -> {
            c.drawRect(3f, 3f, 11f, 11f, p)
            c.drawRect(13f, 3f, 21f, 11f, p)
            c.drawRect(3f, 13f, 11f, 21f, p)
            c.drawRect(13f, 13f, 21f, 21f, p)
        }
        Glyph.NOTE -> {
            c.drawCircle(8f, 18f, 3.2f, p)
            c.drawLine(11.2f, 18f, 11.2f, 5f, p)
            c.drawLine(11.2f, 5f, 18f, 7.5f, p)
            c.drawLine(18f, 7.5f, 18f, 10.5f, p)
        }
        Glyph.TAP -> {
            c.drawCircle(12f, 12f, 2f, p)
            c.drawCircle(12f, 12f, 6f, p)
            c.drawCircle(12f, 12f, 10f, p)
        }
        Glyph.MIC -> {
            c.drawRoundRect(RectF(9f, 3f, 15f, 13f), 3f, 3f, p)
            c.drawArc(RectF(6f, 7f, 18f, 17f), 0f, 180f, false, p)
            c.drawLine(12f, 17f, 12f, 21f, p)
            c.drawLine(9f, 21f, 15f, 21f, p)
        }
        Glyph.WINDOW -> {
            c.drawRoundRect(RectF(3f, 5f, 21f, 19f), 2f, 2f, p)
            c.drawLine(3f, 9f, 21f, 9f, p)
            path.moveTo(16f, 17f); path.lineTo(19f, 14f); path.lineTo(19f, 17f); path.close()
            c.drawPath(path, p)
        }
        Glyph.BACK -> {
            path.moveTo(15f, 5f); path.lineTo(8f, 12f); path.lineTo(15f, 19f)
            c.drawPath(path, p)
        }
        Glyph.GRID -> {
            c.drawRoundRect(RectF(4f, 4f, 10f, 10f), 1.5f, 1.5f, p)
            c.drawRoundRect(RectF(14f, 4f, 20f, 10f), 1.5f, 1.5f, p)
            c.drawRoundRect(RectF(4f, 14f, 10f, 20f), 1.5f, 1.5f, p)
            c.drawRoundRect(RectF(14f, 14f, 20f, 20f), 1.5f, 1.5f, p)
        }
        Glyph.CROSSHAIR -> {
            c.drawCircle(12f, 12f, 6f, p)
            c.drawLine(12f, 2f, 12f, 7f, p)
            c.drawLine(12f, 17f, 12f, 22f, p)
            c.drawLine(2f, 12f, 7f, 12f, p)
            c.drawLine(17f, 12f, 22f, 12f, p)
            c.drawCircle(12f, 12f, 0.8f, p)
        }
        Glyph.MONITOR -> {
            c.drawRoundRect(RectF(3f, 4f, 21f, 18f), 2f, 2f, p)
            path.moveTo(6f, 14f); path.lineTo(10f, 10f); path.lineTo(13f, 13f); path.lineTo(18f, 8f)
            c.drawPath(path, p)
            c.drawLine(9f, 21f, 15f, 21f, p)
        }
        Glyph.CHIP -> {
            c.drawRoundRect(RectF(7f, 7f, 17f, 17f), 1.5f, 1.5f, p)
            for (x in listOf(9.5f, 12f, 14.5f)) {
                c.drawLine(x, 3f, x, 7f, p)
                c.drawLine(x, 17f, x, 21f, p)
            }
            for (y in listOf(9.5f, 12f, 14.5f)) {
                c.drawLine(3f, y, 7f, y, p)
                c.drawLine(17f, y, 21f, y, p)
            }
        }
        Glyph.GPU -> {
            c.drawRoundRect(RectF(3f, 6f, 21f, 16f), 2f, 2f, p)
            c.drawCircle(10f, 11f, 3f, p)
            c.drawLine(15f, 9f, 18f, 9f, p)
            c.drawLine(15f, 13f, 18f, 13f, p)
            c.drawLine(5f, 19f, 19f, 19f, p)
        }
        Glyph.BATTERY -> {
            c.drawRoundRect(RectF(3f, 7f, 19f, 17f), 2f, 2f, p)
            c.drawLine(21f, 10f, 21f, 14f, p)
            path.moveTo(11.5f, 9f); path.lineTo(8.5f, 12.5f); path.lineTo(12f, 12.5f); path.lineTo(10f, 15.5f)
            c.drawPath(path, p)
        }
        Glyph.THERMO -> {
            c.drawRoundRect(RectF(10f, 3f, 14f, 15f), 2f, 2f, p)
            c.drawCircle(12f, 17.5f, 3.5f, p)
            c.drawLine(12f, 8f, 12f, 15f, p)
        }
        Glyph.RAM -> {
            c.drawRoundRect(RectF(2f, 6f, 22f, 16f), 2f, 2f, p)
            for (x in listOf(6f, 10f, 14f, 18f)) c.drawLine(x, 16f, x, 19f, p)
            c.drawRect(RectF(5f, 9f, 9f, 13f), p)
            c.drawRect(RectF(11f, 9f, 15f, 13f), p)
        }
        Glyph.PING -> {
            for (r in listOf(10f, 6.5f, 3.2f)) c.drawArc(RectF(12f - r, 18f - r, 12f + r, 18f + r), 225f, 90f, false, p)
            c.drawCircle(12f, 18f, 1f, p)
        }
        Glyph.MOVE -> {
            c.drawLine(12f, 3f, 12f, 21f, p)
            c.drawLine(3f, 12f, 21f, 12f, p)
            path.moveTo(9f, 6f); path.lineTo(12f, 3f); path.lineTo(15f, 6f)
            path.moveTo(9f, 18f); path.lineTo(12f, 21f); path.lineTo(15f, 18f)
            path.moveTo(6f, 9f); path.lineTo(3f, 12f); path.lineTo(6f, 15f)
            path.moveTo(18f, 9f); path.lineTo(21f, 12f); path.lineTo(18f, 15f)
            c.drawPath(path, p)
        }
        Glyph.CHECK -> {
            path.moveTo(5f, 12.5f); path.lineTo(10f, 17.5f); path.lineTo(19f, 7f)
            c.drawPath(path, p)
        }
        Glyph.OPACITY -> {
            c.drawCircle(12f, 12f, 8f, p)
            c.drawLine(8f, 8f, 8f, 16f, p)
            c.drawLine(10f, 6.5f, 10f, 17.5f, p)
            c.drawLine(12f, 4f, 12f, 20f, p)
        }
        Glyph.SPEAKER, Glyph.SPEAKER_OFF -> {
            path.moveTo(4f, 9.5f); path.lineTo(8f, 9.5f); path.lineTo(13f, 5f)
            path.lineTo(13f, 19f); path.lineTo(8f, 14.5f); path.lineTo(4f, 14.5f); path.close()
            c.drawPath(path, p)
            if (glyph == Glyph.SPEAKER) {
                c.drawArc(RectF(10f, 8f, 18f, 16f), -50f, 100f, false, p)
                c.drawArc(RectF(8f, 5f, 21f, 19f), -50f, 100f, false, p)
            } else {
                c.drawLine(16f, 9f, 21f, 15f, p)
                c.drawLine(21f, 9f, 16f, 15f, p)
            }
        }
    }
}

class IconView(context: Context, private val glyph: Glyph) : View(context) {
    var tint: Int = Color.parseColor("#C9CED8")
        set(value) {
            field = value
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        c.scale(s / 24f, s / 24f)
        p.color = tint
        drawGlyph(c, glyph, p, path)
        c.restore()
    }
}

/** Latar persegi dengan sudut terpotong (gaya HUD). */
class CutDrawable(
    fill: Int,
    stroke: Int,
    private val cut: Float,
    private val strokePx: Float,
    private val tl: Boolean = false,
    private val tr: Boolean = false,
    private val br: Boolean = false,
    private val bl: Boolean = false
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = fill
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokePx
        color = stroke
        strokeJoin = Paint.Join.MITER
    }
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val h = strokePx / 2f
        val l = bounds.left + h
        val t = bounds.top + h
        val r = bounds.right - h
        val b = bounds.bottom - h
        val c = cut
        path.reset()
        if (tl) { path.moveTo(l, t + c); path.lineTo(l + c, t) } else path.moveTo(l, t)
        if (tr) { path.lineTo(r - c, t); path.lineTo(r, t + c) } else path.lineTo(r, t)
        if (br) { path.lineTo(r, b - c); path.lineTo(r - c, b) } else path.lineTo(r, b)
        if (bl) { path.lineTo(l + c, b); path.lineTo(l, b - c) } else path.lineTo(l, b)
        path.close()
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, strokePaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        strokePaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Grafik area FPS bergaya Game Turbo: sumbu 0..puncak, isian kuning, bergeser halus tiap sampel baru. */
class MiniGraph(context: Context) : View(context) {
    private var values: List<Float> = emptyList()
    private var minTop = 60f
    private var slide = 0f
    private var accent = C_BLUE
    private var shaderH = 0f
    private var anim: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.8f * d
        color = C_ACC
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply {
        color = Color.parseColor("#33FFFFFF")
        strokeWidth = 1f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = C_DIM
        textSize = 8f * d
        textAlign = Paint.Align.LEFT
    }
    private val plot = RectF()

    fun setValues(v: List<Float>, minCeiling: Float) {
        val appended = v.size > values.size && v.size > 1
        values = v
        minTop = minCeiling
        anim?.cancel()
        if (appended) {
            anim = ValueAnimator.ofFloat(1f, 0f).apply {
                duration = 600
                interpolator = LinearInterpolator()
                addUpdateListener {
                    slide = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            slide = 0f
            invalidate()
        }
    }

    private fun rebuildShader() {
        if (shaderH <= 0f) return
        fill.shader = LinearGradient(
            0f, 0f, 0f, shaderH,
            Color.argb(210, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Color.argb(10, Color.red(accent), Color.green(accent), Color.blue(accent)), Shader.TileMode.CLAMP
        )
    }

    fun setAccent(c: Int) {
        accent = c
        line.color = c
        rebuildShader()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        shaderH = h.toFloat()
        rebuildShader()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val lm = 22f * d
        val top = ceil(max(minTop, values.maxOrNull() ?: 0f) / 30f) * 30f
        plot.set(lm, 4f * d, w, h - 2f * d)
        canvas.drawLine(lm, plot.top, w, plot.top, grid)
        canvas.drawLine(lm, (plot.top + plot.bottom) / 2f, w, (plot.top + plot.bottom) / 2f, grid)
        canvas.drawLine(lm, plot.bottom, w, plot.bottom, grid)
        canvas.drawText("${top.toInt()}", 0f, plot.top + 6f * d, label)
        canvas.drawText("${(top / 2f).toInt()}", 0f, (plot.top + plot.bottom) / 2f + 3f * d, label)
        canvas.drawText("0", 0f, plot.bottom, label)
        if (values.size < 2) return
        val step = plot.width() / (values.size - 1)
        canvas.save()
        canvas.clipRect(plot.left, 0f, plot.right, h)
        canvas.translate(slide * step, 0f)
        val lp = Path()
        val fp = Path()
        values.forEachIndexed { i, v ->
            val x = plot.left + i * step
            val y = plot.bottom - (v / top).coerceIn(0f, 1f) * plot.height()
            if (i == 0) {
                lp.moveTo(x, y)
                fp.moveTo(x, plot.bottom)
                fp.lineTo(x, y)
            } else {
                lp.lineTo(x, y)
                fp.lineTo(x, y)
            }
        }
        fp.lineTo(plot.left + (values.size - 1) * step, plot.bottom)
        fp.close()
        canvas.drawPath(fp, fill)
        canvas.drawPath(lp, line)
        canvas.restore()
    }
}

/** Slider berbentuk pil (gaya panel cepat): ikon bulat di kiri, isian membesar ke kanan. */
class PillSlider(context: Context, private var glyph: Glyph) : View(context) {
    var onChange: ((Int, Boolean) -> Unit)? = null
    var onIconTap: (() -> Unit)? = null
    private var progress = 0
    private var dragging = false
    private var iconDown = false
    private var downX = 0f
    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A2F38") }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DCE0E8") }
    private val circleP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D91A1F28") }
    private val glyphP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
        color = Color.WHITE
    }
    private val clip = Path()
    private val rect = RectF()
    private val gp = Path()

    fun setGlyph(g: Glyph) {
        if (g != glyph) {
            glyph = g
            invalidate()
        }
    }

    fun setProgressSilently(p: Int) {
        if (dragging) return
        val v = p.coerceIn(0, 100)
        if (v != progress) {
            progress = v
            invalidate()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, track)
        val fw = h + (w - h) * progress / 100f
        c.save()
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(clip)
        c.drawRect(0f, 0f, fw, h, fillP)
        c.restore()
        c.drawCircle(r, r, r - 5f * d, circleP)
        val gs = 20f * d
        c.save()
        c.translate(r - gs / 2f, r - gs / 2f)
        c.scale(gs / 24f, gs / 24f)
        drawGlyph(c, glyph, glyphP, gp)
        c.restore()
    }

    private fun setFromX(x: Float) {
        val p = ((x / max(1, width)) * 100f).roundToInt().coerceIn(0, 100)
        if (p != progress) {
            progress = p
            invalidate()
            onChange?.invoke(p, true)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x
                iconDown = onIconTap != null && e.x < height
                dragging = !iconDown
                if (!iconDown) setFromX(e.x)
            }
            MotionEvent.ACTION_MOVE -> {
                if (iconDown && abs(e.x - downX) > slop) {
                    iconDown = false
                    dragging = true
                }
                if (dragging) setFromX(e.x)
            }
            MotionEvent.ACTION_UP -> {
                if (iconDown) onIconTap?.invoke()
                iconDown = false
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                iconDown = false
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }
}

/** Cincin status tugas: berputar saat berjalan, busur menyesuaikan kemajuan, lalu menampilkan hasil. */
class TaskRing(context: Context) : View(context) {
    private var state = 0 // 0 diam, 1 berjalan, 2 selesai, 3 gagal
    private var angle = 0f
    private var progress = 0f
    private var label = ""
    var accent: Int = C_BLUE
        set(v) {
            field = v
            invalidate()
        }
    private var animator: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        strokeCap = Paint.Cap.ROUND
        color = C_ACC
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 9f * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private val oval = RectF()
    private val reset = Runnable {
        state = 0
        label = ""
        invalidate()
    }

    fun start() {
        removeCallbacks(reset)
        state = 1
        progress = 0f
        label = ""
        if (animator == null) {
            animator = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 900
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    angle = it.animatedValue as Float
                    invalidate()
                }
            }
        }
        animator?.start()
        invalidate()
    }

    fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        invalidate()
    }

    fun finish(text: String, ok: Boolean) {
        animator?.cancel()
        state = if (ok) 2 else 3
        label = text
        invalidate()
        removeCallbacks(reset)
        postDelayed(reset, 3000L)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        removeCallbacks(reset)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 3f * d
        oval.set(cx - r, cy - r, cx + r, cy + r)
        ring.color = when (state) {
            2 -> accent
            3 -> C_HOT
            else -> Color.parseColor("#4A5260")
        }
        c.drawCircle(cx, cy, r, ring)
        if (state == 1) {
            arc.color = accent
            c.drawArc(oval, angle, 70f + 220f * progress, false, arc)
        }
        val text = when (state) {
            1 -> if (progress > 0.01f) "${(progress * 100).toInt()}" else ""
            2, 3 -> label
            else -> ""
        }
        if (text.isNotEmpty()) {
            txt.color = if (state == 3) C_HOT else Color.parseColor("#EDEFF2")
            c.drawText(text, cx, cy - (txt.descent() + txt.ascent()) / 2f, txt)
        } else if (state == 0) {
            txt.color = C_DIM
            c.drawText("•", cx, cy - (txt.descent() + txt.ascent()) / 2f, txt)
        }
    }
}

/**
 * Panel gaming melayang bergaya Game Turbo. Pegangan putih tipis menempel di tepi layar dan tidak
 * berpindah saat panel dibuka (jendela terpisah). Dock jendela mengambang berdiri sendiri di sisi
 * kiri panel. Ketuk area luar panel untuk menutup.
 */
class FloatingPanelService : Service() {

    private class Tile(val view: LinearLayout, val title: TextView, val sub: TextView?, val icon: IconView, val flat: Boolean)

    private lateinit var wm: WindowManager
    private lateinit var handleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var scrimParams: WindowManager.LayoutParams
    private var scrim: View? = null
    private var scrimActive = false
    private lateinit var handle: FrameLayout
    private lateinit var handleBar: View
    private var handleAdded = false
    private lateinit var panel: LinearLayout
    private var panelAttached = false
    private lateinit var dockBox: LinearLayout
    private lateinit var dockScroll: ScrollView
    private lateinit var dock: LinearLayout
    private lateinit var mainBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var ring: TaskRing
    private lateinit var tvModeTag: TextView
    private lateinit var btnStop: TextView
    private lateinit var tvSub: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvFpsBefore: TextView
    private lateinit var tvFpsNote: TextView
    private lateinit var graph: MiniGraph
    private lateinit var sliderBright: PillSlider
    private lateinit var sliderVol: PillSlider
    private lateinit var tvFooter: TextView
    private lateinit var tileClean: Tile
    private lateinit var tileSpace: Tile
    private lateinit var tileDnd: Tile
    private lateinit var tileShot: Tile
    private lateinit var tileRec: Tile
    private lateinit var tileSettings: Tile
    private lateinit var tileRestore: Tile
    private lateinit var tileFrame: Tile
    private lateinit var tileTimer: Tile
    private var hudView: TextView? = null
    private var accent = C_BLUE
    private var accentDim = Color.argb(140, 91, 155, 224)
    private lateinit var statsCard: LinearLayout
    private lateinit var modeMark: View
    private val dots = mutableListOf<View>()

    // halaman dalam panel + overlay crosshair/monitor
    private enum class Page { MAIN, FEATURES, CROSSHAIR, MONITOR, FOCUS, REC, PING, MUSIC, LIVE, AI, MAP, WINDOW }
    private var page = Page.MAIN
    private lateinit var stage: FrameLayout
    private lateinit var pageFeatures: ScrollView
    private lateinit var pageCrosshair: ScrollView
    private lateinit var pageMonitor: ScrollView
    private lateinit var pageFocus: ScrollView
    private lateinit var pageRec: ScrollView
    private lateinit var pagePing: ScrollView
    private lateinit var pageMusic: ScrollView
    private lateinit var pageLive: ScrollView
    private lateinit var tvLiveStatus: TextView
    private lateinit var tvAiStatus: TextView
    private lateinit var pageMap: ScrollView
    private lateinit var tvMapStatus: TextView
    private lateinit var tvMapInfo: TextView
    private lateinit var tvMapSens: TextView
    private lateinit var swMap: ToggleSwitch
    private lateinit var slMapSens: PillSlider
    private lateinit var slMapJoy: PillSlider
    private lateinit var mapKeysBox: LinearLayout
    private var mapCfg = MapConfig()
    private val mapCtl by lazy { MappingController(applicationContext) }
    private var mapCaptureIdx = -2
    private var mapCaptureAt = 0L
    private var mapEdit = false
    private var mapDone: TextView? = null
    private val mapMarkers = HashMap<String, MapMarkerView>()
    private val mapMarkerParams = HashMap<String, WindowManager.LayoutParams>()
    private val mapTick = object : Runnable {
        override fun run() {
            if (page == Page.MAP && expanded) {
                pollMap()
                handler.postDelayed(this, 700L)
            }
        }
    }
    private lateinit var pageAi: ScrollView
    private lateinit var aiInput: android.widget.EditText
    private lateinit var aiKeyInput: android.widget.EditText
    private lateinit var aiMsgs: LinearLayout
    private lateinit var aiScroll: ScrollView
    private lateinit var aiSettings: LinearLayout
    private lateinit var tvAiMode: TextView
    private lateinit var tvAiKey: TextView
    private lateinit var swAiOnline: ToggleSwitch
    private val aiHistory = ArrayList<Pair<Boolean, String>>()
    private var aiBusy = false
    private var aiTyping: TextView? = null
    private var panelFocusable = false
    private lateinit var tvLiveInfo: TextView
    private lateinit var tvLiveOpacity: TextView
    private lateinit var tvLiveSlotTitle: TextView
    private lateinit var swLive: ToggleSwitch
    private lateinit var swLiveSlot: ToggleSwitch
    private lateinit var swLiveTrans: ToggleSwitch
    private lateinit var swLiveThrough: ToggleSwitch
    private lateinit var slLiveOpacity: PillSlider
    private val liveSlotChips = mutableListOf<TextView>()
    private val liveModeChips = mutableListOf<TextView>()
    private var liveSlot = 0
    private val liveRoots = HashMap<Int, FrameLayout>()
    private val liveParamsMap = HashMap<Int, WindowManager.LayoutParams>()
    private val liveBars = HashMap<Int, FloatHandleView>()
    private val liveGrips = HashMap<Int, FloatGripView>()
    private val liveWebs = HashMap<Int, android.webkit.WebView>()
    private var liveEditSlot = -1
    private var liveRemX = 0f
    private var liveRemY = 0f
    private lateinit var tvMusicStatus: TextView
    private lateinit var tvMusicTitle: TextView
    private lateinit var tvMusicTime: TextView
    private lateinit var tvMusicSpeed: TextView
    private lateinit var tvMusicPlay: TextView
    private lateinit var slMusicSeek: PillSlider
    private lateinit var musicDisc: MusicDiscView
    private lateinit var musicList: LinearLayout
    private var musicSeekAt = 0L
    private val musicTick = object : Runnable {
        override fun run() {
            if (page == Page.MUSIC && expanded) {
                updateMusicLive()
                handler.postDelayed(this, 500L)
            } else if (::musicDisc.isInitialized) {
                musicDisc.setPlaying(false, 1f)
            }
        }
    }
    private lateinit var tvPingStatus: TextView
    private lateinit var tvPingInfo: TextView
    private lateinit var tvPingResult: TextView
    private lateinit var swPing: ToggleSwitch
    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null
    private lateinit var tvRecStatus: TextView
    private lateinit var swRecDev: ToggleSwitch
    private lateinit var tvFloatReport: TextView
    private lateinit var swRecMic: ToggleSwitch
    private lateinit var tvFocusStatus: TextView
    private lateinit var tvFocusInfo: TextView
    private lateinit var swFocus: ToggleSwitch
    private lateinit var swFocusDnd: ToggleSwitch
    private lateinit var swFocusHeads: ToggleSwitch
    private lateinit var swFocusBright: ToggleSwitch
    private var focusBanner: FocusBannerView? = null
    private lateinit var pageWindow: ScrollView
    private lateinit var tvWinStatus: TextView
    private lateinit var slFloatScale: PillSlider
    private val ratioChips = mutableListOf<TextView>()
    private val sizeChips = mutableListOf<TextView>()
    private lateinit var tvCrossStatus: TextView
    private lateinit var tvMonStatus: TextView
    private lateinit var swCrosshair: ToggleSwitch
    private lateinit var swMonitor: ToggleSwitch
    private lateinit var slChSize: PillSlider
    private lateinit var slChOpacity: PillSlider
    private val stylePreviews = mutableListOf<CrosshairView>()
    private val styleCells = mutableListOf<FrameLayout>()
    private val chColorCells = mutableListOf<FrameLayout>()
    private val monChips = LinkedHashMap<String, LinearLayout>()
    private val monColorCells = mutableListOf<FrameLayout>()
    private val monSizeChips = mutableListOf<TextView>()
    private var crosshair: CrosshairView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null
    private var crosshairAdded = false
    private var hud: LinearLayout? = null
    private var hudParams: WindowManager.LayoutParams? = null
    private var hudEditing = false
    private val hudValues = LinkedHashMap<String, TextView>()
    private var lastFps: Int? = null
    private var lastCpu: Int? = null
    private var lastCpuGhz: Float? = null
    private var lastGpu: Int? = null
    private var lastBatt: BatteryStatus? = null
    private var lastMemPct: Int? = null
    private val chColors = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFFFF5252.toInt(), 0xFFFFEB3B.toInt(), 0xFF69F0AE.toInt(),
        0xFF18FFFF.toInt(), 0xFF448AFF.toInt(), 0xFFB388FF.toInt()
    )
    private val monColors = intArrayOf(
        0xFF5B9BE0.toInt(), 0xFFFFFFFF.toInt(), 0xFF69F0AE.toInt(), 0xFFFF5252.toInt(),
        0xFFFFEB3B.toInt(), 0xFF18FFFF.toInt(), 0xFFB388FF.toInt(), 0xFFFFA726.toInt()
    )
    private val hudMeta = linkedMapOf(
        "FPS" to (Glyph.FRAME to "FPS"),
        "CPU" to (Glyph.CHIP to "CPU"),
        "CPUF" to (Glyph.CHIP to "Frek CPU"),
        "GPU" to (Glyph.GPU to "GPU"),
        "TEMP" to (Glyph.THERMO to "Suhu"),
        "BATT" to (Glyph.BATTERY to "Baterai"),
        "RAM" to (Glyph.RAM to "RAM"),
        "PING" to (Glyph.PING to "Ping")
    )

    private var expanded = false
    private var dockRight = false
    private var tickCount = 0
    private var lastInteraction = 0L
    private val fpsHistory = ArrayList<Float>()
    private var fpsBefore: Int? = null
    private var fpsShown: Int? = null
    private var fpsAnim: ValueAnimator? = null
    private var lastNet: NetStatus? = null
    private var lastPing: Int? = null
    private var lastTemp: ThermalReading? = null
    @Volatile private var gamePkg: String? = null
    @Volatile private var lastFloating: String? = null
    @Volatile private var floatCur: ShellTools.Bounds? = null
    @Volatile private var floatTaskId: Int? = null
    @Volatile private var moveBusy = false
    @Volatile private var dragSeq = 0
    private var floatMiss = 0
    private val floatPoll = object : Runnable {
        override fun run() {
            if (floatHandle == null) return
            val pkg = lastFloating
            if (pkg != null && !moveBusy && ShizukuHelper.hasPermission()) {
                slowExecutor.execute {
                    val exists = ShellTools.windowFrame(pkg) != null || ShellTools.findTaskId(pkg) != null
                    handler.post {
                        if (floatHandle != null) {
                            if (exists) {
                                floatMiss = 0
                            } else {
                                floatMiss++
                                if (floatMiss >= 3) {
                                    floatMiss = 0
                                    hideFloatHandle()
                                }
                            }
                        }
                    }
                }
            }
            handler.postDelayed(this, 4000L)
        }
    }
    @Volatile private var movePending = false
    private var floatHandle: FloatHandleView? = null
    @Volatile private var floatB: ShellTools.Bounds? = null
    private var floatHandleParams: WindowManager.LayoutParams? = null
    private var floatGhost: FloatGhostView? = null
    private var floatGhostParams: WindowManager.LayoutParams? = null
    private var floatGrip: FloatGripView? = null
    private var floatGripParams: WindowManager.LayoutParams? = null
    private var resRemX = 0f
    private var resRemY = 0f
    private var dragRemX = 0f
    private var dragRemY = 0f
    @Volatile private var gameBeforeFloat: String? = null
    private var homePkg: String? = null
    private var warnedBrightness = false
    private var timerMinutes = 0
    private var timerEndAt = 0L
    private var receiverRegistered = false

    private val handler = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val slowExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, if (expanded || hudActive()) 1000L else 5000L)
        }
    }
    private val timerDone = Runnable { onTimerDone() }

    // Tekstur Ringan / Turunkan Resolusi dimatikan otomatis setelah game ditinggalkan.
    private var texSeenGame = false
    private var texAwayTicks = 0
    private val texWatch = object : Runnable {
        override fun run() {
            checkTexAutoOff()
            handler.postDelayed(this, 4000L)
        }
    }

    private fun checkTexAutoOff() {
        val g = GameSettings(this)
        if (!g.texApplied && !g.texAltApplied) {
            texSeenGame = false
            texAwayTicks = 0
            return
        }
        slowExecutor.execute {
            val fg = ShellTools.foregroundPackage()
            handler.post { onTexForeground(fg) }
        }
    }

    private fun onTexForeground(fg: String?) {
        if (fg == null) return
        if (fg in ShellTools.LIGHT_TEX_PKGS) {
            texSeenGame = true
            texAwayTicks = 0
            return
        }
        if (fg == lastFloating) return // jendela mengambang di depan, game masih di belakangnya
        val sinceApply = System.currentTimeMillis() - GameSettings(this).texAppliedAt
        if (!texSeenGame && sinceApply < 90_000L) return // game masih dibuka
        texAwayTicks++
        if (texAwayTicks >= 3) { // sekitar 12 detik di luar game
            texAwayTicks = 0
            texSeenGame = false
            val g = GameSettings(this)
            slowExecutor.execute {
                val ok = ShellTools.revertGameFeatures(g)
                handler.post { if (ok) toast("Tekstur Ringan dan resolusi dikembalikan ke normal") }
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (!handleAdded) return
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (expanded) toggle()
                    handle.visibility = View.GONE
                }
                Intent.ACTION_USER_PRESENT -> handle.visibility = View.VISIBLE
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        if (!IntegrityCheck.check(this).ok) {
            // APK ditandatangani ulang oleh pihak lain: panel tidak dinyalakan demi keamanan pengguna.
            stopSelf()
            return
        }
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        ShellTools.init(this)
        instance = this
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            GameSettings(this).panelWanted = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin tampil di atas aplikasi lain belum diberikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        GameSettings(this).panelWanted = true
        if (!handleAdded) buildOverlay()
        if (!receiverRegistered) {
            val f = IntentFilter(Intent.ACTION_SCREEN_OFF).apply { addAction(Intent.ACTION_USER_PRESENT) }
            ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        isRunning = true
        if (GameSettings(this).pingLow && wifiLock?.isHeld != true) {
            // layanan dinyalakan ulang setelah proses dimatikan sistem: pasang kembali kunci Wi-Fi
            handler.post { applyPing(true) }
        }
        executor.execute { if (ShellTools.canRead()) ShellTools.enableTimeStats() }
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        handler.removeCallbacks(texWatch)
        handler.postDelayed(texWatch, 4000L)
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!handleAdded) return
        handle.post {
            if (expanded) toggle()
            handleParams.y = (GameSettings(this).panelYFraction * screenSize().second).toInt()
            positionHandle()
            applyCrosshair()
            applyMonitor()
            applyLive()
        }
    }

    /** Aplikasi dihapus dari daftar terakhir: jadwalkan penyalaan ulang supaya panel dan overlay tidak hilang. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (GameSettings(this).panelWanted) scheduleRestart(1200L)
    }

    private fun scheduleRestart(delayMs: Long) {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val i = Intent(this, FloatingPanelService::class.java)
            val flags = android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            val pi = if (Build.VERSION.SDK_INT >= 26) android.app.PendingIntent.getForegroundService(this, 77, i, flags)
            else android.app.PendingIntent.getService(this, 77, i, flags)
            am.set(android.app.AlarmManager.RTC, System.currentTimeMillis() + delayMs, pi)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        removeAllLive()
        val revertCtx = applicationContext
        // Hanya bila pengguna sengaja mematikan Game Space: kembalikan fitur yang masih menyala.
        // Bila dihentikan sistem, pengaturan dipertahankan karena layanan akan dinyalakan ulang.
        removeMapMarkers()
        if (!GameSettings(revertCtx).panelWanted) {
            try {
                MappingController(revertCtx).requestQuit()
            } catch (_: Exception) {
            }
            Thread { ShellTools.revertGameFeatures(GameSettings(revertCtx)) }.start()
            if (GameSettings(revertCtx).pingLow) {
                try {
                    wifiLock?.let { if (it.isHeld) it.release() }
                } catch (_: Exception) {
                }
                GameSettings(revertCtx).pingLow = false
                Thread { ShellTools.setWifiLowLatency(false) }.start()
            }
        }
        handler.removeCallbacksAndMessages(null)
        fpsAnim?.cancel()
        executor.shutdownNow()
        slowExecutor.shutdownNow()
        if (receiverRegistered) {
            try {
                unregisterReceiver(screenReceiver)
            } catch (_: Exception) {
            }
        }
        removeSafely(hudView)
        removeSafely(crosshair)
        hideFloatHandle()
        removeSafely(hud)
        removeFocusBanner()
        if (panelAttached) removeSafely(panel)
        if (handleAdded) removeSafely(handle)
        removeSafely(scrim)
        panelAttached = false
        handleAdded = false
        scrim = null
        instance = null
        isRunning = false
        super.onDestroy()
    }

    private fun removeSafely(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ notifikasi

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val m = getSystemService(NotificationManager::class.java)
            m.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Panel gaming", NotificationManager.IMPORTANCE_LOW))
            m.createNotificationChannel(NotificationChannel(TIMER_CHANNEL, "Timer bermain", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("AISZ GAME SPACE")
            .setContentText("Panel gaming aktif")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(0, "Tutup panel", stop)
            .build()
    }

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ helper

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return b.width() to b.height()
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun edgeRadii(r: Float): FloatArray =
        if (dockRight) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)

    /** Kotak bersudut membulat (nama lama dipertahankan agar pemanggil tidak berubah). */
    private fun cutBg(
        fill: Int, stroke: Int, cutDp: Int,
        tl: Boolean = false, tr: Boolean = false, br: Boolean = true, bl: Boolean = false
    ): GradientDrawable = rounded(fill, (cutDp * 1.9f).toInt().coerceAtLeast(10), stroke)

    private fun withAlpha(c: Int, a: Float): Int =
        Color.argb((a * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun margins(v: Int) = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        setMargins(dp(v), dp(v), dp(v), dp(v))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun View.pressable(onClick: () -> Unit) {
        setOnClickListener {
            lastInteraction = SystemClock.elapsedRealtime()
            onClick()
        }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }
            false
        }
    }

    /** Pesan singkat berupa lapisan sendiri: tetap terlihat di dalam game (toast biasa sering tidak tampil). */
    private fun showHud(msg: String) {
        handler.post {
            if (!handleAdded) return@post
            removeSafely(hudView)
            val tv = text(msg, 13f, TEXT, true).apply {
                gravity = Gravity.CENTER
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                maxWidth = screenSize().first - dp(48)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = cutBg(HUD_BG, accent, 8, tl = true, br = true)
                alpha = 0f
            }
            val lpHud = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(28)
                useFullScreenArea()
            }
            try {
                wm.addView(tv, lpHud)
            } catch (_: Exception) {
                return@post
            }
            hudView = tv
            tv.animate().alpha(1f).setDuration(150).start()
            handler.postDelayed({
                tv.animate().alpha(0f).setDuration(200).withEndAction {
                    removeSafely(tv)
                    if (hudView === tv) hudView = null
                }.start()
            }, 3000L)
        }
    }

    private fun toast(msg: String) = showHud(msg)

    /** Ubin vertikal bergaris (kotak): ikon di atas, judul di bawah. */
    private fun boxTile(glyph: Glyph, title: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph)
        val t = text(title, 10.5f, TEXT).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = cutBg(TILE_BG, TILE_STROKE, 7)
            addView(icon, lp(dp(24), dp(24)))
            addView(t, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
            pressable(onClick)
        }
        return Tile(box, t, null, icon, false)
    }

    /** Ubin datar (tanpa garis) untuk baris ikon dalam satu wadah. */
    private fun flatTile(glyph: Glyph, title: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph)
        val t = text(title, 10f, TEXT).apply {
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(4), dp(2), dp(4))
            addView(icon, lp(dp(24), dp(24)))
            addView(t, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
            pressable(onClick)
        }
        return Tile(box, t, null, icon, true)
    }

    private fun wideTile(glyph: Glyph, title: String, sub: String, onClick: () -> Unit): Tile {
        val icon = IconView(this, glyph)
        val t = text(title, 12f, TEXT, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val s = text(sub, 10f, DIM).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(t)
            addView(s)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(10), 0)
            background = cutBg(TILE_BG, TILE_STROKE, 7)
            addView(icon, lp(dp(24), dp(24)).apply { rightMargin = dp(10) })
            addView(col, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            pressable(onClick)
        }
        return Tile(box, t, s, icon, false)
    }

    private fun setTileActive(t: Tile, active: Boolean, color: Int = accent) {
        if (t.flat) {
            t.view.background = if (active) rounded(withAlpha(color, 0.22f), 12) else null
        } else {
            t.view.background = cutBg(if (active) withAlpha(color, 0.16f) else TILE_BG, if (active) color else TILE_STROKE, 7)
        }
        t.icon.tint = if (active) color else ICON
    }

    // ------------------------------------------------------------ susunan panel

    /** Kartu grafik FPS: chip mode, grafik area, Setelah/Sebelum, tombol Hentikan. */
    private fun buildStatsCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = cutBg(TILE_BG, accentDim, 10, tl = true, br = true)
        }
        statsCard = card
        tvModeTag = text("Seimbang", 12f, accent, true).apply {
            setPadding(dp(8), dp(2), dp(8), dp(2))
            pressable { cycleMode() }
        }
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(View(this@FloatingPanelService), lp(0, 1, 1f))
            addView(tvModeTag)
            modeMark = View(this@FloatingPanelService).apply { background = rounded(accent, 4) }
            addView(modeMark, lp(dp(18), dp(8)).apply { leftMargin = dp(4) })
        })

        graph = MiniGraph(this)
        tvFpsNote = text("", 9.5f, DIM).apply {
            gravity = Gravity.CENTER
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(24), 0, 0, 0)
        }
        val frame = FrameLayout(this).apply {
            addView(graph, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(tvFpsNote, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            ))
        }
        card.addView(frame, lp(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(2)
            bottomMargin = dp(4)
        })

        tvFps = text("-- FPS", 16f, DIM, true)
        tvFpsBefore = text("-- FPS", 16f, DIM, true)
        fun stat(valueView: TextView, caption: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(valueView)
            addView(LinearLayout(this@FloatingPanelService).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val dot = View(this@FloatingPanelService).apply {
                    background = circle(Color.TRANSPARENT, accent)
                }
                dots.add(dot)
                addView(dot, lp(dp(6), dp(6)).apply { rightMargin = dp(4) })
                addView(text(caption, 9.5f, DIM))
            })
        }
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(stat(tvFps, "Setelah"), lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(stat(tvFpsBefore, "Sebelum"), lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        })

        btnStop = text("Hentikan", 13f, accent, true).apply {
            gravity = Gravity.CENTER
            background = cutBg(Color.parseColor("#4B4D12"), accent, 6, tl = true, br = true)
            pressable { stopOrBoost() }
        }
        card.addView(btnStop, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(26)).apply { topMargin = dp(4) })
        return card
    }

    private fun circle(fill: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun buildPanel(): LinearLayout {
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Judul + cincin tugas
        ring = TaskRing(this)
        val allChip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(TILE_BG, 14, TILE_STROKE)
            addView(IconView(this@FloatingPanelService, Glyph.GRID).apply { tint = ICON }, lp(dp(14), dp(14)).apply { rightMargin = dp(5) })
            addView(text("Semua fitur", 10.5f, TEXT, true).apply { maxLines = 1 })
            pressable { showPage(Page.FEATURES) }
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(text("AISZ GAME SPACE", 13f, TITLE, true).apply {
                letterSpacing = 0.05f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(allChip, lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(6)
                rightMargin = dp(6)
            })
            addView(ring, lp(dp(36), dp(36)))
        }, margins(4))
        tvSub = text("WLAN  --   -- ms   -- °C", 10f, DIM).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        content.addView(tvSub, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(5), 0, dp(4), dp(2))
        })

        // Baris atas: dua ubin + kartu grafik FPS
        tileClean = boxTile(Glyph.BOLT, "Bersihkan memori") { cleanMemory() }
        tileSpace = boxTile(Glyph.TRASH, "Bebaskan ruang") { freeSpace() }
        val leftCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tileClean.view, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(63)).apply { bottomMargin = dp(4) })
            addView(tileSpace.view, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(63)).apply { topMargin = dp(4) })
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(leftCol, lp(dp(82), dp(134)))
            addView(buildStatsCard(), lp(0, dp(134), 1f).apply { leftMargin = dp(8) })
        }, margins(4))

        // Baris ikon dalam satu wadah
        tileDnd = flatTile(Glyph.DND, "Jangan ganggu") { toggleDnd() }
        tileShot = flatTile(Glyph.SHOT, "Screen shot") { takeScreenshot() }
        tileRec = flatTile(Glyph.REC, "Rekam") { toggleRecord() }
        tileSettings = flatTile(Glyph.GEAR, "Setelan") { openApp() }
        tileRestore = flatTile(Glyph.RESTORE, "Pulihkan layar") { recoverScreen() }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = cutBg(TILE_BG, TILE_STROKE, 8, tl = true, br = true)
            listOf(tileDnd, tileShot, tileRec, tileSettings, tileRestore).forEach {
                addView(it.view, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            }
        }, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(66)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })

        // Baris bawah: dua ubin lebar
        tileFrame = wideTile(Glyph.FRAME, "Frame tinggi", "Normal") { toggleFrameLock() }
        tileTimer = wideTile(Glyph.TIMER, "Timer", "Mati") { toggleTimer() }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tileFrame.view, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { rightMargin = dp(4) })
            addView(tileTimer.view, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(4) })
        }, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })

        // Slider pil: cerah dan volume
        sliderBright = PillSlider(this, Glyph.SUN).apply {
            onChange = { p, user ->
                if (user) {
                    lastInteraction = SystemClock.elapsedRealtime()
                    applyBrightness(p.coerceAtLeast(1))
                }
            }
        }
        sliderVol = PillSlider(this, Glyph.SPEAKER).apply {
            onChange = { p, user ->
                if (user) {
                    lastInteraction = SystemClock.elapsedRealtime()
                    setVolume(p)
                }
            }
            onIconTap = { toggleMute() }
        }
        content.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(sliderBright, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { rightMargin = dp(4) })
            addView(sliderVol, lp(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(4) })
        }, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })

        tvFooter = text("Shizuku: -", 10f, DIM).apply {
            setPadding(dp(6), dp(2), 0, 0)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            pressable { openShizukuOrApp() }
        }
        content.addView(tvFooter)

        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
            setOnTouchListener { _, _ ->
                lastInteraction = SystemClock.elapsedRealtime()
                false
            }
        }
        pageFeatures = buildFeaturesPage()
        pageCrosshair = buildCrosshairPage()
        pageMonitor = buildMonitorPage()
        pageFocus = buildFocusPage()
        pageRec = buildRecPage()
        pagePing = buildPingPage()
        pageMusic = buildMusicPage()
        pageLive = buildLivePage()
        pageAi = buildAiPage()
        pageMap = buildMapPage()
        pageWindow = buildWindowPage()
        stage = FrameLayout(this)
        stage.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        listOf(pageFeatures, pageCrosshair, pageMonitor, pageFocus, pageRec, pagePing, pageMusic, pageLive, pageAi, pageMap, pageWindow).forEach {
            it.visibility = View.GONE
            stage.addView(it, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        mainBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = cutBg(PANEL_BG, PANEL_STROKE, 12, tr = true, bl = true, br = false)
            addView(stage, lp(mainWidth(), LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        // Dock jendela mengambang: wadah terpisah di sisi kiri
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        dockScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(dock)
            setOnTouchListener { _, _ ->
                lastInteraction = SystemClock.elapsedRealtime()
                false
            }
        }
        dockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(DOCK_BG, 20, TILE_STROKE)
            addView(dockScroll, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(dockBox, lp(dp(60), dp(200)))
            addView(mainBox, lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        }
    }

    /** Lebar isi panel menyesuaikan layar (jarak ke tepi, dock terpisah, dan padding dihitung). */
    private fun mainWidth(): Int {
        val avail = screenSize().first - dp(PANEL_GAP_DP) - dp(12) - dp(60) - dp(8) - dp(24)
        return avail.coerceIn(dp(230), dp(310))
    }

    /** Pegangan putih tipis yang menempel di tepi layar. */
    private fun styleHandle() {
        handleBar.background = GradientDrawable().apply {
            setColor(WHITE)
            cornerRadii = edgeRadii(dp(3).toFloat())
        }
        val lpBar = handleBar.layoutParams as FrameLayout.LayoutParams
        lpBar.gravity = (if (dockRight) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        handleBar.layoutParams = lpBar
    }

    private fun roundOutline(radiusDp: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
        }
    }

    private fun rebuildDock() {
        dock.removeAllViews()
        GameSettings(this).dockApps.take(6).forEach { pkg ->
            val icon = try {
                packageManager.getApplicationIcon(pkg)
            } catch (e: Exception) {
                null
            } ?: return@forEach
            val iv = ImageView(this).apply {
                setImageDrawable(icon)
                outlineProvider = roundOutline(11)
                clipToOutline = true
                pressable { openFloating(pkg) }
            }
            dock.addView(iv, lp(dp(42), dp(42)).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
        val plus = text("+", 20f, accent, true).apply {
            gravity = Gravity.CENTER
            background = rounded(TILE_BG, 11, TILE_STROKE)
            pressable { openApp() }
        }
        dock.addView(plus, lp(dp(42), dp(42)).apply { setMargins(0, dp(5), 0, dp(5)) })
        if (lastFloating != null) {
            val x = FrameLayout(this).apply {
                background = rounded(Color.argb(60, 255, 77, 94), 11, HOT)
                addView(IconView(this@FloatingPanelService, Glyph.CLOSE).apply { tint = HOT },
                    FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
                pressable { recoverScreen() }
            }
            dock.addView(x, lp(dp(42), dp(42)).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun WindowManager.LayoutParams.useFullScreenArea() {
        // Tanpa ini Android menggeser overlay menjauhi lubang kamera sehingga pegangan tidak menempel di tepi.
        if (Build.VERSION.SDK_INT >= 30) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun overlayFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    @SuppressLint("ClickableViewAccessibility")
    private fun addScrim() {
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN && expanded) toggle()
            true
        }
        scrim = v
        scrimParams = WindowManager.LayoutParams(
            1, 1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }
        wm.addView(v, scrimParams)
    }

    private fun setScrim(active: Boolean) {
        val v = scrim ?: return
        scrimActive = active
        val size = if (active) WindowManager.LayoutParams.MATCH_PARENT else 1
        scrimParams.width = size
        scrimParams.height = size
        scrimParams.flags = if (active) {
            scrimParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            scrimParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, scrimParams)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildOverlay() {
        homePkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName

        val gs = GameSettings(this)
        dockRight = gs.panelRight

        handleBar = View(this)
        handle = FrameLayout(this).apply {
            addView(handleBar, FrameLayout.LayoutParams(dp(5), dp(72), Gravity.START or Gravity.CENTER_VERTICAL))
            setOnTouchListener(dragListener)
        }
        panel = buildPanel()
        styleHandle()

        addScrim() // pertama: berada paling bawah

        val (_, sh) = screenSize()
        handleParams = WindowManager.LayoutParams(
            dp(HANDLE_W_DP), dp(96), overlayType(), overlayFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (gs.panelYFraction * sh).toInt()
            useFullScreenArea()
        }
        wm.addView(handle, handleParams)
        handleAdded = true
        positionHandle()

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), overlayFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }
        syncModeButtons()
        applyCrosshair()
        applyMonitor()
        applyLive()
    }

    /** Pegangan selalu di tepi layar dan tidak ikut bergeser saat panel dibuka. */
    private fun positionHandle() {
        if (!handleAdded) return
        val (sw, sh) = screenSize()
        val m = dp(12)
        handleParams.x = if (dockRight) sw - dp(HANDLE_W_DP) else 0
        handleParams.y = handleParams.y.coerceIn(m, max(m, sh - dp(96) - m))
        try {
            wm.updateViewLayout(handle, handleParams)
        } catch (_: Exception) {
        }
    }

    private fun limitPanelHeight() {
        val w = mainWidth()
        content.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val limit = screenSize().second - dp(72)
        val h = min(content.measuredHeight, limit)
        val lpStage = stage.layoutParams
        lpStage.width = w
        lpStage.height = h
        stage.layoutParams = lpStage
        val lpDock = dockBox.layoutParams
        lpDock.height = h + dp(24)
        dockBox.layoutParams = lpDock
    }

    private fun slideOffset(): Float = if (dockRight) dp(24).toFloat() else -dp(24).toFloat()

    private fun toggle() {
        if (expanded) setPanelFocusable(false)
        expanded = !expanded
        lastInteraction = SystemClock.elapsedRealtime()
        if (expanded) showPanel() else hidePanel()
    }

    private fun showPanel() {
        rebuildDock()
        syncModeButtons()
        syncTiles()
        syncSliders()
        warnedBrightness = false
        tickCount = 0
        limitPanelHeight()
        resetPages()
        scroll.scrollTo(0, 0)
        dockScroll.scrollTo(0, 0)
        val (sw, sh) = screenSize()
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST)
        )
        val pw = panel.measuredWidth
        val ph = panel.measuredHeight
        val m = dp(12)
        panelParams.x = if (dockRight) sw - dp(PANEL_GAP_DP) - pw else dp(PANEL_GAP_DP)
        val centerY = handleParams.y + dp(48)
        panelParams.y = (centerY - ph / 2).coerceIn(m, max(m, sh - ph - m))
        panel.animate().cancel()
        if (!panelAttached) {
            try {
                wm.addView(panel, panelParams)
                panelAttached = true
            } catch (_: Exception) {
                expanded = false
                return
            }
        } else {
            try {
                wm.updateViewLayout(panel, panelParams)
            } catch (_: Exception) {
            }
        }
        panel.pivotX = if (dockRight) pw.toFloat() else 0f
        panel.pivotY = ph / 2f
        panel.alpha = 0f
        panel.scaleX = 0.9f
        panel.scaleY = 0.9f
        panel.translationX = slideOffset()
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationX(0f)
            .setDuration(240).setInterpolator(OvershootInterpolator(0.8f)).start()
        dockBox.alpha = 0f
        dockBox.translationX = slideOffset() * 1.6f
        dockBox.animate().alpha(1f).translationX(0f).setStartDelay(40).setDuration(220)
            .setInterpolator(DecelerateInterpolator()).start()
        handleBar.animate().scaleY(1.25f).setDuration(200).start()
        setScrim(true)
        tick()
    }

    private fun hidePanel() {
        setScrim(false)
        panel.animate().cancel()
        dockBox.animate().cancel()
        dockBox.animate().setStartDelay(0)
        handleBar.animate().scaleY(1f).setDuration(150).start()
        panel.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).translationX(slideOffset())
            .setDuration(150).setInterpolator(AccelerateInterpolator()).withEndAction {
            if (!expanded && panelAttached) {
                removeSafely(panel)
                panelAttached = false
            }
        }.start()
    }

    private val dragListener = object : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop by lazy { ViewConfiguration.get(this@FloatingPanelService).scaledTouchSlop }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = handleParams.x
                    startY = handleParams.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                        dragging = true
                        if (expanded) toggle()
                    }
                    if (dragging) {
                        val (sw, sh) = screenSize()
                        val m = dp(12)
                        handleParams.x = (startX + dx).toInt().coerceIn(0, max(0, sw - dp(HANDLE_W_DP)))
                        handleParams.y = (startY + dy).toInt().coerceIn(m, max(m, sh - dp(96) - m))
                        try {
                            wm.updateViewLayout(handle, handleParams)
                        } catch (_: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        val (sw, sh) = screenSize()
                        val right = handleParams.x + dp(HANDLE_W_DP) / 2 > sw / 2
                        if (right != dockRight) {
                            dockRight = right
                            styleHandle()
                        }
                        positionHandle()
                        val gs = GameSettings(this@FloatingPanelService)
                        gs.panelRight = dockRight
                        gs.panelYFraction = handleParams.y.toFloat() / sh
                    } else {
                        v.performClick()
                        toggle()
                    }
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------ data berkala

    private fun levelColor(level: TempLevel): Int = when (level) {
        TempLevel.NORMAL -> OK
        TempLevel.WARM -> WARN
        TempLevel.HIGH -> HOT
        TempLevel.UNKNOWN -> DIM
    }

    private fun fpsColor(fps: Int?): Int = if (fps == null) DIM else accent

    private fun setFpsText(view: TextView, fps: Int?) {
        val s = if (fps == null) "-- FPS" else "$fps FPS"
        val sp = SpannableString(s)
        sp.setSpan(RelativeSizeSpan(0.6f), s.length - 3, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        view.text = sp
        view.setTextColor(fpsColor(fps))
    }

    /** Angka FPS berubah dengan hitung naik/turun halus. */
    private fun showFps(target: Int?) {
        fpsAnim?.cancel()
        if (target == null) {
            fpsShown = null
            setFpsText(tvFps, null)
            return
        }
        val from = fpsShown ?: target
        if (from == target) {
            fpsShown = target
            setFpsText(tvFps, target)
            return
        }
        fpsAnim = ValueAnimator.ofInt(from, target).apply {
            duration = 350
            addUpdateListener {
                val x = it.animatedValue as Int
                fpsShown = x
                setFpsText(tvFps, x)
            }
            start()
        }
    }

    private fun currentAvgFps(): Int? =
        if (fpsHistory.isEmpty()) null else fpsHistory.takeLast(10).average().toInt()

    private fun hudActive(): Boolean {
        val g = GameSettings(this)
        return g.monEnabled && g.monItems.isNotEmpty()
    }

    private fun tick() {
        if (!handleAdded) return
        val now = SystemClock.elapsedRealtime()
        // Sembunyikan di layar kunci.
        val locked = try {
            (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
        } catch (e: Exception) {
            false
        }
        if (locked) {
            if (expanded) toggle()
            handle.visibility = View.GONE
            setOverlaysVisible(false)
            return
        }
        if (handle.visibility != View.VISIBLE) handle.visibility = View.VISIBLE
        setOverlaysVisible(true)
        // Pengaman: lapisan penutup tidak boleh aktif saat panel tertutup.
        if (!expanded && scrimActive) setScrim(false)
        // Tutup otomatis bila tidak disentuh 40 detik.
        if (expanded && now - lastInteraction > 40_000L) {
            toggle()
            return
        }
        val gs = GameSettings(this)
        val hudOn = gs.monEnabled && gs.monItems.isNotEmpty()
        if (!expanded && !hudOn) return
        val items = if (hudOn) gs.monItems else emptyList()
        val wantFps = expanded || "FPS" in items
        val wantNet = expanded || "PING" in items
        val wantCpu = "CPU" in items
        val wantFreq = "CPUF" in items
        val wantGpu = "GPU" in items

        val perf = PerformanceMonitor(this)
        lastTemp = TemperatureMonitor(this).read()
        lastBatt = perf.battery()
        lastMemPct = perf.memory().usedPercent
        if (expanded) {
            syncTiles()
            syncSliders()
        }
        updateHud()
        if (!busy.compareAndSet(false, true)) return
        val idx = tickCount++
        val wasExpanded = expanded
        executor.execute {
            try {
                if (wantNet && idx % 3 == 0) {
                    val monitor = NetworkMonitor(this)
                    lastNet = monitor.status()
                    lastPing = monitor.pingMs()
                }
                var fps: Int? = lastFps
                var note = ""
                val shizuku = ShizukuHelper.hasPermission()
                if (shizuku && !ShellTools.hasDump(this) && idx % 10 == 1) {
                    ShellTools.ensureSelfPermissions(this)
                }
                if (wantFps && (wasExpanded || idx % 2 == 0)) {
                    fps = null
                    if (ShellTools.canRead()) {
                        if (idx % 4 == 0) {
                            val fg = ShellTools.foregroundPackage()
                            val ignore = fg == null || fg == packageName || fg == homePkg ||
                                fg.startsWith("com.android.systemui")
                            if (fg != null && fg == lastFloating) {
                                // jendela mengambang di depan: pertahankan game sebelumnya
                            } else {
                                gamePkg = if (ignore) null else fg
                            }
                        }
                        val g = gamePkg
                        if (g != null) {
                            val gsx = GameSettings(this)
                            if (gsx.lastGamePkg != g) gsx.lastGamePkg = g
                            val r = ShellTools.measureFps(g)
                            fps = r.fps
                            if (r.fps == null && idx % 12 == 6) gsx.fpsDiag = ShellTools.fpsDiagnostics(this, g)
                            note = if (r.fps != null) "" else "FPS N/A: ${r.note}"
                        } else {
                            note = "Buka game untuk melihat FPS"
                        }
                    } else {
                        gamePkg = null
                        note = if (!ShizukuHelper.isRunning()) {
                            "Shizuku mati (ADB nirkabel terputus). Ketuk teks paling bawah untuk memulai ulang."
                        } else {
                            "FPS butuh izin Shizuku (atur di AISZ > Atur)"
                        }
                    }
                }
                if ((wantCpu || wantFreq || wantGpu) && idx % 2 == 0) {
                    val sample = ShellTools.sampleSystem(wantCpu, wantFreq, wantGpu)
                    if (wantCpu) lastCpu = sample.cpuPct
                    if (wantFreq) lastCpuGhz = sample.cpuGhz
                    if (wantGpu) lastGpu = sample.gpuPct
                }
                val footer = when {
                    shizuku -> "Shizuku aktif" + (gamePkg?.let { "  •  $it" } ?: "")
                    ShellTools.canRead() -> "Shizuku mati  •  FPS lewat izin mandiri"
                    else -> "Shizuku mati - ketuk untuk membuka Shizuku"
                }
                val finalFps = fps
                handler.post {
                    if (!handleAdded) return@post
                    lastFps = finalFps
                    if (expanded) bindStats(finalFps, footer, note)
                    updateHud()
                }
            } finally {
                busy.set(false)
            }
        }
    }

    private fun bindStats(fps: Int?, footer: String, note: String) {
        val net = lastNet
        val t = lastTemp
        val netText = when {
            net == null -> "WLAN"
            net.transport == "WLAN" -> buildString {
                append("WLAN")
                if (net.rssiDbm != null) append(" ${net.rssiDbm} dBm")
                if (net.linkMbps != null) append(" ${net.linkMbps} Mbps")
            }
            else -> net.transport
        }
        val pingText = lastPing?.let { "$it ms" } ?: "-- ms"
        val tempText = if (t?.batteryC == null) "N/A" else String.format("%.0f °C", t.batteryC)
        tvSub.text = "$netText   $pingText   $tempText"
        showFps(fps)
        setFpsText(tvFpsBefore, fpsBefore)
        tvFpsBefore.setTextColor(if (fpsBefore == null) DIM else TEXT)
        tvFpsNote.text = note
        if (fps != null) {
            fpsHistory.add(fps.toFloat())
            if (fpsHistory.size > 40) fpsHistory.removeAt(0)
        }
        graph.setValues(fpsHistory.toList(), 60f)
        tvFooter.text = footer
    }

    private fun applyAccent() {
        accent = when (GameSettings(this).profile) {
            GamingProfile.HEMAT -> C_GREEN
            GamingProfile.SEIMBANG -> C_BLUE
            GamingProfile.PERFORMA -> C_RED
        }
        accentDim = withAlpha(accent, 0.6f)
        ring.accent = accent
        graph.setAccent(accent)
        tvModeTag.setTextColor(accent)
        modeMark.background = rounded(accent, 4)
        dots.forEach { it.background = circle(Color.TRANSPARENT, accent) }
        statsCard.background = cutBg(TILE_BG, accentDim, 10)
        btnStop.setTextColor(accent)
        btnStop.background = cutBg(withAlpha(accent, 0.2f), accent, 6)
        setFpsText(tvFps, fpsShown)
    }

    private fun syncModeButtons() {
        val current = GameSettings(this).profile
        tvModeTag.text = current.label
        btnStop.text = if (current == GamingProfile.SEIMBANG) "Aktifkan Performa" else "Hentikan"
        applyAccent()
    }

    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)

    private fun dndOn(): Boolean {
        val f = nm().currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL &&
            f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    private fun syncTiles() {
        if (!handleAdded) return
        val rec = ScreenRecorderService.isRecording
        tileRec.title.text = if (rec) "Berhenti" else "Rekam"
        setTileActive(tileRec, rec, HOT)
        setTileActive(tileDnd, dndOn())
        setTileActive(tileShot, false)
        setTileActive(tileSettings, false)
        setTileActive(tileRestore, false)
        setTileActive(tileClean, false)
        setTileActive(tileSpace, false)
        val locked = GameSettings(this).frameLock
        tileFrame.sub?.text = if (locked) "Terkunci" else "Normal"
        setTileActive(tileFrame, locked)
        val left = if (timerEndAt > 0L) (timerEndAt - SystemClock.elapsedRealtime()) / 1000L else 0L
        tileTimer.sub?.text = if (left > 0L) String.format(Locale.US, "Sisa %d:%02d", left / 60, left % 60) else "Mati"
        setTileActive(tileTimer, left > 0L)
    }

    private fun audio(): AudioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun syncSliders() {
        if (!handleAdded) return
        sliderBright.setProgressSilently(GameSettings(this).getBrightnessPercent())
        val am = audio()
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val p = if (mx > 0) am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / mx else 0
        sliderVol.setProgressSilently(p)
        sliderVol.setGlyph(if (p == 0) Glyph.SPEAKER_OFF else Glyph.SPEAKER)
    }

    // ------------------------------------------------------------ halaman dalam panel

    private fun gs() = GameSettings(this)

    private fun pageView(p: Page): View = when (p) {
        Page.MAIN -> scroll
        Page.FEATURES -> pageFeatures
        Page.CROSSHAIR -> pageCrosshair
        Page.MONITOR -> pageMonitor
        Page.FOCUS -> pageFocus
        Page.REC -> pageRec
        Page.PING -> pagePing
        Page.MUSIC -> pageMusic
        Page.LIVE -> pageLive
        Page.AI -> pageAi
        Page.MAP -> pageMap
        Page.WINDOW -> pageWindow
    }

    private fun resetPages() {
        Page.values().forEach { p ->
            val v = pageView(p)
            v.animate().cancel()
            v.alpha = 1f
            v.translationX = 0f
            v.visibility = if (p == Page.MAIN) View.VISIBLE else View.GONE
        }
        page = Page.MAIN
    }

    /** Pindah halaman di dalam panel yang sama (tanpa overlay baru), dengan animasi geser + pudar. */
    private fun showPage(target: Page, back: Boolean = false) {
        if (target != Page.AI) setPanelFocusable(false)
        if (target == page) return
        val out = pageView(page)
        val inn = pageView(target)
        page = target
        refreshPage(target)
        val off = dp(28).toFloat() * (if (back) -1f else 1f)
        out.animate().cancel()
        inn.animate().cancel()
        inn.visibility = View.VISIBLE
        inn.alpha = 0f
        inn.translationX = off
        inn.animate().alpha(1f).translationX(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        out.animate().alpha(0f).translationX(-off).setDuration(150).withEndAction {
            if (pageView(page) !== out) {
                out.visibility = View.GONE
                out.alpha = 1f
                out.translationX = 0f
            }
        }.start()
    }

    private fun refreshPage(p: Page) {
        when (p) {
            Page.FEATURES -> {
                val g = gs()
                tvCrossStatus.text = if (g.chEnabled) "Aktif" else "Mati"
                tvMonStatus.text = if (g.monEnabled) "${g.monItems.size} item aktif" else "Mati"
                tvFocusStatus.text = if (g.focusActive) "Aktif" else "Mati"
                tvRecStatus.text = recStatusText(g)
                tvPingStatus.text = if (g.pingLow) "Aktif" else "Mati"
                tvAiStatus.text = if (g.aiOnline && g.aiKey.isNotBlank()) "Claude online" else "Offline"
                val liveCount = (0 until GameSettings.LIVE_SLOTS).count { g.liveOn(it) }
                tvLiveStatus.text = if (g.liveMaster && liveCount > 0) "Tampil ($liveCount)" else "Mati"
                MusicEngine.ensureLoaded(this)
                tvMusicStatus.text = when {
                    MusicEngine.isPlaying -> "Memutar"
                    MusicEngine.songs.isEmpty() -> "Belum ada lagu"
                    else -> "${MusicEngine.songs.size} lagu"
                }
                tvWinStatus.text = "Ukuran ${g.floatScale}%"
            }
            Page.CROSSHAIR -> refreshCrosshairUi()
            Page.MONITOR -> refreshMonitorUi()
            Page.FOCUS -> refreshFocusUi()
            Page.REC -> refreshRecUi()
            Page.PING -> refreshPingUi()
            Page.MUSIC -> refreshMusicUi()
            Page.LIVE -> refreshLiveUi()
            Page.AI -> refreshAiUi()
            Page.MAP -> refreshMapUi()
            Page.WINDOW -> refreshWindowUi()
            Page.MAIN -> {}
        }
    }

    private fun sectionLabel(t: String): TextView =
        text(t, 11f, DIM).apply {
            setPadding(dp(4), dp(8), 0, dp(2))
            letterSpacing = 0.05f
        }

    private fun pageScroll(col: View): ScrollView = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        addView(col)
        setOnTouchListener { _, _ ->
            lastInteraction = SystemClock.elapsedRealtime()
            false
        }
    }

    private fun pageHeader(title: String, back: () -> Unit, toggle: View?): LinearLayout {
        val backBtn = FrameLayout(this).apply {
            background = circle(TILE_BG, TILE_STROKE)
            addView(IconView(this@FloatingPanelService, Glyph.BACK).apply { tint = TEXT },
                FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
            pressable(back)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(backBtn, lp(dp(36), dp(36)))
            addView(text(title, 15f, TEXT, true).apply { gravity = Gravity.CENTER }, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            if (toggle != null) addView(toggle, lp(dp(46), dp(26)).apply { leftMargin = dp(0) })
            else addView(View(this@FloatingPanelService), lp(dp(36), dp(36)))
        }
    }

    private fun circleButton(content: View, onClick: () -> Unit): FrameLayout {
        val ringView = FrameLayout(this).apply {
            background = circle(TILE_BG, TILE_STROKE)
            addView(content, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            pressable(onClick)
        }
        return FrameLayout(this).apply {
            addView(ringView, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        }
    }

    private fun setCircleSelected(cell: FrameLayout, selected: Boolean) {
        cell.getChildAt(0).background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(TILE_BG)
            setStroke(dp(if (selected) 2 else 1), if (selected) Color.WHITE else TILE_STROKE)
        }
    }

    private fun weightRow(heightPx: Int, vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach { addView(it, lp(0, heightPx, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }) }
        }

    private fun outlineButton(label: String, onClick: () -> Unit): TextView =
        text(label, 12f, TEXT, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
            background = rounded(Color.TRANSPARENT, 22, Color.argb(200, 237, 239, 242))
            pressable(onClick)
        }

    private fun labeled(label: String, v: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text(label, 11f, DIM))
            addView(v, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)).apply { topMargin = dp(4) })
        }

    private fun featureCard(glyph: Glyph, title: String, status: TextView, onClick: () -> Unit): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text(title, 14f, TEXT, true))
            addView(status)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            background = cutBg(TILE_BG, TILE_STROKE, 8)
            addView(IconView(this@FloatingPanelService, glyph).apply { tint = ICON }, lp(dp(30), dp(30)).apply { rightMargin = dp(12) })
            addView(col, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(IconView(this@FloatingPanelService, Glyph.BACK).apply {
                tint = DIM
                rotation = 180f
            }, lp(dp(16), dp(16)))
            pressable(onClick)
        }
    }

    private fun buildFeaturesPage(): ScrollView {
        tvCrossStatus = text("Mati", 11f, DIM)
        tvMonStatus = text("Mati", 11f, DIM)
        tvFocusStatus = text("Mati", 11f, DIM)
        tvRecStatus = text("Tanpa suara", 11f, DIM)
        tvPingStatus = text("Mati", 11f, DIM)
        tvMusicStatus = text("Belum ada lagu", 11f, DIM)
        tvLiveStatus = text("Mati", 11f, DIM)
        tvAiStatus = text("Offline", 11f, DIM)
        tvMapStatus = text("Mati", 11f, DIM)
        tvWinStatus = text("Ukuran 60%", 11f, DIM)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pageHeader("Semua fitur", { showPage(Page.MAIN, back = true) }, null), margins(4))
        col.addView(featureCard(Glyph.CROSSHAIR, "Crosshair", tvCrossStatus) { showPage(Page.CROSSHAIR) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.MONITOR, "Monitor", tvMonStatus) { showPage(Page.MONITOR) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.TAP, "Fokus game", tvFocusStatus) { showPage(Page.FOCUS) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.REC, "Rekam layar", tvRecStatus) { showPage(Page.REC) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.PING, "Ping rendah", tvPingStatus) { showPage(Page.PING) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.NOTE, "Pemutar musik", tvMusicStatus) { showPage(Page.MUSIC) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.MONITOR, "Overlay live", tvLiveStatus) { showPage(Page.LIVE) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.CHIP, "Asisten AI", tvAiStatus) { showPage(Page.AI) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.TAP, "Mapping keyboard/mouse", tvMapStatus) { showPage(Page.MAP) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        col.addView(featureCard(Glyph.WINDOW, "Jendela mengambang", tvWinStatus) { showPage(Page.WINDOW) },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        return pageScroll(col)
    }

    private fun buildCrosshairPage(): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swCrosshair = ToggleSwitch(this).apply {
            onToggle = { on ->
                gs().chEnabled = on
                applyCrosshair()
                refreshCrosshairUi()
            }
        }
        col.addView(pageHeader("Crosshair", { showPage(Page.FEATURES, back = true) }, swCrosshair), margins(4))

        col.addView(sectionLabel("Gaya"))
        stylePreviews.clear()
        styleCells.clear()
        val styleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 5) {
            val pv = CrosshairView(this).apply {
                style = i
                color = Color.WHITE
                shapeSizePx = dp(20)
                padPx = 0
            }
            stylePreviews.add(pv)
            val cell = circleButton(pv) {
                gs().chStyle = i
                applyCrosshair()
                refreshCrosshairUi()
            }
            styleCells.add(cell)
            styleRow.addView(cell, lp(0, dp(46), 1f))
        }
        col.addView(styleRow, margins(2))

        col.addView(sectionLabel("Warna"))
        chColorCells.clear()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chColors.forEachIndexed { i, colr ->
            val pv = CrosshairView(this).apply {
                style = 0
                color = colr
                shapeSizePx = dp(20)
                padPx = 0
            }
            val cell = circleButton(pv) {
                gs().chColor = colr
                applyCrosshair()
                refreshCrosshairUi()
            }
            chColorCells.add(cell)
            colorRow.addView(cell, lp(0, dp(44), 1f))
        }
        col.addView(colorRow, margins(2))

        slChSize = PillSlider(this, Glyph.CROSSHAIR).apply {
            onChange = { p, user ->
                if (user) {
                    gs().chSize = p
                    applyCrosshair()
                }
            }
        }
        slChOpacity = PillSlider(this, Glyph.OPACITY).apply {
            onChange = { p, user ->
                if (user) {
                    gs().chOpacity = p
                    applyCrosshair()
                }
            }
        }
        col.addView(weightRow(dp(62), labeled("Ukuran", slChSize), labeled("Opasitas", slChOpacity)))
        col.addView(weightRow(
            dp(44),
            outlineButton("POSISI") { startEditCrosshair() },
            outlineButton("DEFAULT") {
                gs().resetCrosshair()
                applyCrosshair()
                refreshCrosshairUi()
            }
        ))
        return pageScroll(col)
    }

    private fun refreshCrosshairUi() {
        val g = gs()
        swCrosshair.accent = accent
        swCrosshair.setCheckedSilently(g.chEnabled)
        styleCells.forEachIndexed { i, c -> setCircleSelected(c, i == g.chStyle) }
        stylePreviews.forEach { it.color = g.chColor }
        chColorCells.forEachIndexed { i, c -> setCircleSelected(c, chColors[i] == g.chColor) }
        slChSize.setProgressSilently(g.chSize)
        slChOpacity.setProgressSilently(g.chOpacity)
    }

    private fun monChip(id: String): LinearLayout {
        val meta = hudMeta.getValue(id)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(8), 0)
            addView(IconView(this@FloatingPanelService, meta.first).apply { tint = ICON }, lp(dp(18), dp(18)).apply { rightMargin = dp(8) })
            addView(text(meta.second, 12f, DIM).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            pressable { toggleMonItem(id) }
        }
        monChips[id] = box
        return box
    }

    private fun toggleMonItem(id: String) {
        val g = gs()
        val items = g.monItems.toMutableList()
        if (id in items) {
            items.remove(id)
        } else {
            if (items.size >= 4) {
                toast("Maksimal 4 item")
                return
            }
            items.add(id)
        }
        g.monItems = items
        applyMonitor()
        refreshMonitorUi()
    }

    private fun buildMonitorPage(): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swMonitor = ToggleSwitch(this).apply {
            onToggle = { on ->
                gs().monEnabled = on
                applyMonitor()
                refreshMonitorUi()
            }
        }
        col.addView(pageHeader("Monitor", { showPage(Page.FEATURES, back = true) }, swMonitor), margins(4))
        col.addView(sectionLabel("Tampilkan (maksimal 4)"))
        monChips.clear()
        hudMeta.keys.toList().chunked(2).forEach { pair ->
            val views = pair.map { monChip(it) }
            col.addView(weightRow(dp(40), *views.toTypedArray()))
        }
        col.addView(sectionLabel("Warna"))
        monColorCells.clear()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        monColors.forEachIndexed { i, colr ->
            val dot = View(this).apply { background = circle(colr) }
            val cell = circleButton(dot) {
                gs().monColor = colr
                applyMonitor()
                refreshMonitorUi()
            }
            monColorCells.add(cell)
            colorRow.addView(cell, lp(0, dp(44), 1f))
        }
        col.addView(colorRow, margins(2))
        col.addView(sectionLabel("Ukuran"))
        monSizeChips.clear()
        val sizeChips = listOf("Kecil", "Sedang", "Besar").mapIndexed { i, label ->
            val t = text(label, 12f, TEXT).apply {
                gravity = Gravity.CENTER
                pressable {
                    gs().monSize = i
                    applyMonitor()
                    refreshMonitorUi()
                }
            }
            monSizeChips.add(t)
            t
        }
        col.addView(weightRow(dp(38), *sizeChips.toTypedArray()))
        col.addView(weightRow(
            dp(44),
            outlineButton("POSISI") { startEditMonitor() },
            outlineButton("DEFAULT") {
                gs().resetMonitor()
                applyMonitor()
                refreshMonitorUi()
            }
        ))
        return pageScroll(col)
    }

    private fun refreshMonitorUi() {
        val g = gs()
        swMonitor.accent = accent
        swMonitor.setCheckedSilently(g.monEnabled)
        val items = g.monItems
        monChips.forEach { (id, chip) ->
            val sel = id in items
            chip.background = cutBg(if (sel) withAlpha(accent, 0.2f) else TILE_BG, if (sel) accent else TILE_STROKE, 7)
            (chip.getChildAt(0) as IconView).tint = if (sel) accent else ICON
            (chip.getChildAt(1) as TextView).setTextColor(if (sel) TEXT else DIM)
        }
        monColorCells.forEachIndexed { i, c -> setCircleSelected(c, monColors[i] == g.monColor) }
        monSizeChips.forEachIndexed { i, t ->
            val sel = i == g.monSize
            t.background = cutBg(if (sel) withAlpha(accent, 0.2f) else TILE_BG, if (sel) accent else TILE_STROKE, 6)
            t.setTextColor(if (sel) TEXT else DIM)
        }
    }

    // ------------------------------------------------------------ pengubah suara & jendela mengambang

    private fun chipStyle(t: TextView, selected: Boolean) {
        t.background = cutBg(if (selected) withAlpha(accent, 0.2f) else TILE_BG, if (selected) accent else TILE_STROKE, 6)
        t.setTextColor(if (selected) TEXT else DIM)
    }

    private fun buildWindowPage(): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pageHeader("Jendela mengambang", { showPage(Page.FEATURES, back = true) }, null), margins(4))
        col.addView(text(
            "Atur ukuran jendela aplikasi yang dibuka dari dock. Ukuran diterapkan saat aplikasi dibuka, " +
                "atau tekan TERAPKAN untuk jendela yang sedang terbuka. Seret bar putih " +
                "di atas jendela untuk memindahkannya, seret tombol putih di pojok kanan bawah untuk mengubah ukuran " +
                "(ketuk x pada bar untuk menyembunyikan; TOMBOL JENDELA memunculkannya lagi).",
            10.5f, DIM
        ).apply { setPadding(dp(6), dp(4), dp(6), dp(2)) })

        col.addView(sectionLabel("Rasio"))
        ratioChips.clear()
        val rc = listOf("Potret", "Persegi", "Lanskap", "3:4").mapIndexed { i, name ->
            val t = text(name, 12f, TEXT).apply {
                gravity = Gravity.CENTER
                pressable {
                    gs().floatRatio = i
                    refreshWindowUi()
                }
            }
            ratioChips.add(t)
            t
        }
        col.addView(weightRow(dp(40), *rc.toTypedArray()))

        col.addView(sectionLabel("Ukuran"))
        sizeChips.clear()
        val presets = listOf("Kecil" to 15, "Sedang" to 55, "Besar" to 100)
        val sc = presets.map { (name, value) ->
            val t = text(name, 12f, TEXT).apply {
                gravity = Gravity.CENTER
                pressable {
                    gs().floatScale = value
                    refreshWindowUi()
                    resizeFloatingNow()
                }
            }
            sizeChips.add(t)
            t
        }
        col.addView(weightRow(dp(40), *sc.toTypedArray()))
        slFloatScale = PillSlider(this, Glyph.WINDOW).apply {
            onChange = { p, user -> if (user) gs().floatScale = p }
        }
        col.addView(weightRow(dp(44), slFloatScale))
        col.addView(weightRow(
            dp(44),
            outlineButton("TERAPKAN") { resizeFloatingNow() },
            outlineButton("TUTUP") { recoverScreen() }
        ))
        col.addView(weightRow(dp(44), outlineButton("TOMBOL JENDELA") { toggleFloatHandle() }, outlineButton("DIAGNOSA") { diagnoseFloat() }))
        col.addView(weightRow(dp(44), outlineButton("CEK DUKUNGAN") { checkFloatSupport() }, outlineButton("AKTIFKAN OPSI") { enableFloatOptions() }))
        tvFloatReport = text("", 10.5f, DIM).apply { setPadding(dp(6), dp(6), dp(6), dp(2)) }
        col.addView(tvFloatReport)
        col.addView(text(
            "Butuh Shizuku aktif dan opsi jendela freeform dinyalakan di Opsi pengembang (lihat Panduan awal di tab Atur). " +
                "Sebagian ROM tidak mengizinkan perubahan ukuran.",
            10f, DIM
        ).apply { setPadding(dp(6), dp(6), dp(6), dp(4)) })
        return pageScroll(col)
    }

    private fun refreshWindowUi() {
        val g = gs()
        ratioChips.forEachIndexed { i, t -> chipStyle(t, i == g.floatRatio) }
        val presetValues = listOf(15, 55, 100)
        sizeChips.forEachIndexed { i, t -> chipStyle(t, g.floatScale == presetValues[i]) }
        slFloatScale.setProgressSilently(g.floatScale)
    }

    // ------------------------------------------------------------ fokus game

    private fun focusRow(label: String, sw: ToggleSwitch): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(6), dp(8), dp(6), dp(4))
        addView(text(label, 12f, TEXT), lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(sw, lp(dp(46), dp(26)))
    }

    private fun buildFocusPage(): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swFocus = ToggleSwitch(this).apply { onToggle = { on -> applyFocus(on) } }
        col.addView(pageHeader("Fokus game", { showPage(Page.FEATURES, back = true) }, swFocus), margins(4))
        tvFocusInfo = text("", 11f, DIM).apply { setPadding(dp(6), dp(4), dp(6), dp(2)) }
        col.addView(tvFocusInfo)

        col.addView(sectionLabel("Yang diatur saat fokus"))
        swFocusDnd = ToggleSwitch(this).apply { onToggle = { on -> gs().focusDnd = on; reapplyFocus() } }
        swFocusHeads = ToggleSwitch(this).apply { onToggle = { on -> gs().focusHeads = on; reapplyFocus() } }
        swFocusBright = ToggleSwitch(this).apply { onToggle = { on -> gs().focusBright = on; reapplyFocus() } }
        col.addView(focusRow("Jangan ganggu (prioritas)", swFocusDnd))
        col.addView(focusRow("Matikan notifikasi pop-up", swFocusHeads))
        col.addView(focusRow("Kecerahan otomatis mati", swFocusBright))

        col.addView(text(
            "Saat dinyalakan, muncul animasi \"FOKUS AKTIF\" dan hal-hal di atas diterapkan lewat Shizuku. Saat " +
                "dimatikan, semuanya dikembalikan persis seperti sebelumnya. Tidak menyentuh berkas game.",
            10.5f, DIM
        ).apply { setPadding(dp(6), dp(8), dp(6), dp(4)) })
        return pageScroll(col)
    }

    private fun reapplyFocus() {
        if (gs().focusActive) applyFocus(true) else refreshFocusUi()
    }

    private fun focusSummary(g: GameSettings): String {
        val parts = ArrayList<String>()
        if (g.focusDnd) parts.add("JANGAN GANGGU")
        if (g.focusHeads) parts.add("NOTIF MATI")
        if (g.focusBright) parts.add("KECERAHAN MANUAL")
        return parts.joinToString("  •  ")
    }

    private fun applyFocus(on: Boolean) {
        if (!ShizukuHelper.hasPermission()) {
            toast("Aktifkan Shizuku dulu (tab Atur).")
            refreshFocusUi()
            return
        }
        val g = gs()
        executor.execute {
            val r = if (on) ShellTools.focusOn(g) else ShellTools.focusOff(g)
            handler.post {
                refreshFocusUi()
                if (!r.ok) {
                    toast("Gagal: ${r.error}")
                } else if (on) {
                    if (expanded) toggle()
                    showFocusBanner("FOKUS AKTIF", focusSummary(g))
                } else {
                    toast("Fokus dimatikan, pengaturan dikembalikan")
                }
            }
        }
    }

    private fun refreshFocusUi() {
        val g = gs()
        swFocus.accent = accent
        swFocusDnd.accent = accent
        swFocusHeads.accent = accent
        swFocusBright.accent = accent
        swFocus.setCheckedSilently(g.focusActive)
        swFocusDnd.setCheckedSilently(g.focusDnd)
        swFocusHeads.setCheckedSilently(g.focusHeads)
        swFocusBright.setCheckedSilently(g.focusBright)
        tvFocusStatus.text = if (g.focusActive) "Aktif" else "Mati"
        tvFocusInfo.text = if (!ShizukuHelper.hasPermission()) "Shizuku belum aktif. Nyalakan Shizuku dulu."
        else if (g.focusActive) "Status: fokus aktif" else "Status: mati"
        tvFocusInfo.setTextColor(
            if (!ShizukuHelper.hasPermission()) WARN else if (g.focusActive) OK else DIM
        )
    }

    private fun showFocusBanner(title: String, sub: String) {
        removeFocusBanner()
        val v = FocusBannerView(this, title, sub)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, dp(150), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(30)
            useFullScreenArea()
        }
        try {
            wm.addView(v, p)
            focusBanner = v
            v.start { removeFocusBanner() }
        } catch (_: Exception) {
        }
    }

    private fun removeFocusBanner() {
        focusBanner?.let {
            it.cancel()
            removeSafely(it)
        }
        focusBanner = null
    }

    // ------------------------------------------------------------ rekam layar

    private fun recStatusText(g: GameSettings): String = when {
        g.recDevice && g.recMic -> "Perangkat + mik"
        g.recDevice -> "Suara perangkat"
        g.recMic -> "Mikrofon"
        else -> "Tanpa suara"
    }

    private fun buildRecPage(): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pageHeader("Rekam layar", { showPage(Page.FEATURES, back = true) }, null), margins(4))
        col.addView(sectionLabel("Suara yang direkam"))
        swRecDev = ToggleSwitch(this).apply { onToggle = { on -> gs().recDevice = on; refreshRecUi() } }
        swRecMic = ToggleSwitch(this).apply { onToggle = { on -> gs().recMic = on; refreshRecUi() } }
        col.addView(focusRow("Suara perangkat (suara game)", swRecDev))
        col.addView(focusRow("Suara mikrofon", swRecMic))
        col.addView(text(
            "Suara perangkat memakai fitur Android 10 ke atas; sebagian game melarang suaranya direkam sehingga " +
                "hasilnya senyap. Mikrofon merekam suara sekitar dan voice chat. Pakai headset agar suara game " +
                "tidak terekam dua kali lewat mikrofon. Izin mikrofon diminta saat mulai merekam pertama kali, " +
                "dan rekaman dengan suara perangkat diproses beberapa detik setelah dihentikan.",
            10.5f, DIM
        ).apply { setPadding(dp(6), dp(8), dp(6), dp(4)) })
        col.addView(weightRow(dp(44), outlineButton("MULAI / BERHENTI REKAM") { toggleRecord() }))
        return pageScroll(col)
    }

    private fun refreshRecUi() {
        val g = gs()
        swRecDev.accent = accent
        swRecMic.accent = accent
        swRecDev.setCheckedSilently(g.recDevice)
        swRecMic.setCheckedSilently(g.recMic)
        tvRecStatus.text = recStatusText(g)
    }

    // ------------------------------------------------------------ ping rendah

    private fun buildPingPage(): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swPing = ToggleSwitch(this).apply { onToggle = { on -> applyPing(on) } }
        col.addView(pageHeader("Ping rendah", { showPage(Page.FEATURES, back = true) }, swPing), margins(4))
        tvPingInfo = text("", 11f, DIM).apply { setPadding(dp(6), dp(4), dp(6), dp(2)) }
        col.addView(tvPingInfo)
        col.addView(text(
            "Mengunci Wi-Fi ke mode latensi rendah supaya sinyal tidak masuk mode hemat daya yang menambah jeda. " +
                "Aktif selama Game Space berjalan dan mati otomatis saat Game Space dimatikan.",
            10.5f, DIM
        ).apply { setPadding(dp(6), dp(4), dp(6), dp(2)) })
        col.addView(weightRow(dp(44), outlineButton("UJI PING") { testPing() }))
        tvPingResult = text("", 12f, TEXT).apply { setPadding(dp(6), dp(6), dp(6), dp(2)) }
        col.addView(tvPingResult)
        col.addView(text(
            "Catatan: hanya berpengaruh di Wi-Fi, tidak di data seluler, dan tidak mempercepat internet dari operator. " +
                "Efeknya terasa kalau lag datang dari Wi-Fi HP, bukan dari server game. Bandingkan hasil UJI PING " +
                "sebelum dan sesudah menyalakan. Shizuku aktif membuat mode ini lebih kuat.",
            10f, DIM
        ).apply { setPadding(dp(6), dp(6), dp(6), dp(4)) })
        return pageScroll(col)
    }

    private fun applyPing(on: Boolean) {
        val g = gs()
        if (on) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
            if (wm == null) {
                toast("Wi-Fi tidak tersedia di HP ini")
                refreshPingUi()
                return
            }
            try {
                val mode = if (Build.VERSION.SDK_INT >= 29) android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                else android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF
                val lock = wifiLock ?: wm.createWifiLock(mode, "aisz:ping").also {
                    it.setReferenceCounted(false)
                    wifiLock = it
                }
                if (!lock.isHeld) lock.acquire()
            } catch (e: Exception) {
                toast("Gagal mengunci Wi-Fi: ${e.message}")
                g.pingLow = false
                refreshPingUi()
                return
            }
        } else {
            try {
                wifiLock?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
        }
        g.pingLow = on
        refreshPingUi()
        slowExecutor.execute {
            val r = if (ShizukuHelper.hasPermission()) ShellTools.setWifiLowLatency(on) else null
            handler.post {
                toast(
                    when {
                        !on -> "Ping rendah dimatikan"
                        r == null -> "Ping rendah aktif (kunci Wi-Fi). Nyalakan Shizuku untuk mode yang lebih kuat."
                        r.ok -> "Ping rendah aktif"
                        else -> "Kunci Wi-Fi aktif. Mode paksa gagal: ${r.error}"
                    }
                )
            }
        }
    }

    private fun testPing() {
        tvPingResult.text = "Mengukur..."
        slowExecutor.execute {
            val nm = NetworkMonitor(this)
            val samples = (1..5).mapNotNull { nm.pingMs() }
            handler.post {
                tvPingResult.text = if (samples.isEmpty()) {
                    "Ping gagal. Periksa koneksi internet."
                } else {
                    "Ping rata-rata ${samples.average().toInt()} ms (terendah ${samples.min()}, tertinggi ${samples.max()}), " +
                        "${samples.size} dari 5 berhasil"
                }
            }
        }
    }

    private fun refreshPingUi() {
        val g = gs()
        swPing.accent = accent
        swPing.setCheckedSilently(g.pingLow)
        tvPingStatus.text = if (g.pingLow) "Aktif" else "Mati"
        tvPingInfo.text = if (g.pingLow) "Status: aktif (Wi-Fi dikunci mode latensi rendah)" else "Status: mati"
        tvPingInfo.setTextColor(if (g.pingLow) OK else DIM)
    }

    // ------------------------------------------------------------ pemutar musik

    private fun fmtTime(ms: Int): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun buildMusicPage(): ScrollView {
        MusicEngine.ensureLoaded(this)
        MusicEngine.onLibraryChanged = {
            if (page == Page.MUSIC) refreshMusicUi()
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pageHeader("Pemutar musik", { showPage(Page.FEATURES, back = true) }, null), margins(4))

        musicDisc = MusicDiscView(this)
        col.addView(musicDisc, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(190)))
        tvMusicTitle = text("Belum ada lagu", 14f, TEXT, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }
        col.addView(tvMusicTitle)
        tvMusicTime = text("00:00 / 00:00", 11f, DIM).apply { gravity = Gravity.CENTER }
        col.addView(tvMusicTime)
        slMusicSeek = PillSlider(this, Glyph.TIMER).apply {
            onChange = { pr, user ->
                if (user) {
                    musicSeekAt = System.currentTimeMillis()
                    MusicEngine.seekToFraction(pr / 100f)
                }
            }
        }
        col.addView(slMusicSeek, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(30)).apply { setMargins(dp(8), dp(6), dp(8), dp(6)) })

        tvMusicPlay = outlineButton("\u25B6 PUTAR") {
            MusicEngine.toggle(this)
            updateMusicLive()
        }
        col.addView(
            weightRow(
                dp(44),
                outlineButton("\u25C0\u25C0") { MusicEngine.prev(this); updateMusicLive() },
                tvMusicPlay,
                outlineButton("\u25B6\u25B6") { MusicEngine.next(this); updateMusicLive() },
                outlineButton("\u25A0 STOP") { MusicEngine.stop(this); updateMusicLive() }
            )
        )

        tvMusicSpeed = text("Kecepatan: 1.00x", 12f, TEXT).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(2))
        }
        col.addView(tvMusicSpeed)
        col.addView(
            weightRow(
                dp(40),
                outlineButton("LAMBAT \u2212") { stepMusicSpeed(-0.25f) },
                outlineButton("NORMAL 1x") { MusicEngine.setSpeed(this, 1f); updateMusicLive() },
                outlineButton("CEPAT +") { stepMusicSpeed(0.25f) }
            )
        )

        col.addView(sectionLabel("Daftar lagu"))
        musicList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(musicList)
        col.addView(weightRow(dp(44), outlineButton("TAMBAH LAGU") { openMusicPicker() }))
        col.addView(text(
            "Lagu diambil dari penyimpanan HP dan diputar tanpa internet. Ketuk judul untuk memutar, tanda x untuk " +
                "menghapus dari daftar (berkas aslinya tidak dihapus). Notifikasi muncul selama lagu aktif, dengan " +
                "tombol jeda, sebelumnya, berikutnya, dan berhenti. Musik tetap jalan walau panel ditutup.",
            10f, DIM
        ).apply { setPadding(dp(6), dp(8), dp(6), dp(4)) })
        return pageScroll(col)
    }

    private fun stepMusicSpeed(delta: Float) {
        val s = (Math.round((MusicEngine.speed + delta) * 4f) / 4f).coerceIn(0.5f, 2.0f)
        MusicEngine.setSpeed(this, s)
        updateMusicLive()
    }

    private fun openMusicPicker() {
        try {
            startActivity(Intent(this, MusicPickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            toast("Tidak bisa membuka pemilih berkas")
        }
    }

    private fun refreshMusicUi() {
        musicList.removeAllViews()
        val songs = MusicEngine.songs
        if (songs.isEmpty()) {
            musicList.addView(text("Belum ada lagu. Ketuk TAMBAH LAGU.", 11f, DIM).apply { setPadding(dp(8), dp(6), dp(8), dp(6)) })
        }
        songs.forEachIndexed { i, sg ->
            val current = i == MusicEngine.index
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(2), 0)
                background = rounded(if (current) Color.argb(60, 0, 183, 255) else Color.TRANSPARENT, 14)
            }
            val t = text(sg.title, 12f, if (current) accent else TEXT, current).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(11), 0, dp(11))
                pressable {
                    MusicEngine.play(this@FloatingPanelService, i)
                    refreshMusicUi()
                    updateMusicLive()
                }
            }
            val del = text("\u2715", 14f, DIM, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(11), dp(14), dp(11))
                pressable {
                    MusicEngine.remove(this@FloatingPanelService, i)
                    toast("Lagu dihapus dari daftar")
                    refreshMusicUi()
                    updateMusicLive()
                }
            }
            row.addView(t, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(del, lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            musicList.addView(row, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
        }
        updateMusicLive()
        handler.removeCallbacks(musicTick)
        handler.post(musicTick)
    }

    private fun updateMusicLive() {
        val playing = MusicEngine.isPlaying
        val dur = MusicEngine.durationMs
        val pos = MusicEngine.positionMs
        musicDisc.setPlaying(playing, MusicEngine.speed)
        tvMusicTitle.text = MusicEngine.title
            ?: if (MusicEngine.songs.isEmpty()) "Belum ada lagu" else "Pilih lagu untuk diputar"
        tvMusicTime.text = "${fmtTime(pos)} / ${fmtTime(dur)}"
        if (System.currentTimeMillis() - musicSeekAt > 1500L) {
            slMusicSeek.setProgressSilently(if (dur > 0) (pos * 100L / dur).toInt() else 0)
        }
        tvMusicPlay.text = if (playing) "\u275A\u275A JEDA" else "\u25B6 PUTAR"
        tvMusicSpeed.text = String.format(Locale.US, "Kecepatan: %.2fx", MusicEngine.speed)
        tvMusicStatus.text = when {
            playing -> "Memutar"
            MusicEngine.songs.isEmpty() -> "Belum ada lagu"
            else -> "${MusicEngine.songs.size} lagu"
        }
    }

    // ------------------------------------------------------------ overlay live (6 slot)

    private fun liveImageFile(i: Int) = java.io.File(filesDir, LiveBridge.imageName(i))

    private fun liveSourceReady(i: Int): Boolean {
        val g = gs()
        return if (g.liveMode(i) == 0) liveImageFile(i).exists() else g.liveUrl(i).isNotBlank()
    }

    private fun liveFlags(i: Int): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (liveEditSlot != i && gs().liveThrough(i)) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    /** Memasang, memperbarui, atau melepas semua slot sesuai pengaturan. rebuildSlot = isi slot itu (foto/link) diganti. */
    private fun applyLive(rebuildSlot: Int = -1) {
        if (!handleAdded) return
        val g = gs()
        for (i in 0 until GameSettings.LIVE_SLOTS) {
            if (!g.liveMaster || !g.liveOn(i) || !liveSourceReady(i)) {
                removeLiveSlot(i)
                continue
            }
            if (i == rebuildSlot) removeLiveSlot(i)
            applyLiveSlot(i)
        }
    }

    private fun applyLiveSlot(i: Int) {
        val g = gs()
        val (sw, sh) = screenSize()
        var root = liveRoots[i]
        val created = root == null
        if (root == null) {
            root = FrameLayout(this)
            root.clipToOutline = true
            root.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(14).toFloat())
                }
            }
            buildLiveContent(i, root)
            liveRoots[i] = root
        }
        val bg = if (g.liveTransparent(i)) Color.TRANSPARENT else Color.rgb(11, 15, 24)
        root.setBackgroundColor(bg)
        liveWebs[i]?.setBackgroundColor(bg)
        var p = liveParamsMap[i]
        if (p == null) {
            p = WindowManager.LayoutParams(0, 0, overlayType(), liveFlags(i), PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.START
                useFullScreenArea()
            }
            liveParamsMap[i] = p
        }
        p.width = (g.liveW(i) * sw).toInt().coerceIn(dp(100), sw)
        p.height = (g.liveH(i) * sh).toInt().coerceIn(dp(100), sh)
        p.x = (g.liveX(i) * sw).toInt().coerceIn(0, max(0, sw - p.width))
        p.y = (g.liveY(i) * sh).toInt().coerceIn(0, max(0, sh - p.height))
        p.flags = liveFlags(i)
        p.alpha = if (g.liveTransparent(i)) g.liveOpacity(i) / 100f else 1f
        val editing = liveEditSlot == i
        liveBars[i]?.visibility = if (editing) View.VISIBLE else View.GONE
        liveGrips[i]?.visibility = if (editing) View.VISIBLE else View.GONE
        try {
            if (created) {
                wm.addView(root, p)
                ensurePanelOnTop()
            } else {
                wm.updateViewLayout(root, p)
            }
        } catch (_: Exception) {
        }
    }

    private fun buildLiveContent(i: Int, root: FrameLayout) {
        val g = gs()
        root.removeAllViews()
        if (g.liveMode(i) == 0) {
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            try {
                val bmp = android.graphics.BitmapFactory.decodeFile(liveImageFile(i).absolutePath)
                if (bmp != null) iv.setImageBitmap(bmp)
            } catch (_: Exception) {
            }
            root.addView(iv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        } else {
            val wv = android.webkit.WebView(applicationContext)
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                setSupportZoom(false)
                mediaPlaybackRequiresUserGesture = true
            }
            val cm = android.webkit.CookieManager.getInstance()
            cm.setAcceptCookie(false)
            cm.setAcceptThirdPartyCookies(wv, false)
            wv.webViewClient = object : android.webkit.WebViewClient() {
                override fun shouldOverrideUrlLoading(view: android.webkit.WebView, request: android.webkit.WebResourceRequest): Boolean {
                    return request.url.scheme != "https" // hanya https; skema lain diblokir
                }
            }
            wv.isVerticalScrollBarEnabled = false
            wv.isHorizontalScrollBarEnabled = false
            wv.loadUrl(g.liveUrl(i))
            liveWebs[i] = wv
            root.addView(wv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        val bar = FloatHandleView(this).apply {
            onDrag = { dx, dy -> moveLive(i, dx, dy) }
            onDragEnd = { saveLive(i) }
            onClose = { setLiveEdit(i, false) }
        }
        root.addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(22), Gravity.TOP))
        liveBars[i] = bar
        val grip = FloatGripView(this).apply {
            onDrag = { dx, dy -> resizeLive(i, dx, dy) }
            onDragEnd = { saveLive(i) }
        }
        root.addView(grip, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(4), dp(4))
        })
        liveGrips[i] = grip
    }

    private fun removeLiveSlot(i: Int) {
        liveWebs.remove(i)?.let {
            try {
                it.stopLoading()
                it.loadUrl("about:blank")
                it.clearHistory()
                it.removeAllViews()
                it.destroy()
            } catch (_: Exception) {
            }
            try {
                android.webkit.CookieManager.getInstance().removeAllCookies(null)
                android.webkit.WebStorage.getInstance().deleteAllData()
            } catch (_: Exception) {
            }
        }
        liveRoots.remove(i)?.let { removeSafely(it) }
        liveParamsMap.remove(i)
        liveBars.remove(i)
        liveGrips.remove(i)
        if (liveEditSlot == i) liveEditSlot = -1
    }

    private fun removeAllLive() {
        for (i in 0 until GameSettings.LIVE_SLOTS) removeLiveSlot(i)
    }

    private fun setLiveEdit(i: Int, on: Boolean) {
        if (on && liveRoots[i] == null) {
            toast("Nyalakan slot ${i + 1} dulu")
            return
        }
        liveEditSlot = if (on) i else -1
        applyLive()
        if (on) {
            if (expanded) toggle()
            toast("Slot ${i + 1}: seret bar putih untuk memindah, bulatan di pojok untuk ukuran, x untuk selesai")
        } else {
            saveLive(i)
            toast("Posisi dan ukuran disimpan")
        }
    }

    private fun moveLive(i: Int, dx: Float, dy: Float) {
        val root = liveRoots[i] ?: return
        val p = liveParamsMap[i] ?: return
        liveRemX += dx
        liveRemY += dy
        val ix = liveRemX.toInt()
        val iy = liveRemY.toInt()
        liveRemX -= ix
        liveRemY -= iy
        val (sw, sh) = screenSize()
        p.x = (p.x + ix).coerceIn(0, max(0, sw - p.width))
        p.y = (p.y + iy).coerceIn(0, max(0, sh - p.height))
        try {
            wm.updateViewLayout(root, p)
        } catch (_: Exception) {
        }
    }

    private fun resizeLive(i: Int, dx: Float, dy: Float) {
        val root = liveRoots[i] ?: return
        val p = liveParamsMap[i] ?: return
        liveRemX += dx
        liveRemY += dy
        val ix = liveRemX.toInt()
        val iy = liveRemY.toInt()
        liveRemX -= ix
        liveRemY -= iy
        val (sw, sh) = screenSize()
        p.width = (p.width + ix).coerceIn(dp(100), max(dp(100), sw - p.x))
        p.height = (p.height + iy).coerceIn(dp(100), max(dp(100), sh - p.y))
        try {
            wm.updateViewLayout(root, p)
        } catch (_: Exception) {
        }
    }

    private fun saveLive(i: Int) {
        val p = liveParamsMap[i] ?: return
        val (sw, sh) = screenSize()
        gs().setLivePos(i, p.x.toFloat() / sw, p.y.toFloat() / sh, p.width.toFloat() / sw, p.height.toFloat() / sh)
    }

    private fun buildLivePage(): ScrollView {
        LiveBridge.onChanged = { slot ->
            handler.post {
                liveSlot = slot
                applyLive(rebuildSlot = slot)
                if (page == Page.LIVE) refreshLiveUi()
            }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swLive = ToggleSwitch(this).apply {
            onToggle = { on ->
                gs().liveMaster = on
                applyLive()
                refreshLiveUi()
            }
        }
        col.addView(pageHeader("Overlay live", { showPage(Page.FEATURES, back = true) }, swLive), margins(4))
        col.addView(text(
            "Sampai 6 overlay sekaligus. Tiap slot bisa foto atau halaman link (misalnya dari Sociabuzz) di atas game " +
                "untuk live streaming. Hanya tampilan: tidak login dan tidak terhubung ke akun mana pun. Sakelar di " +
                "kanan atas menyalakan atau mematikan semua slot.",
            10.5f, DIM
        ).apply { setPadding(dp(6), dp(4), dp(6), dp(2)) })

        col.addView(sectionLabel("Pilih slot"))
        liveSlotChips.clear()
        val slotRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until GameSettings.LIVE_SLOTS) {
            val t = text("${i + 1}", 13f, TEXT).apply {
                gravity = Gravity.CENTER
                pressable {
                    liveSlot = i
                    refreshLiveUi()
                }
            }
            liveSlotChips.add(t)
            slotRow.addView(t, lp(0, dp(40), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        col.addView(slotRow, margins(2))
        tvLiveSlotTitle = text("Slot 1", 13f, TEXT, true).apply { setPadding(dp(6), dp(8), dp(6), dp(2)) }
        col.addView(tvLiveSlotTitle)
        swLiveSlot = ToggleSwitch(this).apply {
            onToggle = { on ->
                gs().setLiveOn(liveSlot, on)
                if (on) gs().liveMaster = true
                if (on && !liveSourceReady(liveSlot)) toast("Pilih foto atau atur link dulu")
                applyLive()
                refreshLiveUi()
            }
        }
        col.addView(focusRow("Slot ini tampil", swLiveSlot))

        col.addView(sectionLabel("Sumber slot ini"))
        liveModeChips.clear()
        val chips = listOf("FOTO", "LINK").mapIndexed { m, name ->
            val t = text(name, 12f, TEXT).apply {
                gravity = Gravity.CENTER
                pressable {
                    gs().setLiveMode(liveSlot, m)
                    applyLive(rebuildSlot = liveSlot)
                    refreshLiveUi()
                }
            }
            liveModeChips.add(t)
            t
        }
        col.addView(weightRow(dp(40), chips[0], chips[1]))
        tvLiveInfo = text("", 11f, DIM).apply { setPadding(dp(6), dp(4), dp(6), dp(2)) }
        col.addView(tvLiveInfo)
        col.addView(weightRow(dp(44), outlineButton("PILIH FOTO") { pickLiveImage() }, outlineButton("ATUR LINK") { openLiveLink() }))

        swLiveTrans = ToggleSwitch(this).apply {
            onToggle = { on ->
                gs().setLiveTransparent(liveSlot, on)
                applyLive()
                refreshLiveUi()
            }
        }
        col.addView(focusRow("Transparan", swLiveTrans))
        tvLiveOpacity = text("", 11f, DIM).apply { setPadding(dp(6), dp(2), dp(6), dp(2)) }
        col.addView(tvLiveOpacity)
        slLiveOpacity = PillSlider(this, Glyph.OPACITY).apply {
            onChange = { pr, user ->
                if (user) {
                    gs().setLiveOpacity(liveSlot, 20 + pr * 70 / 100)
                    applyLive()
                    updateLiveOpacityLabel()
                }
            }
        }
        col.addView(slLiveOpacity, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)).apply { setMargins(dp(8), dp(2), dp(8), dp(6)) })

        swLiveThrough = ToggleSwitch(this).apply {
            onToggle = { on ->
                gs().setLiveThrough(liveSlot, on)
                applyLive()
                refreshLiveUi()
            }
        }
        col.addView(focusRow("Tembus sentuhan", swLiveThrough))
        col.addView(text(
            "Tembus sentuhan: sentuhan ke game tetap sampai di bawah overlay. Matikan bila halaman link perlu diketuk. " +
                "Catatan Android 12+: overlay yang tidak transparan (atau lebih dari 80%) memblokir sentuhan di areanya, " +
                "jadi geser ke bagian layar yang tidak dipakai.",
            10f, DIM
        ).apply { setPadding(dp(6), dp(2), dp(6), dp(4)) })

        col.addView(weightRow(
            dp(44),
            outlineButton("ATUR POSISI DAN UKURAN") { setLiveEdit(liveSlot, liveEditSlot != liveSlot) },
            outlineButton("RESET POSISI") {
                gs().resetLivePos(liveSlot)
                applyLive()
                toast("Posisi slot ${liveSlot + 1} dikembalikan")
            }
        ))
        col.addView(text(
            "Link hanya https dan dimuat tanpa cookie, jadi tidak ada sesi login yang tersimpan; data halaman dihapus saat " +
                "slot dimatikan. Suara halaman tidak diputar otomatis. Tiap slot link memuat satu halaman web, jadi pakai " +
                "secukupnya: banyak slot link sekaligus memakai RAM dan baterai lebih banyak.",
            10f, DIM
        ).apply { setPadding(dp(6), dp(6), dp(6), dp(4)) })
        return pageScroll(col)
    }

    private fun updateLiveOpacityLabel() {
        val g = gs()
        tvLiveOpacity.text = if (g.liveTransparent(liveSlot)) "Opasitas: ${g.liveOpacity(liveSlot)}% (geser untuk mengubah)" else "Tidak transparan (opasitas 100%)"
    }

    private fun pickLiveImage() {
        try {
            startActivity(
                Intent(this, LiveImagePickActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(LiveBridge.EXTRA_SLOT, liveSlot)
            )
        } catch (_: Exception) {
            toast("Tidak bisa membuka pemilih foto")
        }
    }

    private fun openLiveLink() {
        try {
            startActivity(
                Intent(this, LiveLinkActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(LiveBridge.EXTRA_SLOT, liveSlot)
            )
        } catch (_: Exception) {
            toast("Tidak bisa membuka isian link")
        }
    }

    private fun refreshLiveUi() {
        val g = gs()
        val i = liveSlot
        swLive.accent = accent
        swLiveSlot.accent = accent
        swLiveTrans.accent = accent
        swLiveThrough.accent = accent
        swLive.setCheckedSilently(g.liveMaster)
        liveSlotChips.forEachIndexed { n, t ->
            t.text = if (g.liveOn(n)) "${n + 1}\u25CF" else "${n + 1}"
            chipStyle(t, n == i)
        }
        tvLiveSlotTitle.text = "Slot ${i + 1}" + if (g.liveOn(i)) " (tampil)" else " (mati)"
        swLiveSlot.setCheckedSilently(g.liveOn(i))
        swLiveTrans.setCheckedSilently(g.liveTransparent(i))
        swLiveThrough.setCheckedSilently(g.liveThrough(i))
        liveModeChips.forEachIndexed { m, t -> chipStyle(t, m == g.liveMode(i)) }
        tvLiveInfo.text = if (g.liveMode(i) == 0) {
            if (liveImageFile(i).exists()) "Foto terpasang. Ketuk PILIH FOTO untuk mengganti." else "Belum ada foto. Ketuk PILIH FOTO."
        } else {
            if (g.liveUrl(i).isBlank()) "Belum ada link. Ketuk ATUR LINK." else "Link: " + g.liveUrl(i).removePrefix("https://").take(46)
        }
        slLiveOpacity.setProgressSilently((g.liveOpacity(i) - 20) * 100 / 70)
        updateLiveOpacityLabel()
        val count = (0 until GameSettings.LIVE_SLOTS).count { g.liveOn(it) }
        tvLiveStatus.text = if (g.liveMaster && count > 0) "Tampil ($count)" else "Mati"
    }

    // ------------------------------------------------------------ asisten AI (obrolan di dalam panel)

    private fun imm() = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager

    /** Jendela panel normalnya tidak bisa menerima fokus; saat mengetik ia dibuat bisa fokus agar keyboard muncul. */
    private fun setPanelFocusable(on: Boolean) {
        if (panelFocusable == on || !::panelParams.isInitialized) return
        panelFocusable = on
        panelParams.flags = if (on) {
            panelParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() and
                WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM.inv()
        } else {
            panelParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        panelParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        if (::panel.isInitialized) {
            try {
                if (!on) imm().hideSoftInputFromWindow(panel.windowToken, 0)
                wm.updateViewLayout(panel, panelParams)
            } catch (_: Exception) {
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun styledInput(hintText: String, password: Boolean): android.widget.EditText =
        android.widget.EditText(this).apply {
            hint = hintText
            setHintTextColor(DIM)
            setTextColor(TEXT)
            textSize = 13f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                (if (password) android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD else 0)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND or
                android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
            background = rounded(Color.TRANSPARENT, 16, DIM)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnTouchListener { v, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                    setPanelFocusable(true)
                    v.post {
                        v.requestFocus()
                        imm().showSoftInput(v, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                    }
                }
                false
            }
        }

    private fun buildAiPage(): ScrollView {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pageHeader("Asisten AI", { showPage(Page.FEATURES, back = true) }, null), margins(4))
        tvAiMode = text("", 10.5f, DIM).apply { setPadding(dp(6), dp(2), dp(6), dp(2)) }
        col.addView(tvAiMode)

        aiInput = styledInput("Ketik perintah atau pertanyaan...", false).apply {
            setOnEditorActionListener { _, id, _ ->
                if (id == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                    sendAi()
                    true
                } else false
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(aiInput, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(outlineButton("KIRIM") { sendAi() }, lp(dp(76), dp(42)).apply { leftMargin = dp(6) })
        col.addView(row, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        })

        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Mode performa", "Mode hemat daya", "Mode seimbang", "Cek status HP", "Nyalakan fokus", "Putar musik", "Apa itu tekstur ringan?")
            .forEach { q ->
                val t = text(q, 11f, TEXT).apply {
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    chipStyle(this, false)
                    pressable {
                        aiInput.setText(q)
                        sendAi()
                    }
                }
                chipRow.addView(t, lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
            }
        col.addView(
            android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(chipRow)
            },
            lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), dp(2), dp(4), dp(4)) }
        )

        aiMsgs = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val (_, sh) = screenSize()
        aiScroll = ScrollView(this).apply { addView(aiMsgs) }
        col.addView(aiScroll, lp(LinearLayout.LayoutParams.MATCH_PARENT, max(dp(150), (sh * 0.4f).toInt())))
        addAiMsg(
            false,
            "Halo! Saya asisten AISZ. Minta saya mengatur mode (\"mode performa\"), menyalakan fitur (\"nyalakan fokus\"), " +
                "memutar musik, mengecek status HP, atau tanya apa saja soal AISZ GAME SPACE."
        )

        aiSettings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        swAiOnline = ToggleSwitch(this).apply {
            onToggle = { on ->
                if (on && gs().aiKey.isBlank()) {
                    toast("Isi kunci API dulu")
                } else {
                    gs().aiOnline = on
                }
                refreshAiUi()
            }
        }
        aiSettings.addView(focusRow("Pakai Claude online", swAiOnline))
        aiKeyInput = styledInput("Kunci API (sk-ant-...)", true)
        aiSettings.addView(aiKeyInput, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(6), dp(4), dp(6), dp(4))
        })
        tvAiKey = text("", 10.5f, DIM).apply { setPadding(dp(8), dp(2), dp(8), dp(2)) }
        aiSettings.addView(tvAiKey)
        aiSettings.addView(
            weightRow(
                dp(40),
                outlineButton("SIMPAN KUNCI") {
                    val k = aiKeyInput.text.toString().trim()
                    if (k.isNotEmpty()) {
                        gs().aiKey = k
                        toast("Kunci disimpan di HP ini")
                    }
                    aiKeyInput.setText("")
                    aiKeyInput.clearFocus()
                    setPanelFocusable(false)
                    refreshAiUi()
                },
                outlineButton("HAPUS KUNCI") {
                    gs().aiKey = ""
                    gs().aiOnline = false
                    aiKeyInput.setText("")
                    toast("Kunci dihapus")
                    refreshAiUi()
                }
            )
        )
        aiSettings.addView(text(
            "Opsional. Kunci API Anthropic milik lu sendiri disimpan hanya di HP ini dan hanya dikirim ke api.anthropic.com. " +
                "Yang dikirim: pesan lu dan ringkasan status HP. Pemakaian dikenai biaya sesuai akun lu. Asisten hanya boleh " +
                "menjalankan aksi daftar putih (ganti mode, ping, fokus, overlay, musik, bersihkan RAM).",
            10f, DIM
        ).apply { setPadding(dp(8), dp(4), dp(8), dp(4)) })
        col.addView(weightRow(dp(40), outlineButton("PENGATURAN CLAUDE ONLINE") {
            aiSettings.visibility = if (aiSettings.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }))
        col.addView(aiSettings)
        return pageScroll(col)
    }

    private fun addAiMsg(fromUser: Boolean, msg: String): TextView {
        val t = text(msg, 12f, TEXT).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(
                if (fromUser) Color.argb(60, 0, 183, 255) else Color.argb(255, 20, 28, 44), 14,
                if (fromUser) accent else Color.argb(90, 150, 170, 200)
            )
        }
        aiMsgs.addView(t, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            topMargin = dp(5)
            if (fromUser) leftMargin = dp(36) else rightMargin = dp(36)
        })
        aiScroll.post { aiScroll.fullScroll(View.FOCUS_DOWN) }
        return t
    }

    private fun sendAi() {
        val q = aiInput.text.toString().trim()
        if (q.isEmpty() || aiBusy) return
        aiInput.setText("")
        aiInput.clearFocus()
        setPanelFocusable(false)
        addAiMsg(true, q)
        val g = gs()
        val history = aiHistory.toList()
        aiHistory.add(true to q)
        while (aiHistory.size > 20) aiHistory.removeAt(0)
        if (g.aiOnline && g.aiKey.isNotBlank()) {
            aiBusy = true
            aiTyping = addAiMsg(false, "Mengetik...")
            val key = g.aiKey
            val sys = ClaudeClient.systemPrompt(AssistantEngine.statusText(this))
            Thread {
                val res = ClaudeClient.ask(key, sys, history, q)
                handler.post {
                    aiBusy = false
                    aiTyping?.let { aiMsgs.removeView(it) }
                    aiTyping = null
                    if (res.error != null) {
                        addAiMsg(false, "Claude online gagal: ${res.error}\nMemakai asisten offline.")
                        val local = AssistantEngine.interpret(q)
                        showAiReply(local.text, local.actions)
                    } else {
                        showAiReply(res.reply ?: "", res.actions)
                    }
                }
            }.start()
        } else {
            val local = AssistantEngine.interpret(q)
            showAiReply(local.text, local.actions)
        }
    }

    private fun showAiReply(text: String, actions: List<AssistantEngine.Action>) {
        if (text.isNotBlank()) {
            addAiMsg(false, text)
            aiHistory.add(false to text)
        }
        for (a in actions) {
            if (!AssistantEngine.isAllowed(a)) continue
            addAiMsg(false, "\u2713 " + runAssistantAction(a.name, a.arg))
        }
    }

    private fun refreshAiUi() {
        val g = gs()
        val online = g.aiOnline && g.aiKey.isNotBlank()
        swAiOnline.accent = accent
        swAiOnline.setCheckedSilently(online)
        tvAiMode.text = if (online) "Claude online (${ClaudeClient.MODEL})" else "Offline: tanpa internet"
        tvAiMode.setTextColor(if (online) OK else DIM)
        tvAiKey.text = if (g.aiKey.isBlank()) "Belum ada kunci tersimpan." else "Kunci tersimpan di HP ini."
        tvAiStatus.text = if (online) "Claude online" else "Offline"
    }

    /** Menjalankan aksi daftar putih dari asisten; dipanggil di thread utama. */
    private fun runAssistantAction(name: String, arg: String): String {
        val on = arg == "on"
        return when (name) {
            "status" -> AssistantEngine.statusText(this)
            "set_mode" -> {
                val p = when (arg) {
                    "hemat" -> GamingProfile.HEMAT
                    "seimbang" -> GamingProfile.SEIMBANG
                    "performa" -> GamingProfile.PERFORMA
                    else -> return "Mode tidak dikenal: $arg"
                }
                selectMode(p)
                "Mode ${p.label} diterapkan"
            }
            "ping" -> {
                applyPing(on)
                if (on) "Ping rendah dinyalakan" else "Ping rendah dimatikan"
            }
            "fokus" -> {
                applyFocus(on)
                if (on) "Fokus game dinyalakan" else "Fokus game dimatikan"
            }
            "overlay" -> {
                gs().liveMaster = on
                applyLive()
                if (on) "Overlay live dinyalakan (slot yang aktif tampil)" else "Semua overlay live disembunyikan"
            }
            "musik" -> when (arg) {
                "play" -> {
                    if (!MusicEngine.isPlaying) MusicEngine.toggle(this)
                    "Memutar musik"
                }
                "pause" -> {
                    if (MusicEngine.isPlaying) MusicEngine.toggle(this)
                    "Musik dijeda"
                }
                "next" -> {
                    MusicEngine.next(this)
                    "Lagu berikutnya"
                }
                "prev" -> {
                    MusicEngine.prev(this)
                    "Lagu sebelumnya"
                }
                else -> {
                    MusicEngine.stop(this)
                    "Musik dihentikan"
                }
            }
            "bersihkan_ram" -> {
                cleanMemory()
                "Membersihkan memori..."
            }
            "matikan_tekstur" -> {
                val g = GameSettings(this)
                slowExecutor.execute { ShellTools.revertGameFeatures(g) }
                "Tekstur Ringan dan Turunkan Resolusi dimatikan"
            }
            else -> "Aksi tidak dikenal: $name"
        }
    }

    // ------------------------------------------------------------ mapping keyboard/mouse (OTG)

    private fun saveMap() {
        val (sw, sh) = screenSize()
        mapCfg.w = max(sw, sh)
        mapCfg.h = min(sw, sh)
        try {
            mapCtl.save(mapCfg)
        } catch (_: Exception) {
            toast("Gagal menyimpan pengaturan mapping")
        }
    }

    private fun buildMapPage(): ScrollView {
        mapCfg = mapCtl.load()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swMap = ToggleSwitch(this).apply {
            onToggle = { on ->
                mapCfg.enabled = on
                saveMap()
                if (on && !mapCtl.isRunning()) startMapServer()
                refreshMapUi()
            }
        }
        col.addView(pageHeader("Mapping keyboard/mouse", { showPage(Page.FEATURES, back = true) }, swMap), margins(4))
        col.addView(text(
            "Mengubah keyboard dan mouse OTG menjadi sentuhan di layar game: W A S D menjadi joystick, gerak mouse menjadi " +
                "geser kamera, klik kiri menembak, klik kanan membidik, dan tombol lain menekan titik yang lu tentukan. " +
                "Butuh Shizuku dan hanya untuk game landscape.",
            10.5f, DIM
        ).apply { setPadding(dp(6), dp(4), dp(6), dp(2)) })
        tvMapInfo = text("", 11f, TEXT).apply { setPadding(dp(8), dp(6), dp(8), dp(4)) }
        col.addView(tvMapInfo)
        col.addView(weightRow(dp(44), outlineButton("MULAI SERVER") { startMapServer() }, outlineButton("HENTIKAN SERVER") { stopMapServer() }))

        col.addView(sectionLabel("Tombol (ketuk tombolnya lalu tekan keyboard)"))
        mapKeysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(mapKeysBox)

        tvMapSens = text("", 11f, DIM).apply { setPadding(dp(8), dp(8), dp(8), dp(2)) }
        col.addView(tvMapSens)
        slMapSens = PillSlider(this, Glyph.MOVE).apply {
            onChange = { pr, user ->
                if (user) {
                    mapCfg.sens = 0.5f + pr * 2.5f / 100f
                    saveMap()
                    updateMapSensLabel()
                }
            }
        }
        col.addView(slMapSens, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)).apply { setMargins(dp(8), dp(2), dp(8), dp(4)) })
        col.addView(text("Radius joystick", 11f, DIM).apply { setPadding(dp(8), dp(4), dp(8), dp(2)) })
        slMapJoy = PillSlider(this, Glyph.TAP).apply {
            onChange = { pr, user ->
                if (user) {
                    mapCfg.joyR = 0.06f + pr * 0.19f / 100f
                    saveMap()
                    if (mapEdit) showMapMarkers()
                }
            }
        }
        col.addView(slMapJoy, lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)).apply { setMargins(dp(8), dp(2), dp(8), dp(4)) })

        col.addView(weightRow(
            dp(44),
            outlineButton("ATUR TITIK DI LAYAR") { if (mapEdit) stopMapEdit() else startMapEdit() },
            outlineButton("RESET KE AWAL") {
                val on = mapCfg.enabled
                mapCfg = MapConfig()
                mapCfg.enabled = on
                saveMap()
                refreshMapUi()
                toast("Pemetaan dikembalikan ke awal")
            }
        ))
        col.addView(text(
            "Cara pakai: 1) colok keyboard/mouse OTG, 2) MULAI SERVER, 3) ATUR TITIK DI LAYAR saat game landscape terbuka lalu " +
                "seret tiap penanda ke tombol game yang sesuai, 4) nyalakan sakelar di kanan atas. Tekan tombol toggle di keyboard " +
                "untuk menjeda atau melanjutkan mapping; saat jeda, keyboard dan mouse kembali normal untuk HP.",
            10f, DIM
        ).apply { setPadding(dp(6), dp(8), dp(6), dp(2)) })
        col.addView(text(
            "Penting: sentuhan disuntik lewat Shizuku, bukan dari layar asli. Game kompetitif (termasuk Free Fire) bisa " +
                "menganggapnya curang dan menjatuhkan sanksi akun. Pakai dengan risiko sendiri. Server berhenti otomatis " +
                "saat Game Space dimatikan; HENTIKAN SERVER mematikannya kapan saja.",
            10f, WARN
        ).apply { setPadding(dp(6), dp(4), dp(6), dp(4)) })
        return pageScroll(col)
    }

    private fun updateMapSensLabel() {
        tvMapSens.text = String.format(Locale.US, "Kepekaan kamera (mouse): %.1fx", mapCfg.sens)
    }

    private fun refreshMapKeys() {
        mapKeysBox.removeAllViews()
        fun row(label: String, code: Int, idx: Int, editable: Boolean) {
            val capturing = mapCaptureIdx == idx
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(4), 0)
                background = rounded(if (capturing) Color.argb(60, 0, 183, 255) else Color.TRANSPARENT, 14)
            }
            val t = text(label, 12f, TEXT).apply { setPadding(0, dp(11), 0, dp(11)) }
            val k = text(if (capturing) "tekan tombol..." else keyName(code), 12f, if (editable) accent else DIM, true).apply {
                setPadding(dp(10), dp(11), dp(10), dp(11))
                if (editable) pressable { startMapCapture(idx) }
            }
            r.addView(t, lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(k)
            mapKeysBox.addView(r, lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        }
        row("Toggle mapping (jeda/lanjut)", mapCfg.toggleKey, -1, true)
        row("Gerak (joystick)", 0, -3, false)
        mapCfg.keys.forEachIndexed { i, k -> row(k.label, k.code, i, true) }
    }

    private fun startMapCapture(idx: Int) {
        if (!mapCtl.isRunning()) {
            toast("Nyalakan server dulu (MULAI SERVER)")
            return
        }
        mapCaptureIdx = idx
        mapCaptureAt = System.currentTimeMillis()
        refreshMapKeys()
        toast("Tekan tombol di keyboard OTG...")
        handler.removeCallbacks(mapTick)
        handler.post(mapTick)
    }

    private fun pollMap() {
        val st = mapCtl.status()
        val running = mapCtl.isRunning()
        if (mapCaptureIdx != -2) {
            val at = st["lastkeyat"]?.toLongOrNull() ?: 0L
            val code = st["lastkey"]?.toIntOrNull() ?: 0
            if (running && at > mapCaptureAt && code > 0) {
                val used = mapCfg.usedCodes().toMutableList()
                val cur = if (mapCaptureIdx == -1) mapCfg.toggleKey else mapCfg.keys.getOrNull(mapCaptureIdx)?.code ?: -1
                used.remove(cur)
                if (code in used || code == 272 || code == 273) {
                    toast("Tombol itu sudah dipakai atau tidak bisa dipakai")
                } else if (mapCaptureIdx == -1) {
                    mapCfg.toggleKey = code
                    saveMap()
                } else {
                    mapCfg.keys.getOrNull(mapCaptureIdx)?.code = code
                    saveMap()
                }
                mapCaptureIdx = -2
                refreshMapKeys()
            } else if (System.currentTimeMillis() - mapCaptureAt > 8000L) {
                mapCaptureIdx = -2
                toast("Waktu habis, tidak ada tombol ditekan")
                refreshMapKeys()
            }
        }
        val names = (st["devices"] ?: "").split(';').filter { it.isNotBlank() }
        tvMapInfo.text = if (!running) {
            "Server: mati. Ketuk MULAI SERVER (butuh Shizuku aktif)."
        } else {
            "Server: berjalan\n" +
                "Perangkat: " + (if (names.isEmpty()) "belum ada keyboard/mouse OTG terbaca" else names.joinToString(", ")) + "\n" +
                "Mapping: " + (if (st["active"] == "1") "AKTIF" else "dijeda") + "  (toggle: " + keyName(mapCfg.toggleKey) + ")\n" +
                "Ambil alih perangkat: " + (st["grab"] ?: "0/0") + "\n" +
                "Suntik sentuhan: " + (st["inject"] ?: "-") + (if (st["limited"] == "1") "  (dibatasi)" else "")
        }
        tvMapStatus.text = if (mapCfg.enabled && running) (if (st["active"] == "1") "Aktif" else "Dijeda") else "Mati"
    }

    private fun refreshMapUi() {
        swMap.accent = accent
        swMap.setCheckedSilently(mapCfg.enabled)
        refreshMapKeys()
        updateMapSensLabel()
        slMapSens.setProgressSilently(((mapCfg.sens - 0.5f) * 100f / 2.5f).toInt().coerceIn(0, 100))
        slMapJoy.setProgressSilently(((mapCfg.joyR - 0.06f) * 100f / 0.19f).toInt().coerceIn(0, 100))
        pollMap()
        handler.removeCallbacks(mapTick)
        handler.post(mapTick)
    }

    private fun startMapServer() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Aktifkan Shizuku dulu (tab Atur)")
            return
        }
        if (mapCtl.isRunning()) {
            toast("Server sudah berjalan")
            return
        }
        saveMap()
        slowExecutor.execute {
            val r = mapCtl.start()
            try {
                Thread.sleep(1800)
            } catch (_: InterruptedException) {
            }
            handler.post {
                toast(if (mapCtl.isRunning()) "Server mapping berjalan" else "Server belum jalan: " + r.error.take(60))
                pollMap()
            }
        }
    }

    private fun stopMapServer() {
        try {
            mapCtl.requestQuit()
        } catch (_: Exception) {
        }
        mapCfg.enabled = false
        swMap.setCheckedSilently(false)
        toast("Server dihentikan")
        handler.postDelayed({ pollMap() }, 1200L)
    }

    // ---- penanda titik di layar

    private fun startMapEdit() {
        val (sw, sh) = screenSize()
        if (sw < sh) toast("Atur titik saat HP landscape (di dalam game)")
        mapEdit = true
        if (expanded) toggle()
        showMapMarkers()
        showMapDone()
        toast("Seret penanda ke tombol game, lalu ketuk SELESAI")
    }

    private fun stopMapEdit() {
        mapEdit = false
        removeMapMarkers()
        mapDone?.let { removeSafely(it) }
        mapDone = null
        saveMap()
        toast("Titik mapping disimpan")
    }

    private fun showMapMarkers() {
        removeMapMarkers()
        val (_, sh) = screenSize()
        addMapMarker("joy", "WASD", mapCfg.joyX, mapCfg.joyY, (mapCfg.joyR * sh).toInt())
        addMapMarker("look", "LIHAT", mapCfg.lookX, mapCfg.lookY, 0)
        addMapMarker("fire", "TEMBAK", mapCfg.fireX, mapCfg.fireY, 0)
        addMapMarker("scope", "BIDIK", mapCfg.scopeX, mapCfg.scopeY, 0)
        mapCfg.keys.forEachIndexed { i, k -> addMapMarker("k$i", keyName(k.code).take(5), k.x, k.y, 0) }
    }

    private fun addMapMarker(key: String, label: String, fx: Float, fy: Float, ringPx: Int) {
        val (sw, sh) = screenSize()
        val size = max(dp(48), ringPx * 2 + dp(8))
        val v = MapMarkerView(this, label, ringPx.toFloat())
        val p = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
            x = (fx * sw - size / 2f).toInt()
            y = (fy * sh - size / 2f).toInt()
        }
        v.onDrag = { dx, dy -> moveMapMarker(key, dx, dy) }
        v.onDragEnd = { saveMapMarker(key) }
        try {
            wm.addView(v, p)
            mapMarkers[key] = v
            mapMarkerParams[key] = p
        } catch (_: Exception) {
        }
    }

    private fun moveMapMarker(key: String, dx: Float, dy: Float) {
        val v = mapMarkers[key] ?: return
        val p = mapMarkerParams[key] ?: return
        val (sw, sh) = screenSize()
        p.x = (p.x + dx.toInt()).coerceIn(-p.width / 2, sw - p.width / 2)
        p.y = (p.y + dy.toInt()).coerceIn(-p.height / 2, sh - p.height / 2)
        try {
            wm.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    private fun saveMapMarker(key: String) {
        val p = mapMarkerParams[key] ?: return
        val (sw, sh) = screenSize()
        val fx = ((p.x + p.width / 2f) / sw).coerceIn(0f, 1f)
        val fy = ((p.y + p.height / 2f) / sh).coerceIn(0f, 1f)
        when {
            key == "joy" -> { mapCfg.joyX = fx; mapCfg.joyY = fy }
            key == "look" -> { mapCfg.lookX = fx; mapCfg.lookY = fy }
            key == "fire" -> { mapCfg.fireX = fx; mapCfg.fireY = fy }
            key == "scope" -> { mapCfg.scopeX = fx; mapCfg.scopeY = fy }
            key.startsWith("k") -> mapCfg.keys.getOrNull(key.substring(1).toIntOrNull() ?: -1)?.let { it.x = fx; it.y = fy }
        }
        saveMap()
    }

    private fun removeMapMarkers() {
        mapMarkers.values.forEach { removeSafely(it) }
        mapMarkers.clear()
        mapMarkerParams.clear()
    }

    private fun showMapDone() {
        mapDone?.let { removeSafely(it) }
        val tv = text("SELESAI", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12))
            background = rounded(withAlpha(accent, 0.92f), 24)
            setOnClickListener { stopMapEdit() }
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(24)
            useFullScreenArea()
        }
        try {
            wm.addView(tv, p)
            mapDone = tv
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ overlay crosshair & monitor

    private fun setTouchable(p: WindowManager.LayoutParams?, v: View?, touchable: Boolean) {
        if (p == null || v == null) return
        p.flags = if (touchable) {
            p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    private fun ensurePanelOnTop() {
        if (!panelAttached) return
        try {
            wm.removeView(panel)
            wm.addView(panel, panelParams)
        } catch (_: Exception) {
        }
    }

    private fun setOverlaysVisible(v: Boolean) {
        val vis = if (v) View.VISIBLE else View.GONE
        crosshair?.visibility = vis
        hud?.visibility = vis
        focusBanner?.visibility = vis
        liveRoots.values.forEach { it.visibility = vis }
        floatHandle?.visibility = vis
    }

    private fun applyCrosshair() {
        if (!handleAdded) return
        val g = gs()
        if (!g.chEnabled) {
            removeCrosshair()
            return
        }
        val v = crosshair ?: CrosshairView(this).also { nv ->
            nv.onCheck = { finishEditCrosshair() }
            nv.onDrag = { dx, dy -> moveCrosshair(dx, dy) }
            nv.onDragEnd = { saveCrosshairPos() }
            crosshair = nv
        }
        v.style = g.chStyle
        v.color = g.chColor
        v.shapeAlpha = (g.chOpacity * 255 / 100).coerceIn(30, 255)
        val shape = dp(14 + g.chSize * 90 / 100)
        v.shapeSizePx = shape
        v.padPx = dp(28)
        val size = shape + 2 * v.padPx
        val (sw, sh) = screenSize()
        val p = crosshairParams ?: WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }.also { crosshairParams = it }
        p.width = size
        p.height = size
        p.x = (g.chPosX * sw - size / 2f).toInt()
        p.y = (g.chPosY * sh - size / 2f).toInt()
        if (!crosshairAdded) {
            try {
                wm.addView(v, p)
                crosshairAdded = true
                ensurePanelOnTop()
            } catch (_: Exception) {
            }
        } else {
            try {
                wm.updateViewLayout(v, p)
            } catch (_: Exception) {
            }
        }
        v.requestLayout()
        v.invalidate()
    }

    private fun removeCrosshair() {
        crosshair?.let { removeSafely(it) }
        crosshairAdded = false
    }

    private fun startEditCrosshair() {
        val g = gs()
        if (!g.chEnabled) g.chEnabled = true
        if (expanded) toggle()
        applyCrosshair()
        crosshair?.editing = true
        setTouchable(crosshairParams, crosshair, true)
        toast("Seret crosshair ke posisi yang diinginkan, lalu ketuk centang")
    }

    private fun finishEditCrosshair() {
        crosshair?.editing = false
        setTouchable(crosshairParams, crosshair, false)
        saveCrosshairPos()
        toast("Posisi crosshair disimpan")
    }

    private fun moveCrosshair(dx: Float, dy: Float) {
        val p = crosshairParams ?: return
        val v = crosshair ?: return
        val (sw, sh) = screenSize()
        p.x = (p.x + dx.roundToInt()).coerceIn(-p.width / 2, sw - p.width / 2)
        p.y = (p.y + dy.roundToInt()).coerceIn(-p.height / 2, sh - p.height / 2)
        try {
            wm.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    private fun saveCrosshairPos() {
        val p = crosshairParams ?: return
        val (sw, sh) = screenSize()
        val g = gs()
        g.chPosX = ((p.x + p.width / 2f) / sw).coerceIn(0f, 1f)
        g.chPosY = ((p.y + p.height / 2f) / sh).coerceIn(0f, 1f)
    }

    private fun hudText(id: String): String = when (id) {
        "FPS" -> lastFps?.let { "$it FPS" } ?: "N/A"
        "CPU" -> lastCpu?.let { "$it%" } ?: "N/A"
        "CPUF" -> lastCpuGhz?.let { String.format(Locale.US, "%.1f GHz", it) } ?: "N/A"
        "GPU" -> lastGpu?.let { "$it%" } ?: "N/A"
        "TEMP" -> lastTemp?.batteryC?.let { String.format(Locale.US, "%.1f°C", it) } ?: "N/A"
        "BATT" -> lastBatt?.levelPercent?.let { "$it%" } ?: "N/A"
        "RAM" -> lastMemPct?.let { "$it%" } ?: "N/A"
        "PING" -> lastPing?.let { "$it ms" } ?: "N/A"
        else -> ""
    }

    private fun updateHud() {
        if (hud == null) return
        hudValues.forEach { (id, tv) ->
            val t = hudText(id)
            if (tv.text.toString() != t) tv.text = t
        }
    }

    private fun applyMonitor() {
        if (!handleAdded) return
        if (!hudActive() && !hudEditing) {
            removeHud()
            return
        }
        rebuildHud()
    }

    private fun removeHud() {
        removeSafely(hud)
        hud = null
        hudValues.clear()
    }

    private fun rebuildHud() {
        val g = gs()
        val color = g.monColor
        val ts = when (g.monSize) {
            0 -> 11f
            2 -> 15f
            else -> 13f
        }
        val isz = when (g.monSize) {
            0 -> 14
            2 -> 20
            else -> 17
        }
        removeHud()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(12), dp(6))
            background = rounded(Color.argb(150, 0, 0, 0), 14)
        }
        if (hudEditing) {
            val mv = FrameLayout(this).apply {
                background = rounded(withAlpha(accent, 0.85f), 8)
                addView(IconView(this@FloatingPanelService, Glyph.MOVE).apply { tint = Color.WHITE },
                    FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
            }
            box.addView(mv, lp(dp(30), dp(30)).apply { rightMargin = dp(8) })
        }
        g.monItems.forEach { id ->
            val meta = hudMeta[id] ?: return@forEach
            val icon = IconView(this, meta.first).apply { tint = color }
            val tv = text("--", ts, color, true)
            box.addView(icon, lp(dp(isz), dp(isz)).apply { rightMargin = dp(4) })
            box.addView(tv, lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
            hudValues[id] = tv
        }
        if (hudEditing) {
            val ok = FrameLayout(this).apply {
                background = circle(withAlpha(accent, 0.9f))
                addView(IconView(this@FloatingPanelService, Glyph.CHECK).apply { tint = Color.WHITE },
                    FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
                setOnClickListener { finishEditMonitor() }
            }
            box.addView(ok, lp(dp(28), dp(28)))
            box.setOnTouchListener(hudDragListener)
        }
        val (sw, sh) = screenSize()
        val p = hudParams ?: WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }.also { hudParams = it }
        p.flags = if (hudEditing) {
            p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        p.x = (g.monPosX * sw).toInt()
        p.y = (g.monPosY * sh).toInt()
        try {
            wm.addView(box, p)
            hud = box
            ensurePanelOnTop()
        } catch (_: Exception) {
            hud = null
            return
        }
        updateHud()
        box.post { clampHud() }
    }

    private fun clampHud() {
        val b = hud ?: return
        val p = hudParams ?: return
        val (sw, sh) = screenSize()
        p.x = p.x.coerceIn(0, max(0, sw - b.width))
        p.y = p.y.coerceIn(0, max(0, sh - b.height))
        try {
            wm.updateViewLayout(b, p)
        } catch (_: Exception) {
        }
    }

    private fun saveHudPos() {
        val p = hudParams ?: return
        val (sw, sh) = screenSize()
        val g = gs()
        g.monPosX = (p.x.toFloat() / sw).coerceIn(0f, 1f)
        g.monPosY = (p.y.toFloat() / sh).coerceIn(0f, 1f)
    }

    private val hudDragListener = object : View.OnTouchListener {
        private var lastX = 0f
        private var lastY = 0f
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val p = hudParams ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX
                    lastY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x += (e.rawX - lastX).roundToInt()
                    p.y += (e.rawY - lastY).roundToInt()
                    lastX = e.rawX
                    lastY = e.rawY
                    clampHud()
                }
                MotionEvent.ACTION_UP -> saveHudPos()
            }
            return true
        }
    }

    private fun startEditMonitor() {
        val g = gs()
        if (!g.monEnabled) g.monEnabled = true
        if (g.monItems.isEmpty()) g.monItems = listOf("FPS", "CPU", "BATT", "TEMP")
        hudEditing = true
        if (expanded) toggle()
        applyMonitor()
        toast("Seret monitor ke posisi yang diinginkan, lalu ketuk centang")
    }

    private fun finishEditMonitor() {
        saveHudPos()
        hudEditing = false
        applyMonitor()
        toast("Posisi monitor disimpan")
    }

    // ------------------------------------------------------------ aksi

    private fun openApp() {
        if (expanded) toggle()
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    /** Shizuku mati: buka aplikasi Shizuku agar bisa dimulai ulang dengan sekali ketuk. */
    private fun openShizukuOrApp() {
        if (expanded) toggle()
        val i = if (ShizukuHelper.isInstalled(this) && !ShizukuHelper.isRunning()) {
            packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE)
        } else {
            null
        }
        if (i != null) {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            openApp()
        }
    }

    private fun setVolume(percent: Int) {
        try {
            val am = audio()
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent * mx / 100.0).roundToInt(), 0)
            sliderVol.setGlyph(if (percent == 0) Glyph.SPEAKER_OFF else Glyph.SPEAKER)
        } catch (e: SecurityException) {
            toast("Tidak dapat mengubah volume.")
        }
    }

    private fun toggleMute() {
        try {
            audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
        } catch (_: SecurityException) {
        }
        handler.postDelayed({ syncSliders() }, 150L)
    }

    private fun applyBrightness(percent: Int) {
        val gs = GameSettings(this)
        if (gs.canWriteSystemSettings()) {
            gs.setBrightnessPercent(percent)
        } else if (ShizukuHelper.hasPermission()) {
            executor.execute { ShellTools.setBrightness(percent * 255 / 100) }
        } else if (!warnedBrightness) {
            warnedBrightness = true
            toast("Kecerahan butuh izin \"Ubah pengaturan sistem\" atau Shizuku (atur di AISZ > Atur).")
        }
    }

    /** Chip mode: Hemat daya -> Seimbang -> Performa -> Hemat daya. */
    private fun cycleMode() {
        val all = GamingProfile.values()
        val cur = GameSettings(this).profile
        selectMode(all[(cur.ordinal + 1) % all.size])
    }

    /** Hentikan = kembali ke Seimbang; saat sudah Seimbang, tombol mengaktifkan Performa. */
    private fun stopOrBoost() {
        val cur = GameSettings(this).profile
        selectMode(if (cur == GamingProfile.SEIMBANG) GamingProfile.PERFORMA else GamingProfile.SEIMBANG)
    }

    /** Mode benar-benar diterapkan ke HP; cincin di judul menunjukkan kemajuannya. */
    private fun selectMode(p: GamingProfile) {
        fpsBefore = currentAvgFps()
        GameSettings(this).profile = p
        syncModeButtons()
        ring.start()
        ModeController.applyAsync(this, p, gamePkg, { f -> ring.setProgress(f) }) { msg ->
            ring.finish("OK", true)
            toast(msg)
        }
    }

    private fun cleanMemory() {
        ring.start()
        toast("Membersihkan memori...")
        executor.execute {
            val pm = PerformanceMonitor(this)
            val freed = ModeController.cleanBackground(this, setOf(gamePkg, lastFloating, homePkg)) { f ->
                handler.post { ring.setProgress(f) }
            }
            val after = pm.memory().availMb
            handler.post {
                ring.finish(if (freed > 0) "+${freed}M" else "OK", true)
                toast(if (freed > 0) "Memori bebas +$freed MB (sekarang $after MB)" else "Memori sudah bersih ($after MB bebas)")
            }
        }
    }

    private fun freeSpace() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Bebaskan ruang butuh Shizuku. Membuka pengaturan penyimpanan.")
            try {
                startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
            return
        }
        ring.start()
        toast("Mengosongkan cache aplikasi...")
        slowExecutor.execute {
            val before = StatFs(Environment.getDataDirectory().path).availableBytes
            val r = ShizukuHelper.exec("pm trim-caches 8G")
            val after = StatFs(Environment.getDataDirectory().path).availableBytes
            val freed = max((after - before) / (1024L * 1024L), 0L)
            handler.post {
                if (r.ok || freed > 0) {
                    ring.finish("+${freed}M", true)
                    toast("Ruang bebas +$freed MB")
                } else {
                    ring.finish("!", false)
                    toast("Gagal: ${r.error.ifBlank { r.output }.take(60)}")
                }
            }
        }
    }

    private fun takeScreenshot() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Screenshot butuh Shizuku. Pakai tombol bawaan HP.")
            return
        }
        if (expanded) toggle()
        val name = "AISZ_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        handler.postDelayed({
            slowExecutor.execute {
                val dir = "/sdcard/Pictures/AISZ"
                val r = ShizukuHelper.exec("mkdir -p $dir && screencap -p $dir/$name")
                if (r.ok) {
                    ShizukuHelper.exec("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$dir/$name")
                }
                handler.post {
                    toast(if (r.ok) "Screenshot tersimpan di Pictures/AISZ" else "Gagal screenshot: ${r.error.ifBlank { r.output }.take(60)}")
                }
            }
        }, 500L)
    }

    private fun toggleRecord() {
        if (ScreenRecorderService.isRecording) {
            startService(Intent(this, ScreenRecorderService::class.java).setAction(ScreenRecorderService.ACTION_STOP))
        } else {
            if (expanded) toggle() // sembunyikan panel agar tidak ikut terekam
            startActivity(Intent(this, RecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun toggleFrameLock() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Frame tinggi butuh Shizuku (atur di AISZ > Atur).")
            return
        }
        val gs = GameSettings(this)
        val target = !gs.frameLock
        executor.execute {
            val r = if (target) ShellTools.lockRefreshRate(ShellTools.maxRefreshRate(this)) else ShellTools.unlockRefreshRate()
            handler.post {
                if (r.ok) {
                    gs.frameLock = target
                    syncTiles()
                    toast(if (target) "Refresh rate dikunci ke maksimum" else "Refresh rate dikembalikan")
                } else {
                    toast("Gagal: ${r.error.ifBlank { r.output }}")
                }
            }
        }
    }

    private fun toggleDnd() {
        if (!nm().isNotificationPolicyAccessGranted) {
            toast("Beri izin akses Jangan Ganggu dulu.")
            try {
                startActivity(
                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
            return
        }
        nm().setInterruptionFilter(
            if (dndOn()) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        syncTiles()
    }

    /** Timer bermain: Mati -> 30 -> 60 -> 90 menit -> Mati. Berbunyi (getar + notifikasi) saat habis. */
    private fun toggleTimer() {
        val options = listOf(0, 30, 60, 90)
        val next = options[(options.indexOf(timerMinutes) + 1) % options.size]
        handler.removeCallbacks(timerDone)
        timerMinutes = next
        if (next == 0) {
            timerEndAt = 0L
            toast("Timer dimatikan")
        } else {
            timerEndAt = SystemClock.elapsedRealtime() + next * 60_000L
            handler.postDelayed(timerDone, next * 60_000L)
            toast("Timer $next menit dimulai")
        }
        syncTiles()
    }

    private fun onTimerDone() {
        timerMinutes = 0
        timerEndAt = 0L
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(700)
            }
        } catch (_: Exception) {
        }
        val n = NotificationCompat.Builder(this, TIMER_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle("Waktu bermain habis")
            .setContentText("Timer AISZ GAME SPACE selesai.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            nm().notify(2001, n)
        } catch (_: Exception) {
        }
        toast("Waktu bermain habis")
        if (handleAdded) syncTiles()
    }

    private fun openFloating(pkg: String) {
        if (expanded) toggle()
        gameBeforeFloat = gamePkg
        executor.execute {
            if (ShizukuHelper.hasPermission()) {
                val r = ShellTools.launchFreeform(this, pkg)
                if (r.ok) {
                    lastFloating = pkg
                    slowExecutor.execute { resizeFloating(pkg, silent = true) }
                    return@execute
                }
                if (r.error.startsWith("FULLSCREEN:")) {
                    handler.post { toast(r.error.removePrefix("FULLSCREEN:")) }
                    return@execute
                }
                handler.post { toast("Jendela mengambang gagal dibuka. Dibuka biasa.") }
            } else {
                handler.post { toast("Jendela mengambang butuh Shizuku, dibuka biasa.") }
            }
            handler.post { GameLauncher(this).launch(pkg, applyProfile = false, skipSplash = true) }
        }
    }

    /** Ukuran jendela dari pengaturan: tinggi 35-95% layar, rasio potret/persegi/lanskap, di tengah. */
    private fun floatBounds(): ShellTools.Bounds {
        val (sw, sh) = screenSize()
        val g = gs()
        val frac = 0.30f + 0.70f * g.floatScale / 100f
        var h = (sh * frac).toInt()
        val ratio = when (g.floatRatio) {
            1 -> 1f
            2 -> 1.7778f
            3 -> 0.75f
            else -> 0.5625f
        }
        var w = (h * ratio).toInt()
        if (w > sw * 0.96f) {
            w = (sw * 0.96f).toInt()
            h = min(h, (w / ratio).toInt())
        }
        val l = (sw - w) / 2
        val t = (sh - h) / 2
        return ShellTools.Bounds(l, t, l + w, t + h)
    }

    /** Mengubah ukuran jendela aplikasi (dicoba beberapa kali sampai jendelanya muncul). Jalankan di thread latar. */
    private fun resizeFloating(pkg: String, silent: Boolean) {
        if (!ShizukuHelper.hasPermission()) {
            if (!silent) toast("Ubah ukuran jendela butuh Shizuku aktif.")
            return
        }
        val b = floatBounds()
        var lastErr = "jendela tidak ditemukan"
        for (attempt in 1..6) {
            try {
                Thread.sleep(400)
            } catch (_: InterruptedException) {
                return
            }
            val id = ShellTools.findTaskId(pkg)
            if (id != null) {
                val r = ShellTools.resizeTask(id, b)
                if (r.ok) {
                    try {
                        Thread.sleep(450)
                    } catch (_: InterruptedException) {
                    }
                    settleFloatSize(pkg, id, b)
                    floatTaskId = id
                    handler.post { showFloatHandle() }
                    if (!silent) toast("Ukuran jendela diterapkan")
                    return
                }
                lastErr = r.error.ifBlank { r.output }.take(60).ifBlank { "perintah ditolak" }
            }
        }
        toast("Ukuran jendela tidak bisa diubah ($lastErr). Sebagian ROM tidak mendukung.")
    }

    /**
     * HyperOS menskalakan jendela kecil, sehingga ukuran terlihat bisa jauh lebih kecil dari yang diminta.
     * Coba besarkan ukuran yang diminta agar ukuran terlihat sesuai pengaturan; bila sistem tetap menahannya, kembalikan.
     */
    private fun settleFloatSize(pkg: String, id: Int, b: ShellTools.Bounds) {
        var applied = ShellTools.taskBounds(id) ?: ShellTools.windowFrame(pkg) ?: b
        var vis = ShellTools.visibleFrame(pkg)
        val (sw, sh) = screenSize()
        if (vis != null) {
            val want = b.b - b.t
            val seen = vis.b - vis.t
            if (seen > 0 && seen < want * 0.85f) {
                val k = (want.toFloat() / seen).coerceAtMost(3f)
                var nw = ((applied.r - applied.l) * k).toInt()
                var nh = ((applied.b - applied.t) * k).toInt()
                if (nw > sw) {
                    nh = (nh * sw.toFloat() / nw).toInt()
                    nw = sw
                }
                if (nh > sh) {
                    nw = (nw * sh.toFloat() / nh).toInt()
                    nh = sh
                }
                val nl = b.l.coerceIn(0, max(0, sw - nw))
                val nt = b.t.coerceIn(0, max(0, sh - nh))
                val nb = ShellTools.Bounds(nl, nt, nl + nw, nt + nh)
                ShellTools.resizeTask(id, nb)
                try {
                    Thread.sleep(450)
                } catch (_: InterruptedException) {
                }
                val vis2 = ShellTools.visibleFrame(pkg)
                if (vis2 != null && (vis2.b - vis2.t) > seen * 1.12f) {
                    applied = ShellTools.taskBounds(id) ?: nb
                    vis = vis2
                } else {
                    ShellTools.resizeTask(id, applied)
                    handler.post { toast("HyperOS membatasi ukuran jendela kecil, jadi AISZ tidak bisa membesarkannya lebih dari ini.") }
                }
            }
        }
        floatB = applied
        floatCur = vis ?: applied
    }

    // ---- tombol jendela mengambang: bar putih di atas = pindah, tombol putih di pojok = ubah ukuran.
    // floatCur = persegi yang terlihat di layar; floatB = ukuran jendela yang dikirim ke sistem (ROM bisa menskalakannya).

    private fun positionFloatHandle(p: WindowManager.LayoutParams, b: ShellTools.Bounds) {
        val (sw, _) = screenSize()
        p.width = (b.r - b.l).coerceIn(dp(100), max(dp(100), sw))
        p.height = dp(22)
        p.x = b.l.coerceIn(0, max(0, sw - p.width))
        val above = b.t - p.height
        p.y = if (above >= 0) above else b.t
    }

    private fun positionFloatGrip(p: WindowManager.LayoutParams, b: ShellTools.Bounds) {
        val (sw, sh) = screenSize()
        p.x = (b.r - p.width - dp(4)).coerceIn(0, max(0, sw - p.width))
        p.y = (b.b - p.height - dp(4)).coerceIn(0, max(0, sh - p.height))
    }

    private fun floatOverlayParams(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(w, h, overlayType(), flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            useFullScreenArea()
        }
    }

    /** Menyesuaikan area gestur dan (saat menyeret) bingkai bayangan dengan posisi jendela. */
    private fun applyFloatOverlays(b: ShellTools.Bounds, ghost: Boolean) {
        val hv = floatHandle
        val hp = floatHandleParams
        if (hv != null && hp != null) {
            positionFloatHandle(hp, b)
            try {
                wm.updateViewLayout(hv, hp)
            } catch (_: Exception) {
            }
        }
        val gv = floatGrip
        val gp = floatGripParams
        if (gv != null && gp != null) {
            positionFloatGrip(gp, b)
            try {
                wm.updateViewLayout(gv, gp)
            } catch (_: Exception) {
            }
        }
        if (ghost) updateFloatGhost(b)
    }

    private fun updateFloatGhost(b: ShellTools.Bounds) {
        val v = floatGhost
        val p = floatGhostParams
        if (v == null || p == null) {
            val nv = FloatGhostView(this)
            val np = floatOverlayParams(b.r - b.l, b.b - b.t, touchable = false)
            np.x = b.l
            np.y = b.t
            try {
                wm.addView(nv, np)
                floatGhost = nv
                floatGhostParams = np
            } catch (_: Exception) {
            }
            return
        }
        p.x = b.l
        p.y = b.t
        p.width = b.r - b.l
        p.height = b.b - b.t
        try {
            wm.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    private fun hideFloatGhost() {
        floatGhost?.let { removeSafely(it) }
        floatGhost = null
        floatGhostParams = null
    }

    private fun showFloatHandle() {
        if (!handleAdded) return
        val cur = floatCur ?: return
        if (floatHandle != null) {
            applyFloatOverlays(cur, false)
            return
        }
        val v = FloatHandleView(this).apply {
            onDrag = { dx, dy -> dragFloat(dx, dy) }
            onDragEnd = { commitFloatDrag() }
            onClose = { hideFloatHandle() }
        }
        val p = floatOverlayParams(dp(100), dp(22), touchable = true)
        positionFloatHandle(p, cur)
        try {
            wm.addView(v, p)
            floatHandle = v
            floatHandleParams = p
        } catch (_: Exception) {
        }
        val gv = FloatGripView(this).apply {
            onDrag = { dx, dy -> resizeDrag(dx, dy) }
            onDragEnd = { commitFloatDrag() }
        }
        val gp = floatOverlayParams(dp(30), dp(30), touchable = true)
        positionFloatGrip(gp, cur)
        try {
            wm.addView(gv, gp)
            floatGrip = gv
            floatGripParams = gp
        } catch (_: Exception) {
        }
        ensurePanelOnTop()
        floatMiss = 0
        handler.removeCallbacks(floatPoll)
        handler.postDelayed(floatPoll, 4000L)
    }

    private fun hideFloatHandle() {
        handler.removeCallbacks(floatPoll)
        floatHandle?.let { removeSafely(it) }
        floatHandle = null
        floatHandleParams = null
        floatGrip?.let { removeSafely(it) }
        floatGrip = null
        floatGripParams = null
        hideFloatGhost()
    }

    private fun toggleFloatHandle() {
        if (floatHandle != null) {
            hideFloatHandle()
            toast("Tombol jendela disembunyikan")
            return
        }
        if (lastFloating == null) {
            toast("Buka dulu sebuah aplikasi dari dock.")
            return
        }
        if (floatCur == null) {
            // Belum ada ukuran yang diterapkan: terapkan dulu agar posisi jendela diketahui.
            slowExecutor.execute { resizeFloating(lastFloating ?: return@execute, silent = true) }
        } else {
            showFloatHandle()
            toast("Seret bar putih di atas jendela untuk memindah, tombol putih di pojok untuk ukuran")
        }
    }

    /** Menggeser: hanya bingkai bayangan yang bergerak mengikuti jari; jendela asli dipindah sekali saat jari dilepas. */
    private fun dragFloat(dx: Float, dy: Float) {
        val cur = floatCur ?: return
        dragSeq++
        dragRemX += dx
        dragRemY += dy
        val ix = dragRemX.toInt()
        val iy = dragRemY.toInt()
        dragRemX -= ix
        dragRemY -= iy
        val (sw, sh) = screenSize()
        val w = cur.r - cur.l
        val h = cur.b - cur.t
        val nl = (cur.l + ix).coerceIn(0, max(0, sw - w))
        val nt = (cur.t + iy).coerceIn(0, max(0, sh - h))
        val nb = ShellTools.Bounds(nl, nt, nl + w, nt + h)
        val b = floatB ?: cur
        floatB = ShellTools.Bounds(b.l + (nl - cur.l), b.t + (nt - cur.t), b.r + (nl - cur.l), b.b + (nt - cur.t))
        floatCur = nb
        applyFloatOverlays(nb, true)
    }

    /** Mengubah ukuran dengan menyeret pojok kanan bawah. */
    private fun resizeDrag(dx: Float, dy: Float) {
        val cur = floatCur ?: return
        dragSeq++
        resRemX += dx
        resRemY += dy
        val ix = resRemX.toInt()
        val iy = resRemY.toInt()
        resRemX -= ix
        resRemY -= iy
        val (sw, sh) = screenSize()
        val oldW = cur.r - cur.l
        val oldH = cur.b - cur.t
        val nw = (oldW + ix).coerceIn(dp(120), max(dp(120), sw - cur.l))
        val nh = (oldH + iy).coerceIn(dp(120), max(dp(120), sh - cur.t))
        val b = floatB ?: cur
        val scale = (oldW.toFloat() / max(1, b.r - b.l)).coerceIn(0.2f, 3f)
        val bw = max(dp(120), ((b.r - b.l) + (nw - oldW) / scale).toInt())
        val bh = max(dp(120), ((b.b - b.t) + (nh - oldH) / scale).toInt())
        floatB = ShellTools.Bounds(b.l, b.t, b.l + bw, b.t + bh)
        val nb = ShellTools.Bounds(cur.l, cur.t, cur.l + nw, cur.t + nh)
        floatCur = nb
        applyFloatOverlays(nb, true)
    }

    private fun commitFloatDrag() {
        // Bingkai bayangan tetap tampil sampai jendela asli selesai dipindah, supaya tidak ada jeda kosong.
        scheduleFloatMove()
    }

    /** Menerapkan posisi/ukuran lewat am task resize; permintaan beruntun digabung agar tidak membanjiri Shizuku. */
    private fun scheduleFloatMove() {
        if (moveBusy) {
            movePending = true
            return
        }
        moveBusy = true
        slowExecutor.execute {
            try {
                do {
                    movePending = false
                    val b = floatB
                    val pkg = lastFloating
                    if (b != null && pkg != null && ShizukuHelper.hasPermission()) {
                        val id = floatTaskId ?: ShellTools.findTaskId(pkg)
                        floatTaskId = id
                        if (id != null) {
                            val seq = dragSeq
                            val r = ShellTools.resizeTask(id, b)
                            if (!r.ok) {
                                floatTaskId = null
                            } else if (!movePending) {
                                try {
                                    Thread.sleep(450)
                                } catch (_: InterruptedException) {
                                }
                                val vis = ShellTools.visibleFrame(pkg)
                                val nb = ShellTools.taskBounds(id)
                                if (seq == dragSeq && !movePending) {
                                    if (nb != null) floatB = nb
                                    if (vis != null) floatCur = vis
                                    handler.post { floatCur?.let { applyFloatOverlays(it, false) } }
                                }
                            }
                        }
                    }
                } while (movePending)
            } finally {
                moveBusy = false
                if (!movePending) handler.post { hideFloatGhost() }
            }
        }
    }

    private fun enableFloatOptions() {
        if (!ShizukuHelper.hasPermission()) {
            toast("Aktifkan Shizuku dulu (tab Atur).")
            return
        }
        slowExecutor.execute {
            val changed = ShellTools.ensureFreeformSettings()
            handler.post { toast(if (changed) "Opsi dinyalakan. Mulai ulang HP agar berlaku." else "Opsi sudah menyala.") }
        }
    }

    /** Memeriksa apakah HP ini mendukung jendela mengambang dan menjelaskan kenapa tidak. */
    private fun checkFloatSupport() {
        if (!ShizukuHelper.hasPermission()) {
            tvFloatReport.text = "Aktifkan Shizuku dulu (tab Atur) untuk memeriksa."
            return
        }
        tvFloatReport.text = "Memeriksa..."
        slowExecutor.execute {
            val low = (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).isLowRamDevice
            val feat = ShizukuHelper.exec("pm has-feature android.software.freeform_window_management").output.trim()
            val opt = ShizukuHelper.exec("settings get global enable_freeform_support").output.trim() == "1"
            val force = ShizukuHelper.exec("settings get global force_resizable_activities").output.trim() == "1"
            val verdict = when {
                low -> "Tidak didukung: HP RAM rendah (Android Go) menonaktifkan multi-jendela dari sistem. " +
                    "Aplikasi lain seperti Taskbar juga tidak bisa memaksanya di HP ini."
                !opt || !force -> "Opsi belum menyala. Tekan AKTIFKAN OPSI, lalu mulai ulang HP sekali."
                feat.contains("false") -> "Fitur freeform tidak terdaftar di ROM. Coba mulai ulang HP; bila tetap penuh layar, ROM tidak mendukung."
                else -> "Seharusnya didukung. Buka aplikasi dari dock untuk mencoba."
            }
            val txt = "HP: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}\n" +
                "RAM rendah (Go): ${if (low) "ya" else "tidak"}\n" +
                "Fitur freeform sistem: ${if (feat.contains("true")) "ada" else "tidak ada"}\n" +
                "Opsi freeform: ${if (opt) "menyala" else "mati"}, paksa ubah ukuran: ${if (force) "menyala" else "mati"}\n" +
                "Kesimpulan: $verdict"
            handler.post { tvFloatReport.text = txt }
        }
    }

    /** Menampilkan angka posisi jendela dari beberapa sumber, untuk memeriksa sinkronisasi. */
    private fun diagnoseFloat() {
        val pkg = lastFloating
        if (pkg == null) {
            toast("Buka dulu sebuah aplikasi dari dock.")
            return
        }
        slowExecutor.execute {
            val id = floatTaskId ?: ShellTools.findTaskId(pkg)
            val t = id?.let { ShellTools.taskBounds(it) }
            val w = ShellTools.windowFrame(pkg)
            val v = ShellTools.visibleFrame(pkg)
            fun f(x: ShellTools.Bounds?): String = if (x == null) "-" else "[${x.l},${x.t}][${x.r},${x.b}]"
            handler.post { toast("Terlihat ${f(v)}\nTask ${f(t)}\nWindow ${f(w)}\nDiminta ${f(floatB)}") }
        }
    }

    private fun resizeFloatingNow() {
        val pkg = lastFloating
        if (pkg == null) {
            toast("Buka dulu sebuah aplikasi dari dock.")
            return
        }
        slowExecutor.execute { resizeFloating(pkg, silent = false) }
    }

    /** Pemulihan: tutup aplikasi jendela mengambang terakhir dan kembalikan game ke layar penuh. */
    private fun recoverScreen() {
        val floating = lastFloating
        val game = gameBeforeFloat ?: gamePkg
        if (expanded) toggle()
        executor.execute {
            if (ShizukuHelper.hasPermission()) {
                if (floating != null) ShellTools.forceStop(floating)
                if (game != null) ShellTools.bringFullscreen(this, game)
                lastFloating = null
                floatCur = null
                floatTaskId = null
                handler.post {
                    hideFloatHandle()
                    toast("Layar dipulihkan")
                }
            } else {
                handler.post { toast("Pulihkan layar butuh Shizuku aktif.") }
            }
        }
    }

    companion object {
        const val ACTION_STOP = "com.aisz.gamespace.action.STOP_PANEL"
        private const val CHANNEL_ID = "aisz_panel"
        private const val TIMER_CHANNEL = "aisz_timer"
        private const val NOTIF_ID = 1001
        private const val HANDLE_W_DP = 22
        private const val PANEL_GAP_DP = 36

        private val TITLE = Color.parseColor("#43A8F0")
        private val TEXT = Color.parseColor("#EDEFF2")
        private val DIM = Color.parseColor("#8C94A3")
        private val ICON = Color.parseColor("#C9CED8")
        private val TILE_BG = Color.parseColor("#0F141C")
        private val TILE_ON = Color.parseColor("#232610")
        private val TILE_STROKE = Color.parseColor("#4A5260")
        private val PANEL_BG = Color.parseColor("#F40C1118")
        private val PANEL_STROKE = Color.parseColor("#3A4252")
        private val DOCK_BG = Color.parseColor("#F40E131A")
        private val HUD_BG = Color.parseColor("#F00C1118")
        private val WHITE = Color.parseColor("#F2FFFFFF")
        private val OK = Color.parseColor("#2BE38B")
        private val WARN = Color.parseColor("#FFB020")
        private val HOT = Color.parseColor("#FF4D5E")

        @Volatile
        private var instance: FloatingPanelService? = null

        /** Menampilkan pesan lewat panel (terlihat di dalam game). False bila panel tidak aktif. */
        fun announce(msg: String): Boolean {
            val i = instance ?: return false
            i.showHud(msg)
            return true
        }

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingPanelService::class.java))
        }

        fun stop(ctx: Context) {
            GameSettings(ctx).panelWanted = false
            ctx.stopService(Intent(ctx, FloatingPanelService::class.java))
        }
    }
}
