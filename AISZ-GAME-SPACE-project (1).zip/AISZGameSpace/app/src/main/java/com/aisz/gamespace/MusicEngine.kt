package com.aisz.gamespace

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast

/** Pemutar musik offline: daftar lagu disimpan di pengaturan, pemutaran lewat MediaPlayer. */
object MusicEngine {
    class Song(val uri: String, val title: String)

    private val main = Handler(Looper.getMainLooper())
    private var appCtx: Context? = null
    private var mp: MediaPlayer? = null
    private var prepared = false
    private var loaded = false

    var songs: List<Song> = emptyList()
        private set
    var index = -1
        private set
    var speed = 1.0f
        private set
    var onLibraryChanged: (() -> Unit)? = null

    val isActive: Boolean get() = mp != null

    val isPlaying: Boolean
        get() = try {
            mp?.isPlaying == true
        } catch (_: IllegalStateException) {
            false
        }

    val title: String? get() = songs.getOrNull(index)?.title

    val positionMs: Int
        get() = try {
            if (prepared) mp?.currentPosition ?: 0 else 0
        } catch (_: IllegalStateException) {
            0
        }

    val durationMs: Int
        get() = try {
            if (prepared) mp?.duration ?: 0 else 0
        } catch (_: IllegalStateException) {
            0
        }

    fun ensureLoaded(ctx: Context) {
        if (!loaded) load(ctx)
    }

    fun load(ctx: Context) {
        appCtx = ctx.applicationContext
        val g = GameSettings(ctx)
        songs = g.musicLib.lines().mapNotNull { line ->
            val t = line.split('\t', limit = 2)
            if (t.size == 2 && t[0].isNotBlank()) Song(t[0], t[1]) else null
        }
        speed = g.musicSpeed
        loaded = true
    }

    private fun save(ctx: Context) {
        GameSettings(ctx).musicLib = songs.joinToString("\n") {
            it.uri + "\t" + it.title.replace('\t', ' ').replace('\n', ' ')
        }
    }

    private fun libraryChanged() {
        main.post { onLibraryChanged?.invoke() }
    }

    /** Menambah lagu; mengembalikan jumlah yang benar-benar baru. */
    fun add(ctx: Context, list: List<Song>): Int {
        ensureLoaded(ctx)
        val known = songs.map { it.uri }.toSet()
        val fresh = list.filter { it.uri !in known }
        if (fresh.isEmpty()) return 0
        songs = songs + fresh
        save(ctx)
        libraryChanged()
        return fresh.size
    }

    fun remove(ctx: Context, i: Int) {
        ensureLoaded(ctx)
        if (i !in songs.indices) return
        val removed = songs[i]
        if (i == index) {
            releasePlayer()
            index = -1
        } else if (i < index) {
            index -= 1
        }
        songs = songs.filterIndexed { n, _ -> n != i }
        try {
            ctx.contentResolver.releasePersistableUriPermission(
                Uri.parse(removed.uri), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        save(ctx)
        libraryChanged()
        changed()
    }

    private fun changed() {
        appCtx?.let { MusicService.sync(it) }
    }

    private fun toast(msg: String) {
        val c = appCtx ?: return
        main.post { Toast.makeText(c, msg, Toast.LENGTH_LONG).show() }
    }

    private fun releasePlayer() {
        mp?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            try {
                it.release()
            } catch (_: Exception) {
            }
        }
        mp = null
        prepared = false
    }

    fun play(ctx: Context, i: Int) {
        ensureLoaded(ctx)
        appCtx = ctx.applicationContext
        if (i !in songs.indices) return
        releasePlayer()
        index = i
        val s = songs[i]
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setWakeMode(appCtx, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(appCtx!!, Uri.parse(s.uri))
            p.setOnPreparedListener { pl ->
                if (mp === pl) {
                    prepared = true
                    pl.start()
                    applySpeed()
                    appCtx?.let { GameSettings(it).musicIndex = index }
                    changed()
                }
            }
            p.setOnCompletionListener { pl ->
                if (mp === pl) appCtx?.let { next(it) }
            }
            p.setOnErrorListener { pl, _, _ ->
                if (mp === pl) {
                    main.post {
                        releasePlayer()
                        index = -1
                        toast("Lagu tidak bisa diputar. Hapus lalu tambahkan lagi.")
                        changed()
                    }
                }
                true
            }
            p.prepareAsync()
            changed()
        } catch (e: Exception) {
            releasePlayer()
            index = -1
            toast("Gagal membuka lagu: ${e.message}")
            changed()
        }
    }

    fun toggle(ctx: Context) {
        ensureLoaded(ctx)
        appCtx = ctx.applicationContext
        val p = mp
        if (p == null) {
            if (songs.isEmpty()) {
                toast("Tambahkan lagu dulu.")
                return
            }
            val last = GameSettings(ctx).musicIndex
            play(ctx, if (last in songs.indices) last else 0)
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
            } else {
                p.start()
                applySpeed()
            }
        } catch (_: IllegalStateException) {
        }
        changed()
    }

    fun next(ctx: Context) {
        ensureLoaded(ctx)
        if (songs.isEmpty()) return
        play(ctx, (index + 1).mod(songs.size))
    }

    fun prev(ctx: Context) {
        ensureLoaded(ctx)
        if (songs.isEmpty()) return
        if (positionMs > 3000) {
            seekTo(0)
            return
        }
        play(ctx, if (index <= 0) songs.size - 1 else index - 1)
    }

    fun stop(ctx: Context) {
        appCtx = ctx.applicationContext
        releasePlayer()
        index = -1
        changed()
    }

    fun seekTo(ms: Int) {
        try {
            if (prepared) mp?.seekTo(ms)
        } catch (_: IllegalStateException) {
        }
    }

    fun seekToFraction(f: Float) {
        val d = durationMs
        if (d > 0) seekTo((d * f.coerceIn(0f, 1f)).toInt())
    }

    fun setSpeed(ctx: Context, s: Float) {
        appCtx = ctx.applicationContext
        speed = s.coerceIn(0.5f, 2.0f)
        GameSettings(ctx).musicSpeed = speed
        applySpeed()
        changed()
    }

    private fun applySpeed() {
        val p = mp ?: return
        if (!prepared) return
        try {
            val was = p.isPlaying
            p.playbackParams = PlaybackParams().setSpeed(speed).setPitch(1.0f)
            if (!was) p.pause() // di sebagian HP mengubah kecepatan otomatis memutar
        } catch (_: Exception) {
        }
    }
}
