package com.aisz.gamespace

import android.content.Context
import java.util.Locale

/** Asisten offline: memahami perintah sederhana dan menjawab pertanyaan seputar AISZ GAME SPACE tanpa internet. */
object AssistantEngine {
    class Action(val name: String, val arg: String)
    class Reply(val text: String, val actions: List<Action> = emptyList())
    class Faq(val topic: String, val keys: List<String>, val answer: String)

    /** Satu-satunya aksi yang boleh dijalankan, baik dari mesin offline maupun dari Claude. */
    val allowedActions: Map<String, Set<String>> = mapOf(
        "set_mode" to setOf("hemat", "seimbang", "performa"),
        "ping" to setOf("on", "off"),
        "fokus" to setOf("on", "off"),
        "overlay" to setOf("on", "off"),
        "musik" to setOf("play", "pause", "next", "prev", "stop"),
        "bersihkan_ram" to setOf(""),
        "matikan_tekstur" to setOf(""),
        "status" to setOf("")
    )

    fun isAllowed(a: Action): Boolean = allowedActions[a.name]?.contains(a.arg) == true

    val faq: List<Faq> = listOf(
        Faq("Mode Hemat daya, Seimbang, Performa", listOf("mode", "hemat", "seimbang", "performa", "profil"),
            "Ada tiga mode. Hemat daya menyalakan Penghemat Baterai HP. Seimbang adalah kondisi normal. Performa menutup aplikasi latar (AISZ dan game tidak ikut), menyalakan mode kinerja HP dan Game Mode performa. Efeknya bergantung ROM, dan butuh Shizuku."),
        Faq("Shizuku", listOf("shizuku", "adb", "izin", "debugging"),
            "Shizuku memberi AISZ akses setara ADB tanpa PC, dibutuhkan untuk mode, FPS, tekstur, resolusi, fokus, dan ping rendah. Nyalakan lewat Opsi pengembang > Debugging nirkabel > buka Shizuku > Mulai. Shizuku berhenti saat Wi-Fi putus atau HP restart, jadi perlu dinyalakan lagi."),
        Faq("Tekstur Ringan", listOf("tekstur", "kotak", "angle", "jarak tegas", "anisotropik"),
            "Tekstur Ringan membuat tekstur Free Fire dan Free Fire MAX kotak-kotak lewat lapisan ANGLE supaya GPU lebih ringan. Atur tingkat 1 sampai 4 dan Jarak tegas di layar yang muncul sebelum game dibuka lewat AISZ. Efek terlihat setelah game dibuka ulang, dan otomatis dimatikan saat lu meninggalkan game. Butuh Shizuku dan HP yang punya ANGLE."),
        Faq("Turunkan Resolusi", listOf("resolusi", "downscale", "pecah", "turunkan"),
            "Turunkan Resolusi memakai Game Mode Android 13+ untuk merender game di 85%, 70%, 60%, atau 50% supaya GPU lebih ringan. Gambar jadi lebih pecah. Aturannya ada di tab kedua pada layar sebelum game dibuka, dan otomatis dimatikan saat keluar game."),
        Faq("Fokus game", listOf("fokus", "notifikasi", "ganggu", "dnd"),
            "Fokus game menyalakan Jangan Ganggu prioritas, mematikan notifikasi pop-up, dan mematikan kecerahan otomatis. Semuanya dikembalikan saat Fokus dimatikan. Ada di Semua fitur."),
        Faq("Ping rendah", listOf("ping", "lag", "wifi", "latensi", "jaringan"),
            "Ping rendah mengunci Wi-Fi ke mode latensi rendah supaya sinyal tidak masuk mode hemat daya. Hanya berpengaruh di Wi-Fi, dan terasa kalau lag datang dari Wi-Fi HP. Ada tombol UJI PING untuk membandingkan sebelum dan sesudah."),
        Faq("Rekam layar", listOf("rekam", "record", "video", "suara perangkat", "mikrofon"),
            "Rekam layar menyimpan video ke Movies/AISZ. Di Semua fitur > Rekam layar lu bisa memilih suara perangkat (suara game) dan mikrofon. Sebagian game melarang suaranya direkam sehingga hasilnya senyap. Rekaman dengan suara perangkat diproses beberapa detik setelah dihentikan."),
        Faq("Overlay live", listOf("overlay", "live", "streaming", "sociabuzz", "foto", "link"),
            "Overlay live menampilkan sampai 6 foto atau halaman link (misalnya Sociabuzz) di atas game. Tiap slot punya sakelar, transparansi, tembus sentuhan, posisi, dan ukuran sendiri. Hanya tampilan: tanpa login dan tidak terhubung ke akun. Link hanya https dan dimuat tanpa cookie."),
        Faq("Pemutar musik", listOf("musik", "lagu", "pemutar", "putar", "kecepatan"),
            "Pemutar musik memutar lagu dari penyimpanan HP tanpa internet. Tambah dan hapus lagu di daftar, atur kecepatan 0,5x sampai 2x, dan kendalikan dari notifikasi. Musik tetap jalan walau panel ditutup."),
        Faq("Jendela mengambang", listOf("jendela", "mengambang", "freeform", "dock", "floating"),
            "Aplikasi di dock panel bisa dibuka sebagai jendela mengambang. Di HyperOS ukuran terlihat dibatasi sistem. HP RAM rendah (Android Go) tidak mendukungnya. Tombol CEK DUKUNGAN di Semua fitur > Jendela mengambang menjelaskan kenapa tidak jalan."),
        Faq("Crosshair dan HUD monitor", listOf("crosshair", "bidik", "hud", "monitor"),
            "Crosshair punya 5 gaya dengan warna, ukuran, opasitas, dan posisi yang bisa diatur. HUD monitor menampilkan sampai 4 info (FPS, CPU, GPU, suhu, baterai, RAM, ping) dalam overlay kecil. Keduanya ada di Semua fitur."),
        Faq("FPS", listOf("fps", "frame", "n/a"),
            "FPS game dibaca saat game terbuka dan butuh Shizuku. Kalau tampil N/A, biasanya Shizuku belum jalan atau game memakai lapisan yang tidak terbaca di HP itu. Layar Monitor menampilkan refresh rate layar, bukan FPS game."),
        Faq("Panel melayang", listOf("panel", "handle", "gagang", "buka panel", "game space"),
            "Panel Game Space dibuka dari gagang putih tipis di tepi layar. Isinya mode, dock aplikasi, kecerahan, volume, dan tombol Semua fitur. Panel dinyalakan dari Home lewat Masuk ke Game Space."),
        Faq("Profil dan Monitor", listOf("profil", "tab", "ip", "perangkat"),
            "Tab Profil menampilkan nama HP, IP perangkat (ketuk untuk menyalin), model, sistem, RAM, penyimpanan, baterai, dan status Shizuku. Tab Monitor menampilkan refresh rate, jaringan, suhu, RAM, baterai, dan perangkat dalam satu layar."),
        Faq("Fitur tidak jalan", listOf("tidak jalan", "gagal", "error", "masalah", "tidak bisa", "bug"),
            "Cek dulu: Shizuku sudah Aktif di tab Atur? Izin tampil di atas aplikasi lain sudah diberikan? Untuk fitur game, tutup game lalu buka lewat AISZ. Banyak fitur bergantung ROM, jadi tidak semua HP sama hasilnya.")
    )

    private const val HELP =
        "Saya belum paham maksudnya. Coba: \"mode performa\", \"nyalakan fokus\", \"matikan ping rendah\", \"putar musik\", " +
            "\"cek suhu\", \"bersihkan RAM\", atau tanya \"apa itu tekstur ringan?\". Untuk jawaban yang lebih bebas, nyalakan " +
            "Claude online lewat ikon pengaturan di kanan atas."

    /** Ringkasan keadaan HP dan fitur AISZ (dipakai untuk perintah status dan sebagai konteks Claude). */
    fun statusText(ctx: Context): String {
        val g = GameSettings(ctx)
        val perf = PerformanceMonitor(ctx)
        val mem = perf.memory()
        val bat = perf.battery()
        val th = TemperatureMonitor(ctx).read()
        val live = (0 until GameSettings.LIVE_SLOTS).count { g.liveOn(it) }
        val shizuku = when {
            !ShizukuHelper.isInstalled(ctx) -> "belum dipasang"
            ShizukuHelper.isRunning() && ShizukuHelper.hasPermission() -> "aktif"
            ShizukuHelper.isRunning() -> "berjalan, izin belum diberikan"
            else -> "belum berjalan"
        }
        return listOf(
            "Mode: ${g.profile.label}",
            "Suhu baterai: ${th.batteryC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "N/A"} (${th.level.label})",
            "RAM: ${mem.usedPercent}% terpakai, ${mem.availMb} MB bebas",
            "Baterai: ${bat.levelPercent?.let { "$it%" } ?: "N/A"}${if (bat.charging) " (mengisi)" else ""}",
            "Refresh layar: ${String.format(Locale.US, "%.0f Hz", perf.deviceInfo().refreshRateHz)}",
            "Ping rendah: ${if (g.pingLow) "aktif" else "mati"}; Fokus: ${if (g.focusActive) "aktif" else "mati"}",
            "Tekstur Ringan: ${if (g.texApplied) "aktif" else "mati"}; Turunkan Resolusi: ${if (g.texAltApplied) "aktif" else "mati"}",
            "Overlay live: $live slot tampil; Musik: ${if (MusicEngine.isPlaying) "memutar" else "berhenti"}",
            "Shizuku: $shizuku"
        ).joinToString("\n")
    }

    fun knowledgeText(): String = faq.joinToString("\n") { "- ${it.topic}: ${it.answer}" }

    fun interpret(input: String): Reply {
        val t = " " + input.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9?/ ]"), " ").replace(Regex("\\s+"), " ").trim() + " "
        fun s(x: String) = t.contains(x)
        fun w(x: String) = t.contains(" $x ")

        val off = w("off") || s("matikan") || s("nonaktif") || s("hentikan") || s("berhenti") || s("tutup") || s("sembunyikan") || s("lepas")
        val on = !off && (w("on") || s("nyala") || s("aktifkan") || s("hidupkan") || s("jalankan") || s("pakai") || s("mulai") || s("tampilkan"))
        val question = s("apa itu") || s("apakah") || s("kenapa") || s("mengapa") || s("bagaimana") || s("gimana") ||
            s("jelaskan") || s("fungsi") || s("cara ") || s("bedanya") || s("maksud") || s("kegunaan") || s("manfaat")

        if (!question) {
            val actions = ArrayList<Action>()
            val notes = ArrayList<String>()
            if (s("tekstur") || s("resolusi")) {
                if (off) actions.add(Action("matikan_tekstur", ""))
                else notes.add("Tekstur Ringan dan Turunkan Resolusi diatur lewat layar yang muncul sebelum game dibuka dari AISZ. Dari sini saya hanya bisa mematikannya.")
            }
            if (s("performa") || s("performance") || s("ngebut") || s("kencang") || s("boost")) actions.add(Action("set_mode", "performa"))
            else if (s("hemat") || s("irit")) actions.add(Action("set_mode", "hemat"))
            else if ((w("seimbang") || s("normal") || s("balance")) && (s("mode") || s("ganti") || s("kembali") || s("ubah"))) actions.add(Action("set_mode", "seimbang"))
            if (s("ping") && !s("berapa") && !s("cek")) actions.add(Action("ping", if (off) "off" else "on"))
            if (s("fokus")) actions.add(Action("fokus", if (off) "off" else "on"))
            if (s("overlay") || w("live")) actions.add(Action("overlay", if (off) "off" else "on"))
            if (s("bersihkan") && (s("ram") || s("memori")) || s("clean")) actions.add(Action("bersihkan_ram", ""))
            val music = s("musik") || s("lagu") || s("putar") || s("jeda") || w("next") || w("pause") || w("play") || s("berikutnya") || s("sebelumnya") || s("lewati")
            if (music) {
                val arg = when {
                    s("jeda") || w("pause") -> "pause"
                    s("berikutnya") || w("next") || s("lewati") || s("ganti lagu") -> "next"
                    s("sebelumnya") || w("prev") -> "prev"
                    off -> "stop"
                    else -> "play"
                }
                actions.add(Action("musik", arg))
            }
            if (s("status") || ((s("suhu") || s("ram") || s("baterai") || s("ping")) && (s("berapa") || s("cek") || s("lihat")))) {
                actions.add(Action("status", ""))
            }
            if (actions.isNotEmpty() || notes.isNotEmpty()) {
                return Reply(notes.joinToString("\n"), actions.distinctBy { it.name + ":" + it.arg })
            }
        }

        var best: Faq? = null
        var bestScore = 0
        for (f in faq) {
            val score = f.keys.count { s(it) }
            if (score > bestScore) {
                bestScore = score
                best = f
            }
        }
        return if (best != null) Reply(best.topic + "\n" + best.answer) else Reply(HELP)
    }
}
