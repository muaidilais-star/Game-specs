package com.aisz.gamespace

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.aisz.gamespace.ui.AiszTheme
import com.aisz.gamespace.ui.LaunchSplashScreen

/** Layar animasi roket singkat sebelum game dibuka. */
class LaunchSplashActivity : ComponentActivity() {
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PKG)
        if (pkg == null) {
            finish()
            return
        }
        val applyProfile = intent.getBooleanExtra(EXTRA_PROFILE, true)
        val name = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
        val icon: ImageBitmap? = try {
            toBitmap(packageManager.getApplicationIcon(pkg)).asImageBitmap()
        } catch (_: Exception) {
            null
        }
        setContent {
            AiszTheme {
                LaunchSplashScreen(
                    gameName = name,
                    icon = icon,
                    onCancel = { finish() },
                    onDone = {
                        if (!done) {
                            done = true
                            GameLauncher(this).launch(pkg, applyProfile, skipSetup = true, skipSplash = true)
                            finish()
                        }
                    }
                )
            }
        }
    }

    private fun toBitmap(d: Drawable): Bitmap {
        val size = 160
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return bmp
    }

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_PROFILE = "apply_profile"
    }
}
