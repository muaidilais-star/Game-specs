package com.aisz.gamespace

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.security.MessageDigest

/**
 * Memeriksa apakah APK yang berjalan masih ditandatangani dengan kunci asli proyek ini. Kunci itu
 * sendiri TIDAK ada di repo (disimpan sebagai GitHub Secrets, lihat .github/workflows/build.yml dan
 * README.md bagian Keamanan dan keaslian APK) — yang ada di sini hanya hash publik hasil tanda tangan,
 * yang memang boleh diketahui semua orang. Bila seseorang mengambil APK ini,
 * mengubahnya, lalu menandatangani ulang dengan kuncinya sendiri untuk dibagikan ulang, tanda tangan
 * yang terbaca di HP pengguna akan BERBEDA dari nilai di bawah, dan ini akan ketahuan.
 *
 * KODE RAHASIA (watermark pembuat): dipakai sebagai bukti kepemilikan bila ada yang mengklaim
 * membuat aplikasi ini. Jangan dibagikan di luar repo ini.
 */
object IntegrityCheck {
    /**
     * Mode bootstrap: keystore sekarang dibuat otomatis oleh workflow (lihat .github/workflows/build.yml,
     * langkah "Siapkan keystore"), bukan dibuat manual lagi, supaya tidak ada lagi teks panjang yang perlu
     * disalin ke GitHub Secrets. Tanda tangannya dijamin SAMA di setiap build selanjutnya (disimpan di cache
     * Actions), tapi nilai hash-nya baru diketahui setelah build pertama kali selesai.
     * Kosong ("") berarti: pemeriksaan ini dilewati (dianggap asli) sampai nilai sebenarnya diisi di sini.
     * Setelah build pertama sukses, lihat log langkah "Siapkan keystore" untuk baris
     * "TANDA TANGAN SAAT INI (SHA-256)", lalu tempel nilainya di sini dan kirim ulang proyeknya sekali lagi —
     * sesudah itu pemeriksaan aktif penuh dan APK yang ditandatangani ulang pihak lain akan ditolak.
     */
    private const val EXPECTED_SHA256 = ""

    /** Kode rahasia pembuat, dipecah jadi beberapa bagian supaya tidak langsung terbaca saat APK dibongkar. */
    private val W = charArrayOf('A', 'I', 'S', 'Z', '-', '2', '0', '2', '6', '-', 'm', 'u', 'a', 'i', 'd', 'i', 'l', 'a', 'i', 's', '-', 's', 't', 'a', 'r')
    fun watermark(): String = String(W)

    class Report(val ok: Boolean, val reason: String, val signatureHash: String?)

    /** True bila tanda tangan APK yang berjalan cocok dengan [EXPECTED_SHA256]. */
    fun check(ctx: Context): Report {
        val hash = currentSignatureSha256(ctx) ?: return Report(false, "Tanda tangan APK tidak terbaca", null)
        if (EXPECTED_SHA256.isBlank()) {
            return Report(true, "Mode bootstrap: EXPECTED_SHA256 belum diisi, pemeriksaan dilewati", hash)
        }
        val ok = hash.equals(EXPECTED_SHA256, ignoreCase = true)
        val reason = if (ok) "Tanda tangan sesuai (asli)" else "Tanda tangan BERBEDA dari aslinya — APK ini kemungkinan telah diubah dan ditandatangani ulang oleh pihak lain"
        return Report(ok, reason, hash)
    }

    private fun currentSignatureSha256(ctx: Context): String? {
      return try {
        val pm = ctx.packageManager
        val sigs: Array<Signature> = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val h = info.signingInfo
            if (h == null) emptyArray() else if (h.hasMultipleSigners()) h.apkContentsSigners else h.signingCertificateHistory
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        val s = sigs.firstOrNull() ?: return null
        val md = MessageDigest.getInstance("SHA-256")
        md.update(s.toByteArray())
        md.digest().joinToString(":") { String.format("%02X", it) }
      } catch (_: Exception) {
          null
      }
    }
}
