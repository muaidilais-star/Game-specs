package com.aisz.gamespace.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.IntegrityCheck

/**
 * Peringatan layar penuh yang tidak bisa ditutup, ditampilkan saat tanda tangan APK tidak cocok
 * dengan kunci asli proyek ini (lihat IntegrityCheck). Ini menandakan APK sudah diubah dan
 * ditandatangani ulang oleh pihak lain, sehingga keaslian dan keamanannya tidak bisa dijamin.
 */
@Composable
fun TamperWarningDialog() {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF14060A))
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("\u26A0", fontSize = 56.sp, modifier = Modifier.fillMaxWidth(), color = Color(0xFFE0605E))
        Spacer(Modifier.height(16.dp))
        Text(
            "APK INI BUKAN VERSI ASLI",
            color = Color(0xFFE0605E), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "Tanda tangan paket aplikasi ini tidak cocok dengan tanda tangan asli AISZ GAME SPACE " +
                "(proyek ${IntegrityCheck.watermark()}). Ini berarti seseorang telah mengubah APK aslinya " +
                "lalu menandatangani ulang dengan kuncinya sendiri sebelum membagikannya.",
            color = Color(0xFFF0D9D9), fontSize = 14.sp
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Risikonya: kode di dalam APK ini bisa saja sudah disisipi sesuatu yang tidak lu ketahui, dan " +
                "pembuat aslinya tidak bisa menjamin keamanannya. Hapus APK ini, lalu pasang ulang dari ZIP " +
                "proyek resmi dan build lewat GitHub Actions milik lu sendiri.",
            color = Color(0xFFF0D9D9), fontSize = 14.sp
        )
        Spacer(Modifier.height(18.dp))
        Text(
            "Aplikasi tidak akan dibuka selama peringatan ini tampil.",
            color = Color(0xFFBFA6A6), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
