package com.aisz.gamespace.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.GamingProfile
import com.aisz.gamespace.NetworkMonitor
import com.aisz.gamespace.PerformanceMonitor
import com.aisz.gamespace.TemperatureMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.random.Random

/** Roket kecil menghadap kanan; 1 satuan = 1 dp. Titik (0,0) di tengah badan roket. */
private fun DrawScope.drawRocket(center: Offset, flame: Float) {
    translate(center.x, center.y) {
        scale(density, density, pivot = Offset.Zero) {
            val outer = Path().apply {
                moveTo(-18f, -5f)
                lineTo(-18f - 16f * flame, 0f)
                lineTo(-18f, 5f)
                close()
            }
            drawPath(outer, Color(0xFFFFA726))
            val inner = Path().apply {
                moveTo(-18f, -2.5f)
                lineTo(-18f - 9f * flame, 0f)
                lineTo(-18f, 2.5f)
                close()
            }
            drawPath(inner, Color(0xFFFFE082))
            val finTop = Path().apply {
                moveTo(-16f, -8f)
                lineTo(-26f, -17f)
                lineTo(-6f, -8f)
                close()
            }
            val finBottom = Path().apply {
                moveTo(-16f, 8f)
                lineTo(-26f, 17f)
                lineTo(-6f, 8f)
                close()
            }
            drawPath(finTop, Color(0xFF2B7FFF))
            drawPath(finBottom, Color(0xFF2B7FFF))
            drawOval(Color(0xFFECF2FA), topLeft = Offset(-20f, -9f), size = Size(40f, 18f))
            val nose = Path().apply {
                moveTo(10f, -8f)
                quadraticBezierTo(24f, -6f, 32f, 0f)
                quadraticBezierTo(24f, 6f, 10f, 8f)
                close()
            }
            drawPath(nose, Color(0xFFE5484D))
            drawCircle(Color(0xFF2B7FFF), radius = 4.2f, center = Offset(2f, 0f))
            drawCircle(Color(0xFFBFE0FF), radius = 2f, center = Offset(1f, -1f))
        }
    }
}

/** Ringkasan keadaan HP dan fitur AISZ yang ditampilkan sebelum game dibuka. */
private class SplashInfo(
    val mode: GamingProfile,
    val hz: Float,
    val frameLock: Boolean,
    val tempC: Float?,
    val tempLabel: String,
    val tempColor: Color,
    val ping: Int?,
    val transport: String,
    val ramPercent: Int,
    val ramFreeMb: Long,
    val battery: Int?,
    val charging: Boolean,
    val texture: String?,
    val resolution: String?
)

private fun readSplashInfo(ctx: android.content.Context): SplashInfo {
    val g = GameSettings(ctx)
    val perf = PerformanceMonitor(ctx)
    val mem = perf.memory()
    val bat = perf.battery()
    val th = TemperatureMonitor(ctx).read()
    val transport = try { NetworkMonitor(ctx).status().transport } catch (_: Exception) { "-" }
    val scales = intArrayOf(85, 70, 60, 50)
    return SplashInfo(
        mode = g.profile,
        hz = perf.deviceInfo().refreshRateHz,
        frameLock = g.frameLock,
        tempC = th.batteryC,
        tempLabel = th.level.label,
        tempColor = levelColor(th.level),
        ping = null,
        transport = transport,
        ramPercent = mem.usedPercent,
        ramFreeMb = mem.availMb.toLong(),
        battery = bat.levelPercent,
        charging = bat.charging,
        texture = if (g.texApplied) "Tingkat ${g.texLevel}" else null,
        resolution = if (g.texAltApplied) "${scales[(g.resLevel - 1).coerceIn(0, 3)]}%" else null
    )
}

private fun modeColor(p: GamingProfile): Color = when (p) {
    GamingProfile.HEMAT -> Color(0xFF5CBF8A)
    GamingProfile.SEIMBANG -> Color(0xFF5B9BE0)
    else -> Color(0xFFE0605E)
}

/** Kotak kecil berisi satu informasi; muncul bertahap saat [shown] menjadi true. */
@Composable
private fun SplashTile(
    label: String,
    value: String,
    sub: String,
    accent: Color,
    shown: Boolean,
    modifier: Modifier = Modifier
) {
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(380, easing = FastOutSlowInEasing), label = "tile")
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .graphicsLayer {
                alpha = a
                translationY = (1f - a) * 26f
            }
            .clip(shape)
            .background(AiszColors.Surface)
            .border(1.dp, accent.copy(alpha = 0.38f), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(6.dp))
            Text(
                label, color = AiszColors.TextDim, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp, maxLines = 1
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(value, color = accent, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(sub, color = AiszColors.TextDim, fontSize = 10.sp, maxLines = 1)
    }
}

/**
 * Layar pembuka game (landscape): latar gelap solid berbintang, delapan kotak kecil berisi mode, layar, suhu,
 * jaringan, RAM, baterai, tekstur, dan resolusi yang muncul bertahap, serta roket meluncur di bilah kemajuan.
 * Selesai otomatis lalu memanggil [onDone].
 */
@Composable
fun LaunchSplashScreen(gameName: String, icon: ImageBitmap?, onCancel: () -> Unit, onDone: () -> Unit) {
    BackHandler { onCancel() }
    val ctx = LocalContext.current
    var info by remember { mutableStateOf(readSplashInfo(ctx)) }
    val enter = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    val fx = rememberInfiniteTransition(label = "fx")
    val flame by fx.animateFloat(
        0.6f, 1.25f,
        infiniteRepeatable(tween(110, easing = LinearEasing), RepeatMode.Reverse), label = "flame"
    )
    val twinkle by fx.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "twinkle"
    )
    val stars = remember { List(46) { Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat()) } }
    var ping by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(Unit) {
        ping = withContext(Dispatchers.IO) { try { NetworkMonitor(ctx).pingMs() } catch (_: Exception) { null } }
    }
    LaunchedEffect(Unit) {
        enter.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        progress.animateTo(1f, tween(2300, easing = FastOutSlowInEasing))
        delay(220)
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF05070D), Color(0xFF0A1730), Color(0xFF0E2447))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            stars.forEach { (sx, sy, ph) ->
                val a = 0.2f + 0.7f * (0.5f + 0.5f * kotlin.math.sin((twinkle + ph) * 6.2832f))
                drawCircle(
                    Color.White.copy(alpha = a.coerceIn(0f, 1f)),
                    radius = (0.7f + 1.4f * ph) * density,
                    center = Offset(sx * size.width, sy * size.height)
                )
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 28.dp, vertical = 14.dp)
                .graphicsLayer { alpha = enter.value }
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Image(
                        bitmap = icon,
                        contentDescription = null,
                        modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("MELUNCURKAN", color = AiszColors.Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(gameName, color = AiszColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                Text(
                    "${(progress.value * 100).toInt()}%",
                    color = AiszColors.Neon, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(AiszColors.Neon.copy(alpha = 0.25f)))
            Spacer(Modifier.height(12.dp))

            val p = progress.value
            val pingColor = when {
                ping == null -> AiszColors.TextDim
                ping!! < 60 -> AiszColors.Ok
                ping!! < 120 -> AiszColors.Warn
                else -> AiszColors.Hot
            }
            val ramColor = when {
                info.ramPercent >= 90 -> AiszColors.Hot
                info.ramPercent >= 75 -> AiszColors.Warn
                else -> AiszColors.Ok
            }
            val batColor = when {
                (info.battery ?: 100) < 20 && !info.charging -> AiszColors.Hot
                (info.battery ?: 100) < 40 && !info.charging -> AiszColors.Warn
                else -> AiszColors.Ok
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SplashTile("MODE", info.mode.label, "Profil game", modeColor(info.mode), p >= 0.04f, Modifier.weight(1f).fillMaxHeight())
                    SplashTile(
                        "FPS", String.format(Locale.US, "%.0f Hz", info.hz),
                        if (info.frameLock) "Refresh dikunci" else "Refresh layar",
                        AiszColors.Neon, p >= 0.12f, Modifier.weight(1f).fillMaxHeight()
                    )
                    SplashTile(
                        "SUHU", info.tempC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "N/A",
                        info.tempLabel, info.tempColor, p >= 0.20f, Modifier.weight(1f).fillMaxHeight()
                    )
                    SplashTile(
                        "JARINGAN", ping?.let { "$it ms" } ?: "...", info.transport,
                        pingColor, p >= 0.28f, Modifier.weight(1f).fillMaxHeight()
                    )
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SplashTile(
                        "RAM", "${info.ramPercent}%", "${info.ramFreeMb} MB bebas",
                        ramColor, p >= 0.36f, Modifier.weight(1f).fillMaxHeight()
                    )
                    SplashTile(
                        "BATERAI", info.battery?.let { "$it%" } ?: "N/A",
                        if (info.charging) "Mengisi" else "Tidak mengisi",
                        batColor, p >= 0.44f, Modifier.weight(1f).fillMaxHeight()
                    )
                    SplashTile(
                        "TEKSTUR", info.texture ?: "Normal", "Tekstur Ringan",
                        if (info.texture != null) AiszColors.NeonSoft else AiszColors.TextDim,
                        p >= 0.52f, Modifier.weight(1f).fillMaxHeight()
                    )
                    SplashTile(
                        "RESOLUSI", info.resolution ?: "Normal", "Render game",
                        if (info.resolution != null) AiszColors.NeonSoft else AiszColors.TextDim,
                        p >= 0.60f, Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            Canvas(Modifier.fillMaxWidth().height(58.dp)) {
                val trackY = size.height * 0.8f
                val left = 4.dp.toPx()
                val right = size.width - 4.dp.toPx()
                val x = left + (right - left) * progress.value
                val stroke = 7.dp.toPx()
                drawLine(AiszColors.SurfaceHigh, Offset(left, trackY), Offset(right, trackY), stroke, StrokeCap.Round)
                if (x > left) {
                    drawLine(
                        Brush.horizontalGradient(listOf(AiszColors.Neon, AiszColors.NeonSoft), startX = left, endX = right),
                        Offset(left, trackY), Offset(x, trackY), stroke, StrokeCap.Round
                    )
                }
                for (i in 1..6) {
                    val tx = x - 34.dp.toPx() - i * 14.dp.toPx()
                    if (tx > left) {
                        drawCircle(
                            AiszColors.NeonSoft.copy(alpha = (0.55f - i * 0.08f).coerceAtLeast(0.05f)),
                            radius = (4.2f - i * 0.5f).coerceAtLeast(1f) * density,
                            center = Offset(tx, trackY - 20.dp.toPx() + (i % 2) * 3.dp.toPx())
                        )
                    }
                }
                drawRocket(Offset(x, trackY - 20.dp.toPx()), flame)
            }
        }
    }
}
