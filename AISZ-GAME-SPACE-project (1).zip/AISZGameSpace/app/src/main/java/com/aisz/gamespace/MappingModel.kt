package com.aisz.gamespace

import android.content.Context
import java.io.File

/** Satu tombol keyboard yang dipetakan ke satu titik sentuh di layar (koordinat pecahan 0..1). */
class MapKey(var label: String, var code: Int, var x: Float, var y: Float)

/**
 * Konfigurasi mapping keyboard/mouse. Disimpan sebagai berkas teks sederhana yang dibaca oleh [InputServer]
 * (proses terpisah lewat Shizuku). Koordinat berupa pecahan lebar/tinggi layar landscape.
 */
class MapConfig {
    var enabled = false
    var quit = false
    var toggleKey = 41 // tanda ` (KEY_GRAVE)
    var sens = 1.5f
    var w = 1600
    var h = 720
    var joyUp = 17 // W
    var joyLeft = 30 // A
    var joyDown = 31 // S
    var joyRight = 32 // D
    var joyX = 0.17f
    var joyY = 0.70f
    var joyR = 0.12f // pecahan tinggi layar
    var lookX = 0.72f
    var lookY = 0.45f
    var fireX = 0.88f
    var fireY = 0.72f
    var scopeX = 0.80f
    var scopeY = 0.52f
    val keys = ArrayList<MapKey>()

    init {
        keys.add(MapKey("Lompat", 57, 0.90f, 0.55f)) // Space
        keys.add(MapKey("Jongkok", 46, 0.94f, 0.74f)) // C
        keys.add(MapKey("Tiarap", 44, 0.96f, 0.64f)) // Z
        keys.add(MapKey("Reload", 19, 0.62f, 0.80f)) // R
        keys.add(MapKey("Ambil", 18, 0.55f, 0.62f)) // E
        keys.add(MapKey("Senjata 1", 2, 0.40f, 0.90f)) // 1
        keys.add(MapKey("Senjata 2", 3, 0.46f, 0.90f)) // 2
        keys.add(MapKey("Granat", 34, 0.50f, 0.20f)) // G
    }

    fun usedCodes(): List<Int> = listOf(toggleKey, joyUp, joyLeft, joyDown, joyRight) + keys.map { it.code }

    fun toText(): String {
        val sb = StringBuilder()
        sb.append("enabled=").append(if (enabled) 1 else 0).append('\n')
        sb.append("quit=").append(if (quit) 1 else 0).append('\n')
        sb.append("toggle=").append(toggleKey).append('\n')
        sb.append("sens=").append(sens).append('\n')
        sb.append("size=").append(w).append(',').append(h).append('\n')
        sb.append("joykeys=").append(joyUp).append(',').append(joyLeft).append(',').append(joyDown).append(',').append(joyRight).append('\n')
        sb.append("joy=").append(joyX).append(',').append(joyY).append(',').append(joyR).append('\n')
        sb.append("look=").append(lookX).append(',').append(lookY).append('\n')
        sb.append("fire=").append(fireX).append(',').append(fireY).append('\n')
        sb.append("scope=").append(scopeX).append(',').append(scopeY).append('\n')
        for (k in keys) {
            sb.append("key=").append(k.label.replace('|', ' ')).append('|').append(k.code).append('|').append(k.x).append('|').append(k.y).append('\n')
        }
        return sb.toString()
    }

    companion object {
        fun parse(text: String): MapConfig {
            val c = MapConfig()
            val parsedKeys = ArrayList<MapKey>()
            for (line in text.lines()) {
                try {
                    val i = line.indexOf('=')
                    if (i <= 0) continue
                    val k = line.substring(0, i).trim()
                    val v = line.substring(i + 1).trim()
                    val p = v.split(',')
                    when (k) {
                        "enabled" -> c.enabled = v == "1"
                        "quit" -> c.quit = v == "1"
                        "toggle" -> c.toggleKey = v.toInt()
                        "sens" -> c.sens = v.toFloat()
                        "size" -> {
                            c.w = p[0].toInt()
                            c.h = p[1].toInt()
                        }
                        "joykeys" -> {
                            c.joyUp = p[0].toInt()
                            c.joyLeft = p[1].toInt()
                            c.joyDown = p[2].toInt()
                            c.joyRight = p[3].toInt()
                        }
                        "joy" -> {
                            c.joyX = p[0].toFloat()
                            c.joyY = p[1].toFloat()
                            c.joyR = p[2].toFloat()
                        }
                        "look" -> {
                            c.lookX = p[0].toFloat()
                            c.lookY = p[1].toFloat()
                        }
                        "fire" -> {
                            c.fireX = p[0].toFloat()
                            c.fireY = p[1].toFloat()
                        }
                        "scope" -> {
                            c.scopeX = p[0].toFloat()
                            c.scopeY = p[1].toFloat()
                        }
                        "key" -> {
                            val q = v.split('|')
                            parsedKeys.add(MapKey(q[0], q[1].toInt(), q[2].toFloat(), q[3].toFloat()))
                        }
                    }
                } catch (_: Exception) {
                }
            }
            if (parsedKeys.isNotEmpty()) {
                c.keys.clear()
                c.keys.addAll(parsedKeys)
            }
            return c
        }
    }
}

/** Nama tombol keyboard (kode Linux input) untuk ditampilkan. */
fun keyName(code: Int): String = when (code) {
    1 -> "Esc"; 14 -> "Backspace"; 15 -> "Tab"; 28 -> "Enter"; 29 -> "Ctrl kiri"; 97 -> "Ctrl kanan"
    42 -> "Shift kiri"; 54 -> "Shift kanan"; 56 -> "Alt kiri"; 100 -> "Alt kanan"; 57 -> "Spasi"; 58 -> "Caps Lock"
    41 -> "` (kutip balik)"; 103 -> "Panah atas"; 108 -> "Panah bawah"; 105 -> "Panah kiri"; 106 -> "Panah kanan"
    2 -> "1"; 3 -> "2"; 4 -> "3"; 5 -> "4"; 6 -> "5"; 7 -> "6"; 8 -> "7"; 9 -> "8"; 10 -> "9"; 11 -> "0"
    16 -> "Q"; 17 -> "W"; 18 -> "E"; 19 -> "R"; 20 -> "T"; 21 -> "Y"; 22 -> "U"; 23 -> "I"; 24 -> "O"; 25 -> "P"
    30 -> "A"; 31 -> "S"; 32 -> "D"; 33 -> "F"; 34 -> "G"; 35 -> "H"; 36 -> "J"; 37 -> "K"; 38 -> "L"
    44 -> "Z"; 45 -> "X"; 46 -> "C"; 47 -> "V"; 48 -> "B"; 49 -> "N"; 50 -> "M"
    59 -> "F1"; 60 -> "F2"; 61 -> "F3"; 62 -> "F4"; 63 -> "F5"; 64 -> "F6"; 65 -> "F7"; 66 -> "F8"; 67 -> "F9"; 68 -> "F10"
    87 -> "F11"; 88 -> "F12"
    else -> "Kode $code"
}

/** Pengendali sisi aplikasi: menulis konfigurasi, membaca status, dan menyalakan/mematikan [InputServer] lewat Shizuku. */
class MappingController(private val ctx: Context) {
    val dir: File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    private val cfgFile = File(dir, "aisz_map.cfg")
    private val statusFile = File(dir, "aisz_map_status.txt")

    fun load(): MapConfig = try {
        if (cfgFile.exists()) MapConfig.parse(cfgFile.readText()) else MapConfig()
    } catch (_: Exception) {
        MapConfig()
    }

    fun save(c: MapConfig) {
        cfgFile.writeText(c.toText())
    }

    fun status(): Map<String, String> {
        val out = HashMap<String, String>()
        try {
            if (statusFile.exists()) {
                for (line in statusFile.readText().lines()) {
                    val i = line.indexOf('=')
                    if (i > 0) out[line.substring(0, i)] = line.substring(i + 1)
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun isRunning(): Boolean {
        val hb = status()["hb"]?.toLongOrNull() ?: return false
        return System.currentTimeMillis() - hb < 3000L
    }

    /** Menyalakan server penyuntik sentuhan sebagai proses terpisah (butuh Shizuku). Panggil dari thread latar. */
    fun start(): ShellResult {
        val c = load()
        c.quit = false
        save(c)
        val apk = ctx.applicationInfo.sourceDir
        val d = dir.absolutePath
        val cmd = "if command -v setsid >/dev/null 2>&1; then S=setsid; else S=; fi; " +
            "CLASSPATH='$apk' nohup \$S app_process /system/bin --nice-name=aisz_input " +
            "com.aisz.gamespace.InputServer '$d' > '$d/aisz_map_server.log' 2>&1 &"
        return ShizukuHelper.exec(cmd)
    }

    fun requestQuit() {
        val c = load()
        c.quit = true
        save(c)
    }
}
