package com.aisz.gamespace

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Klien sederhana ke API Claude. Dipakai hanya bila pengguna memasukkan kunci API sendiri dan menyalakan mode online. */
object ClaudeClient {
    const val MODEL = "claude-haiku-5-5"
    private const val URL_API = "https://api.anthropic.com/v1/messages"

    class Result(val reply: String?, val actions: List<AssistantEngine.Action>, val error: String?)

    fun systemPrompt(status: String): String =
        "Kamu adalah asisten di dalam aplikasi Android AISZ GAME SPACE (panel kontrol game tanpa root, memakai Shizuku). " +
            "Jawab dalam bahasa Indonesia, singkat dan jelas. Jangan mengarang fitur; kalau tidak tahu, katakan tidak tahu. " +
            "Jawaban WAJIB berupa satu objek JSON saja tanpa teks lain: {\"reply\":\"teks jawaban\",\"actions\":[{\"name\":\"...\",\"arg\":\"...\"}]}. " +
            "Isi actions hanya bila pengguna jelas meminta perintah; kalau hanya bertanya, kosongkan. Aksi yang diizinkan: " +
            "set_mode (arg: hemat|seimbang|performa), ping (arg: on|off), fokus (arg: on|off), overlay (arg: on|off), " +
            "musik (arg: play|pause|next|prev|stop), bersihkan_ram (arg: kosong), matikan_tekstur (arg: kosong), status (arg: kosong). " +
            "Tekstur Ringan dan Turunkan Resolusi tidak bisa dinyalakan dari sini, hanya dimatikan.\n\n" +
            "Pengetahuan tentang aplikasi:\n" + AssistantEngine.knowledgeText() + "\n\nKeadaan HP sekarang:\n" + status

    fun ask(key: String, system: String, history: List<Pair<Boolean, String>>, user: String): Result {
        return try {
            val msgs = JSONArray()
            // riwayat: (dariPengguna, teks); pesan harus bergantian dan diawali pengguna
            var expectUser = true
            for ((fromUser, text) in history.takeLast(8)) {
                if (fromUser == expectUser && text.isNotBlank()) {
                    msgs.put(JSONObject().put("role", if (fromUser) "user" else "assistant").put("content", text))
                    expectUser = !expectUser
                }
            }
            if (!expectUser) msgs.put(JSONObject().put("role", "assistant").put("content", "(lanjut)")).also { expectUser = true }
            msgs.put(JSONObject().put("role", "user").put("content", user))
            val body = JSONObject()
                .put("model", MODEL)
                .put("max_tokens", 700)
                .put("system", system)
                .put("messages", msgs)
            val c = URL(URL_API).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 45000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            c.disconnect()
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (_: Exception) { "" }
                val friendly = when (code) {
                    401 -> "Kunci API tidak valid."
                    403 -> "Kunci API tidak punya izin."
                    404 -> "Model tidak ditemukan."
                    429 -> "Terlalu banyak permintaan atau kuota habis."
                    else -> "Server menolak (kode $code)."
                }
                return Result(null, emptyList(), (friendly + " " + msg).trim().take(200))
            }
            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val part = content.getJSONObject(i)
                if (part.optString("type") == "text") sb.append(part.optString("text"))
            }
            parse(sb.toString())
        } catch (e: Exception) {
            Result(null, emptyList(), "Tidak bisa terhubung: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun parse(raw: String): Result {
        val a = raw.indexOf('{')
        val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return Result(raw.trim(), emptyList(), null)
        return try {
            val o = JSONObject(raw.substring(a, b + 1))
            val reply = o.optString("reply", "").trim()
            val acts = ArrayList<AssistantEngine.Action>()
            val arr = o.optJSONArray("actions")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    val act = AssistantEngine.Action(x.optString("name"), x.optString("arg"))
                    if (AssistantEngine.isAllowed(act)) acts.add(act) // aksi di luar daftar putih dibuang
                }
            }
            Result(reply.ifBlank { null }, acts, null)
        } catch (_: Exception) {
            Result(raw.trim(), emptyList(), null)
        }
    }
}
