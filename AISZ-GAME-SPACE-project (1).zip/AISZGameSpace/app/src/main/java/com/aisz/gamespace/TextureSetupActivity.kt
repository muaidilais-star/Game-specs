package com.aisz.gamespace

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.aisz.gamespace.ui.AiszTheme
import com.aisz.gamespace.ui.TextureSetupScreen

/** Layar singkat sebelum Free Fire / Free Fire MAX dibuka: atur Tekstur Ringan, lalu mulai game. */
class TextureSetupActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PKG)
        if (pkg == null) {
            finish()
            return
        }
        val applyProfile = intent.getBooleanExtra(EXTRA_PROFILE, true)
        val name = if (pkg == "com.dts.freefiremax") "Free Fire MAX" else "Free Fire"
        setContent {
            AiszTheme {
                TextureSetupScreen(
                    gameName = name,
                    onCancel = { finish() },
                    onStart = { on, level, sharp, noAniso, resOn, resLevel ->
                        val settings = GameSettings(this)
                        settings.texLevel = level
                        settings.texSharp = sharp
                        settings.texNoAniso = noAniso
                        settings.texAlt = resOn
                        settings.resLevel = resLevel
                        Thread {
                            var info = ""
                            if (ShizukuHelper.hasPermission()) {
                                val r = ShellTools.setLightTexture(on, level, sharp, noAniso)
                                settings.texApplied = on && r.ok
                                info = if (!r.ok) "Gagal menerapkan: ${r.error.take(60)}"
                                else if (on) "Terpasang: " + ShellTools.lightTextureProp().replace("force", "").replace("Filtering", "")
                                else "Tekstur Ringan dimatikan"
                                if (on || resOn) settings.texAppliedAt = System.currentTimeMillis()
                                if (resOn) {
                                    val r2 = ShellTools.setGameDownscale(true, resLevel, pkg)
                                    settings.texAltApplied = r2.ok
                                    info += if (r2.ok) " | Resolusi diturunkan" else " | Turunkan resolusi gagal: ${r2.error.take(70)}"
                                } else if (settings.texAltApplied) {
                                    ShellTools.setGameDownscale(false, resLevel)
                                    settings.texAltApplied = false
                                }
                            }
                            runOnUiThread {
                                if (info.isNotEmpty()) Toast.makeText(this, info, Toast.LENGTH_LONG).show()
                                GameLauncher(this).launch(pkg, applyProfile, skipSetup = true)
                                finish()
                            }
                        }.start()
                    }
                )
            }
        }
    }

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_PROFILE = "apply_profile"
    }
}
