package com.aisz.gamespace

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import kotlin.math.max

/** Penghubung sederhana: panel dipanggil ulang setelah foto atau link sebuah slot diganti. */
object LiveBridge {
    var onChanged: ((Int) -> Unit)? = null
    const val EXTRA_SLOT = "slot"

    /** Slot 0 memakai nama berkas lama supaya foto sebelumnya tetap terbaca. */
    fun imageName(slot: Int): String = if (slot == 0) "live_overlay.png" else "live_overlay_$slot.png"
}

/** Memilih foto dari HP untuk satu slot; disalin (diperkecil) ke penyimpanan aplikasi. */
class LiveImagePickActivity : ComponentActivity() {
    private var slot = 0

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            finish()
        } else {
            Thread {
                val ok = saveImage(uri)
                runOnUiThread {
                    if (ok) {
                        val g = GameSettings(this)
                        g.setLiveMode(slot, 0)
                        g.setLiveOn(slot, true)
                        g.liveMaster = true
                        Toast.makeText(this, "Foto dipasang di slot ${slot + 1}", Toast.LENGTH_SHORT).show()
                        LiveBridge.onChanged?.invoke(slot)
                    } else {
                        Toast.makeText(this, "Foto tidak bisa dibaca", Toast.LENGTH_LONG).show()
                    }
                    finish()
                }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        slot = intent.getIntExtra(LiveBridge.EXTRA_SLOT, 0).coerceIn(0, GameSettings.LIVE_SLOTS - 1)
        picker.launch(arrayOf("image/*"))
    }

    private fun saveImage(uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val side = max(bounds.outWidth, bounds.outHeight)
        while (side / sample > 1600) sample *= 2
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (bmp == null) {
            false
        } else {
            File(filesDir, LiveBridge.imageName(slot)).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
            true
        }
    } catch (_: Exception) {
        false
    }
}

/** Mengisi link halaman untuk satu slot overlay (mis. dari Sociabuzz). Hanya https; dimuat tanpa login. */
class LiveLinkActivity : Activity() {
    private var slot = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        slot = intent.getIntExtra(LiveBridge.EXTRA_SLOT, 0).coerceIn(0, GameSettings.LIVE_SLOTS - 1)
        val d = resources.displayMetrics.density
        val input = EditText(this).apply {
            setText(GameSettings(this@LiveLinkActivity).liveUrl(slot))
            hint = "https://sociabuzz.com/..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setSelectAllOnFocus(true)
        }
        val box = FrameLayout(this).apply {
            setPadding((20 * d).toInt(), (8 * d).toInt(), (20 * d).toInt(), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Link untuk slot ${slot + 1}")
            .setMessage("Tempel link halaman, misalnya dari Sociabuzz. Hanya link https. Halaman hanya ditampilkan, tanpa login dan tanpa terhubung ke akun.")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ -> save(input.text.toString()) }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun save(raw: String) {
        var s = raw.trim()
        if (s.isEmpty()) {
            finish()
            return
        }
        if (!s.contains("://")) s = "https://$s"
        val u = Uri.parse(s)
        if (u.scheme != "https" || u.host.isNullOrBlank()) {
            Toast.makeText(this, "Link harus diawali https://", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val g = GameSettings(this)
        g.setLiveUrl(slot, s)
        g.setLiveMode(slot, 1)
        g.setLiveOn(slot, true)
        g.liveMaster = true
        Toast.makeText(this, "Link disimpan di slot ${slot + 1}", Toast.LENGTH_SHORT).show()
        LiveBridge.onChanged?.invoke(slot)
        finish()
    }
}
