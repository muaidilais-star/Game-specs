package com.aisz.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/** Menampilkan notifikasi pemutar musik (putar/jeda, sebelumnya, berikutnya, berhenti) selama lagu aktif. */
class MusicService : Service() {

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY && MusicEngine.isPlaying) MusicEngine.toggle(c)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(noisy)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        MusicEngine.ensureLoaded(this)
        when (intent?.action) {
            ACTION_TOGGLE -> MusicEngine.toggle(this)
            ACTION_NEXT -> MusicEngine.next(this)
            ACTION_PREV -> MusicEngine.prev(this)
            ACTION_STOP -> MusicEngine.stop(this)
        }
        // Layanan latar depan wajib menampilkan notifikasi segera, termasuk saat akan berhenti.
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (!MusicEngine.isActive) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Pemutar musik", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun action(icon: Int, label: String, act: String, code: Int): NotificationCompat.Action {
        val i = Intent(this, MusicService::class.java).setAction(act)
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val pi = if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, code, i, flags)
        else PendingIntent.getService(this, code, i, flags)
        return NotificationCompat.Action(icon, label, pi)
    }

    private fun buildNotification(): Notification {
        createChannel()
        val playing = MusicEngine.isPlaying
        val speedTxt = if (MusicEngine.speed != 1f) String.format(Locale.US, " · %.2fx", MusicEngine.speed) else ""
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_aisz)
            .setContentTitle(MusicEngine.title ?: "Pemutar musik")
            .setContentText((if (playing) "Memutar" else "Dijeda") + speedTxt)
            .setContentIntent(open)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(action(android.R.drawable.ic_media_previous, "Sebelumnya", ACTION_PREV, 1))
            .addAction(
                action(
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                    if (playing) "Jeda" else "Putar", ACTION_TOGGLE, 2
                )
            )
            .addAction(action(android.R.drawable.ic_media_next, "Berikutnya", ACTION_NEXT, 3))
            .addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", ACTION_STOP, 4))
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "aisz_music"
        private const val NOTIF_ID = 4410
        const val ACTION_TOGGLE = "com.aisz.gamespace.MUSIC_TOGGLE"
        const val ACTION_NEXT = "com.aisz.gamespace.MUSIC_NEXT"
        const val ACTION_PREV = "com.aisz.gamespace.MUSIC_PREV"
        const val ACTION_STOP = "com.aisz.gamespace.MUSIC_STOP"

        /** Menyamakan notifikasi dengan keadaan pemutar: tampil bila ada lagu aktif, hilang bila tidak. */
        fun sync(ctx: Context) {
            val i = Intent(ctx, MusicService::class.java)
            try {
                if (MusicEngine.isActive) ContextCompat.startForegroundService(ctx, i) else ctx.stopService(i)
            } catch (_: Exception) {
            }
        }
    }
}
