# AISZ GAME SPACE v1.6.0

Aplikasi Android (Kotlin + Jetpack Compose): dashboard bertema hitam-biru, panel gaming melayang,
game launcher dengan profil per game, monitor FPS/suhu/WLAN/latensi/RAM, rekam layar, Jangan Ganggu,
dan dukungan Shizuku (dimulai lewat ADB nirkabel).

- Package: `com.aisz.gamespace` - minSdk 24, target/compileSdk 35
- AGP 8.6.1, Gradle 8.7, Kotlin 1.9.24, Compose BOM 2024.06.00, JDK 17

## Build
- GitHub Actions: `.github/workflows` (APK debug sebagai artifact), atau
- Android Studio: Build > Build APK(s), atau `gradle assembleDebug`.

## Shizuku / ADB nirkabel
Fitur sistem (FPS game, Game Mode, Penghemat Baterai, kunci refresh rate, jendela mengambang)
memakai Shizuku. Mulai Shizuku lewat Debugging nirkabel (Android 11+) atau ADB dari PC, lalu
ketuk "Izinkan" di AISZ > Atur. Tanpa Shizuku fitur tersebut dinonaktifkan dengan pesan jelas.

## Catatan jujur
- Mode Hemat/Seimbang/Performa memakai Game Mode & Penghemat Baterai bawaan Android. Efeknya bergantung
  pada game dan ROM; tidak ada jaminan kenaikan FPS.
- FPS game dibaca dari SurfaceFlinger (best effort); bila tidak terbaca tampil N/A.
- Jendela mengambang memakai `am start --windowingMode 5`; hanya jalan jika ROM mendukung freeform.
- Rekam layar tanpa audio, disimpan di Movies/AISZ.

## Keamanan dan keaslian APK
Keystore tanda tangan proyek ini **dibuat otomatis oleh GitHub Actions sendiri**, sekali saja, lalu
disimpan di cache Actions (`actions/cache`, key `aisz-signing-keystore-v1`) dan dipakai lagi di setiap
build berikutnya — tanda tangannya tetap sama selamanya selama cache itu tidak dihapus. Tidak ada lagi
keystore atau password yang perlu disalin manual ke GitHub Secrets; cara lama itu (KEYSTORE_HEX /
KEYSTORE_BASE64 dan lainnya) sudah tidak dipakai dan boleh dihapus dari Settings > Secrets and variables
> Actions kalau masih ada.

**Langkah sekali saja setelah build pertama berhasil:**
1. Buka run Actions yang berhasil, buka langkah **Siapkan keystore**, cari baris
   "TANDA TANGAN SAAT INI (SHA-256)" dan salin nilainya.
2. Tempel nilai itu ke `EXPECTED_SHA256` di `IntegrityCheck.kt` (menggantikan string kosong `""`).
3. Kirim ulang proyek (atau minta AISZ melakukannya) dan build ulang sekali lagi.
4. Sesudah itu, pemeriksaan keaslian aktif penuh: APK yang diambil, diubah, dan ditandatangani ulang
   oleh pihak lain akan ditolak (menampilkan peringatan layar penuh, panel Game Space tidak menyala).

Sebelum langkah itu selesai, `EXPECTED_SHA256` kosong dan `IntegrityCheck` berjalan dalam **mode
bootstrap**: semua APK dianggap asli sementara, supaya build pertama tidak langsung ditolak hanya
karena hash-nya belum diketahui.

- Bila cache keystore pernah terhapus (jarang terjadi, atau sengaja dihapus lewat Settings > Actions >
  Caches), build berikutnya otomatis membuat keystore baru dan tanda tangannya berubah — ulangi 4 langkah
  di atas dengan hash yang baru.
- `IntegrityCheck.watermark()` adalah kode identitas proyek ini, tampil di tab Profil > Kode proyek,
  sebagai bukti kepemilikan bila ada yang mengklaim membuat aplikasi ini.
- Batasannya: pemeriksaan ini mendeteksi APK yang sudah ditandatangani ulang, tapi tidak bisa mencegah
  seseorang yang cukup paham membongkar APK (decompile) dan menghapus kode pemeriksaannya sendiri sebelum
  menandatangani ulang. Tidak ada proteksi APK Android yang benar-benar tidak bisa ditembus.
