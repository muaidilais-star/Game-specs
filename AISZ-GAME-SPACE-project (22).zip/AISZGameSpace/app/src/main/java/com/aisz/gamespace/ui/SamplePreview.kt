package com.aisz.gamespace.ui

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.LinearGradient
import android.graphics.Paint as AndroidPaint
import android.graphics.Path
import android.graphics.Shader
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.max

/** Adegan contoh buatan sendiri (bukan gambar game) untuk melihat perkiraan efek tiap tingkat. */
private fun buildSampleScene(): Bitmap {
    val w = 320
    val h = 180
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(bmp)
    val p = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 0f, 100f, 0xFF6FA8E6.toInt(), 0xFFDDEBF8.toInt(), Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, w.toFloat(), 100f, p)
    p.shader = null
    val rnd = java.util.Random(11)
    var x = 0f
    while (x < w) {
        val bw = 16f + rnd.nextInt(24)
        val bh = 26f + rnd.nextInt(48)
        p.color = if (rnd.nextBoolean()) 0xFF8C96AB.toInt() else 0xFF7A859B.toInt()
        c.drawRect(x, 100f - bh, x + bw, 100f, p)
        p.color = 0xFFE3EEF9.toInt()
        var wy = 100f - bh + 4f
        while (wy < 95f) {
            var wx = x + 3f
            while (wx < x + bw - 4f) {
                c.drawRect(wx, wy, wx + 3f, wy + 3f, p)
                wx += 6f
            }
            wy += 7f
        }
        x += bw + 2f
    }
    p.color = 0xFF5A6068.toInt()
    c.drawRect(0f, 100f, w.toFloat(), h.toFloat(), p)
    var y = 101f
    var gap = 1.5f
    var alt = false
    while (y < h) {
        p.color = if (alt) 0xFF6B727A.toInt() else 0xFF50565D.toInt()
        c.drawRect(0f, y, w.toFloat(), y + gap, p)
        y += gap
        gap *= 1.16f
        alt = !alt
    }
    p.color = 0xFFE8A22F.toInt()
    val road = Path()
    road.moveTo(200f, 100f)
    road.lineTo(208f, 100f)
    road.lineTo(300f, 180f)
    road.lineTo(215f, 180f)
    road.close()
    c.drawPath(road, p)
    p.color = 0xFFF2F2F2.toInt()
    var ly = 106f
    var lh = 2f
    while (ly < h) {
        c.drawRect(40f, ly, 40f + lh * 3f, ly + lh, p)
        ly += lh * 3f
        lh *= 1.25f
    }
    p.color = 0xFF2D3A55.toInt()
    c.drawCircle(120f, 90f, 9f, p)
    p.color = 0xFF63B7EE.toInt()
    c.drawRect(108f, 100f, 132f, 135f, p)
    p.color = 0xFFFFFFFF.toInt()
    c.drawRect(112f, 100f, 115f, 135f, p)
    c.drawRect(120f, 100f, 123f, 135f, p)
    c.drawRect(128f, 100f, 131f, 135f, p)
    p.color = 0xFFC99A74.toInt()
    c.drawRect(110f, 135f, 118f, 160f, p)
    c.drawRect(122f, 135f, 130f, 160f, p)
    return bmp
}

/**
 * Menampilkan adegan contoh dengan detail diturunkan [factor] kali.
 * smooth = false: kotak tegas (tekstur ringan); smooth = true: pecah halus (turunkan resolusi).
 */
@Composable
fun SamplePreview(factor: Float, smooth: Boolean, modifier: Modifier = Modifier) {
    val base = remember { buildSampleScene() }
    val small = remember(factor) {
        val w = max(8, (base.width / factor).toInt())
        val h = max(4, (base.height / factor).toInt())
        Bitmap.createScaledBitmap(base, w, h, true).asImageBitmap()
    }
    Canvas(
        modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(10.dp))
    ) {
        drawImage(
            image = small,
            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            filterQuality = if (smooth) FilterQuality.Medium else FilterQuality.None
        )
    }
}
