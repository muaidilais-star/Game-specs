package com.aisz.gamespace.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.ShellTools
import com.aisz.gamespace.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val TEX_FACTORS = floatArrayOf(1f, 2f, 4f, 16f)
private val RES_SCALES = floatArrayOf(0.85f, 0.7f, 0.6f, 0.5f)

/** Layar sebelum game dibuka: dua fitur terpisah (Tekstur Ringan dan Turunkan Resolusi), masing-masing satu halaman. */
@Composable
fun TextureSetupScreen(
    gameName: String,
    onCancel: () -> Unit,
    // texOn, texLevel, sharp, noAniso, resOn, resLevel
    onStart: (Boolean, Int, Boolean, Boolean, Boolean, Int) -> Unit
) {
    val ctx = LocalContext.current
    val settings = remember { GameSettings(ctx) }
    var page by remember { mutableStateOf(0) }
    var texOn by remember { mutableStateOf(false) }
    var texLevel by remember { mutableStateOf(settings.texLevel) }
    var sharp by remember { mutableStateOf(settings.texSharp) }
    var noAniso by remember { mutableStateOf(settings.texNoAniso) }
    var resOn by remember { mutableStateOf(settings.texAlt) }
    var resLevel by remember { mutableStateOf(settings.resLevel) }
    var shizuku by remember { mutableStateOf<Boolean?>(null) }
    var sysProp by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val resSupported = Build.VERSION.SDK_INT >= 33

    LaunchedEffect(Unit) {
        val ok = withContext(Dispatchers.IO) { ShizukuHelper.hasPermission() }
        shizuku = ok
        if (ok) {
            texOn = withContext(Dispatchers.IO) { ShellTools.lightTextureOn() }
            sysProp = withContext(Dispatchers.IO) { ShellTools.lightTextureProp() }
        }
    }

    val switchColors = SwitchDefaults.colors(
        checkedThumbColor = AiszColors.Black,
        checkedTrackColor = AiszColors.Neon,
        uncheckedThumbColor = AiszColors.TextDim,
        uncheckedTrackColor = AiszColors.SurfaceHigh
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (!busy) onCancel()
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .widthIn(max = 460.dp)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            GlowCard(
                Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            ) {
                SectionTitle("Atur sebelum $gameName dibuka")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonChip("Tekstur Ringan", page == 0, Modifier.weight(1f)) { page = 0 }
                    NeonChip("Turunkan Resolusi", page == 1, Modifier.weight(1f)) { page = 1 }
                }
                Spacer(Modifier.height(12.dp))

                if (shizuku == false) {
                    Text(
                        "Shizuku belum aktif, jadi pengaturan tidak bisa diterapkan. Game tetap dibuka seperti biasa.",
                        color = AiszColors.Warn,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                }

                if (page == 0) {
                    Text(
                        "Tekstur game dibuat kotak-kotak supaya GPU lebih ringan.",
                        color = AiszColors.TextDim,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Aktifkan Tekstur Ringan", color = AiszColors.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Switch(checked = texOn, onCheckedChange = { texOn = it }, enabled = shizuku == true, colors = switchColors)
                    }
                    Spacer(Modifier.height(10.dp))
                    SectionTitle("Tingkat kotak")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NeonChip("1 Tipis", texLevel == 1, Modifier.weight(1f)) { texLevel = 1 }
                        NeonChip("2 Sedikit", texLevel == 2, Modifier.weight(1f)) { texLevel = 2 }
                        NeonChip("3 Sedang", texLevel == 3, Modifier.weight(1f)) { texLevel = 3 }
                        NeonChip("4 Penuh", texLevel == 4, Modifier.weight(1f)) { texLevel = 4 }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("Asli", color = AiszColors.TextDim, fontSize = 11.sp)
                            SamplePreview(1f, smooth = false)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Tingkat $texLevel", color = AiszColors.Neon, fontSize = 11.sp)
                            SamplePreview(TEX_FACTORS[texLevel - 1], smooth = false)
                        }
                    }
                    Text(
                        when (texLevel) {
                            1 -> "Tipis: kotak halus, garis blur di tanah hampir tidak ada. Hemat GPU paling kecil."
                            2 -> "Sedikit: kotak ringan, garis blur sedikit."
                            3 -> "Sedang: kotak jelas, garis blur di tanah mulai terlihat."
                            else -> "Penuh: paling kotak dan paling ringan, garis blur di tanah paling jelas."
                        },
                        color = AiszColors.TextDim,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    Text(
                        "Gambar contoh buatan AISZ, hanya perkiraan. Hasil asli tergantung game dan HP.",
                        color = AiszColors.TextDim,
                        fontSize = 10.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Jarak tegas", color = AiszColors.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Switch(checked = sharp, onCheckedChange = { sharp = it }, colors = switchColors)
                    }
                    Text(
                        "Perpindahan detail tekstur antar jarak dibuat tegas, tanpa campuran halus. Blur yang berasal " +
                            "dari pengaturan grafis game sendiri tidak bisa dihilangkan dari sini.",
                        color = AiszColors.TextDim,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Eksperimen: matikan anisotropik", color = AiszColors.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Switch(checked = noAniso, onCheckedChange = { noAniso = it }, colors = switchColors)
                    }
                    Text(
                        "Dicoba bila jarak tegas belum mengubah apa pun. Hasilnya bisa lebih tajam atau malah lebih buram.",
                        color = AiszColors.TextDim,
                        fontSize = 11.sp
                    )
                    if (sysProp.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Terpasang di sistem: $sysProp", color = AiszColors.TextDim, fontSize = 10.sp)
                    }
                    Text(
                        "Bila efek kotak tidak terlihat di HP ini, coba fitur Turunkan Resolusi.",
                        color = AiszColors.TextDim,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                } else {
                    Text(
                        "Menurunkan resolusi render game lewat Game Mode. Gambar jadi lebih pecah tetapi GPU lebih ringan.",
                        color = AiszColors.TextDim,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    if (!resSupported) {
                        Text(
                            "Fitur ini butuh Android 13 ke atas. HP ini memakai Android ${Build.VERSION.RELEASE}.",
                            color = AiszColors.Warn,
                            fontSize = 12.sp
                        )
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Aktifkan Turunkan Resolusi", color = AiszColors.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Switch(checked = resOn, onCheckedChange = { resOn = it }, enabled = shizuku == true, colors = switchColors)
                        }
                        Spacer(Modifier.height(10.dp))
                        SectionTitle("Tingkat resolusi")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NeonChip("1 · 85%", resLevel == 1, Modifier.weight(1f)) { resLevel = 1 }
                            NeonChip("2 · 70%", resLevel == 2, Modifier.weight(1f)) { resLevel = 2 }
                            NeonChip("3 · 60%", resLevel == 3, Modifier.weight(1f)) { resLevel = 3 }
                            NeonChip("4 · 50%", resLevel == 4, Modifier.weight(1f)) { resLevel = 4 }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text("Asli", color = AiszColors.TextDim, fontSize = 11.sp)
                                SamplePreview(1f, smooth = true)
                            }
                            Column(Modifier.weight(1f)) {
                                Text("Tingkat $resLevel", color = AiszColors.Neon, fontSize = 11.sp)
                                SamplePreview(1f / RES_SCALES[resLevel - 1], smooth = true)
                            }
                        }
                        Text(
                            when (resLevel) {
                                1 -> "85%: sedikit lebih lembut, hemat GPU kecil."
                                2 -> "70%: seimbang antara ketajaman dan hemat GPU."
                                3 -> "60%: terlihat pecah, hemat GPU besar."
                                else -> "50%: paling pecah dan paling ringan."
                            },
                            color = AiszColors.TextDim,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        Text(
                            "Gambar contoh buatan AISZ, hanya perkiraan. Tidak bergantung pada ANGLE, jadi bisa dipakai di HP " +
                                "yang tekstur kotaknya tidak muncul.",
                            color = AiszColors.TextDim,
                            fontSize = 10.sp
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text(
                    "Jika game sedang berjalan, tutup dulu agar pengaturan berlaku.",
                    color = AiszColors.TextDim,
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    GhostButton("Batal", Modifier.weight(1f)) { if (!busy) onCancel() }
                    Spacer(Modifier.width(10.dp))
                    NeonButton("MULAI GAME", Modifier.weight(1.5f), enabled = !busy) {
                        busy = true
                        onStart(texOn, texLevel, sharp, noAniso, resOn && resSupported, resLevel)
                    }
                }
            }
        }
    }
}
