package com.aisz.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ShellResult(val ok: Boolean, val output: String, val error: String = "")

data class FpsResult(val fps: Int?, val note: String)

data class SysSample(val cpuPct: Int?, val cpuGhz: Float?, val gpuPct: Int?)

/**
 * Akses shell lewat Shizuku. Shizuku dimulai tanpa root lewat Debugging nirkabel (Android 11+)
 * atau ADB dari PC. Catatan: Shizuku yang dimulai lewat ADB nirkabel berhenti saat Wi-Fi putus
 * atau HP dimulai ulang.
 */
object ShizukuHelper {
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val REQUEST_CODE = 4242

    fun isInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku belum berjalan
        }
    }

    /** Menjalankan perintah shell. Panggil dari thread latar belakang, bukan UI. */
    fun exec(command: String): ShellResult {
        if (!hasPermission()) return ShellResult(false, "", "Shizuku belum aktif atau izin belum diberikan")
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = p.inputStream.bufferedReader().readText().trim()
            val err = p.errorStream.bufferedReader().readText().trim()
            val code = p.waitFor()
            val failed = code != 0 || out.startsWith("Error") || out.contains("Exception") ||
                out.contains("Unknown command")
            ShellResult(!failed, out, err)
        } catch (e: Throwable) {
            ShellResult(false, "", e.message ?: e.javaClass.simpleName)
        }
    }
}

/** Menjalankan perintah baca-saja (dumpsys) dengan izin DUMP milik AISZ sendiri, tanpa Shizuku. */
object LocalShell {
    fun exec(command: String): ShellResult = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
        val out = p.inputStream.bufferedReader().readText().trim()
        val err = p.errorStream.bufferedReader().readText().trim()
        p.waitFor()
        val denied = out.contains("Permission Denial") || err.contains("Permission Denial")
        ShellResult(!denied, out, err)
    } catch (e: Throwable) {
        ShellResult(false, "", e.message ?: "gagal")
    }
}

/** Perintah yang dipakai AISZ. Semua argumen divalidasi sebelum masuk ke shell. */
object ShellTools {
    private val SAFE = Regex("[A-Za-z0-9._/]+")
    private fun safe(s: String): Boolean = SAFE.matches(s)

    @Volatile
    var appCtx: Context? = null

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
    }

    fun hasDump(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.DUMP") == PackageManager.PERMISSION_GRANTED

    fun hasSecureSettings(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** True bila FPS/foreground bisa dibaca: lewat Shizuku, atau lewat izin DUMP milik AISZ. */
    fun canRead(): Boolean {
        if (ShizukuHelper.hasPermission()) return true
        val c = appCtx ?: return false
        return hasDump(c)
    }

    /** Membaca dumpsys: Shizuku bila aktif, selain itu izin DUMP sendiri. */
    fun read(cmd: String): ShellResult {
        if (ShizukuHelper.hasPermission()) return ShizukuHelper.exec(cmd)
        val c = appCtx
        if (c != null && hasDump(c)) return LocalShell.exec(cmd)
        return ShellResult(false, "", "Shizuku/DUMP tidak tersedia")
    }

    /**
     * Saat Shizuku aktif, AISZ memberi dirinya izin DUMP dan WRITE_SECURE_SETTINGS (izin tingkat
     * pengembang). Izin ini bertahan walau Shizuku berhenti, sehingga FPS dan Penghemat Baterai
     * tetap bisa dipakai.
     */
    fun ensureSelfPermissions(ctx: Context): Boolean {
        if (!ShizukuHelper.hasPermission()) return hasDump(ctx)
        val pkg = ctx.packageName
        ShizukuHelper.exec(
            "pm grant $pkg android.permission.DUMP; pm grant $pkg android.permission.WRITE_SECURE_SETTINGS"
        )
        return hasDump(ctx)
    }

    fun setBatterySaver(on: Boolean): ShellResult =
        ShizukuHelper.exec("settings put global low_power ${if (on) 1 else 0}")

    /** Mode kinerja HP (Power HAL). Tidak semua HP mendukung; hasil dilaporkan jujur. */
    fun setFixedPerformance(on: Boolean): ShellResult {
        val a = ShizukuHelper.exec("cmd power set-fixed-performance-mode-enabled ${if (on) "true" else "false"}")
        if (a.ok) return a
        return ShizukuHelper.exec("cmd power set-mode 2 ${if (on) "true" else "false"}")
    }

    /** mode: standard | performance | battery (Game Mode bawaan Android 12+). */
    fun setGameMode(pkg: String, mode: String): ShellResult {
        if (!safe(pkg) || mode !in listOf("standard", "performance", "battery")) {
            return ShellResult(false, "", "Argumen tidak valid")
        }
        return ShizukuHelper.exec("cmd game mode $mode $pkg")
    }

    fun lockRefreshRate(hz: Float): ShellResult {
        val v = String.format(Locale.US, "%.1f", hz)
        return ShizukuHelper.exec(
            "settings put system min_refresh_rate $v; settings put system peak_refresh_rate $v"
        )
    }

    fun unlockRefreshRate(): ShellResult = ShizukuHelper.exec(
        "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
    )

    fun setBrightness(value0to255: Int): ShellResult = ShizukuHelper.exec(
        "settings put system screen_brightness_mode 0; " +
            "settings put system screen_brightness ${value0to255.coerceIn(1, 255)}"
    )

    /** Paket aplikasi yang sedang di layar depan (dua cara, yang kedua sebagai cadangan). */
    fun foregroundPackage(): String? {
        val re = Regex("u\\d+\\s+([A-Za-z0-9._]+)/")
        val a = read(
            "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 2"
        ).output
        re.find(a)?.groupValues?.get(1)?.let { return it }
        val b = read("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -n 3").output
        return re.find(b)?.groupValues?.get(1)
    }

    // ---------------- sensor CPU / frekuensi / GPU untuk Monitor ----------------
    @Volatile private var prevCpu: LongArray? = null
    @Volatile private var procBlocked = false
    private val GPU_PATHS = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",
        "/sys/kernel/ged/hal/gpu_utilization",
        "/proc/mali/utilization",
        "/sys/class/misc/mali0/device/utilization"
    )

    private fun readFile(path: String): String? = try {
        java.io.File(path).readText()
    } catch (e: Throwable) {
        null
    }

    private fun parseCpuLine(line: String): Int? {
        val p = line.trim().split(Regex("\\s+"))
        if (p.size < 5 || p[0] != "cpu") return null
        val v = p.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (v.size < 4) return null
        val total = v.sum()
        val idle = v[3] + (v.getOrNull(4) ?: 0L)
        val prev = prevCpu
        prevCpu = longArrayOf(total, idle)
        if (prev == null) return null
        val dt = total - prev[0]
        val di = idle - prev[1]
        if (dt <= 0L) return null
        return (100.0 * (dt - di) / dt).roundToInt().coerceIn(0, 100)
    }

    private fun javaFreqGhz(): Float? {
        var best = 0L
        try {
            java.io.File("/sys/devices/system/cpu").listFiles()?.forEach { d ->
                if (d.name.matches(Regex("cpu\\d+"))) {
                    val v = readFile("${d.path}/cpufreq/scaling_cur_freq")?.trim()?.toLongOrNull()
                    if (v != null && v > best) best = v
                }
            }
        } catch (_: Throwable) {
        }
        return if (best > 0L) best / 1_000_000f else null
    }

    /**
     * Membaca pemakaian CPU, frekuensi tertinggi, dan beban GPU. Pertama lewat berkas langsung (sering ditolak
     * Android 8+), lalu lewat Shizuku/DUMP. Nilai yang tidak tersedia di HP ini dikembalikan null (tampil N/A).
     */
    fun sampleSystem(needCpu: Boolean, needFreq: Boolean, needGpu: Boolean): SysSample {
        var cpu: Int? = null
        var ghz: Float? = null
        var gpu: Int? = null
        if (needCpu && !procBlocked) {
            val t = readFile("/proc/stat")
            if (t == null) procBlocked = true
            else cpu = t.lineSequence().firstOrNull { it.startsWith("cpu ") }?.let { parseCpuLine(it) }
        }
        if (needFreq) ghz = javaFreqGhz()
        val shellCpu = needCpu && cpu == null && procBlocked
        val shellFreq = needFreq && ghz == null
        if ((shellCpu || shellFreq || needGpu) && canRead()) {
            val cmd = buildString {
                if (shellCpu) append("head -n 1 /proc/stat; ")
                append("echo '#FREQ'; ")
                if (shellFreq) append("cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null; ")
                append("echo '#GPU'; ")
                if (needGpu) {
                    append("for p in ${GPU_PATHS.joinToString(" ")}; do if [ -r \$p ]; then cat \$p; break; fi; done")
                }
            }
            var section = 0
            var maxKhz = 0L
            for (raw in read(cmd).output.lines()) {
                val l = raw.trim()
                when {
                    l == "#FREQ" -> section = 1
                    l == "#GPU" -> section = 2
                    l.isEmpty() -> {}
                    section == 0 && l.startsWith("cpu ") -> if (cpu == null) cpu = parseCpuLine(l)
                    section == 1 -> l.toLongOrNull()?.let { if (it > maxKhz) maxKhz = it }
                    section == 2 && gpu == null -> {
                        val src = if (l.contains('=')) l.substringAfter('=') else l
                        gpu = Regex("\\d+").find(src)?.value?.toIntOrNull()?.coerceIn(0, 100)
                    }
                }
            }
            if (shellFreq && maxKhz > 0L) ghz = maxKhz / 1_000_000f
        }
        if (needCpu && cpu == null && canRead()) {
            val t = read("dumpsys cpuinfo | grep TOTAL | head -n 1").output
            cpu = Regex("(\\d+(?:\\.\\d+)?)%\\s+TOTAL").find(t)?.groupValues?.get(1)?.toDoubleOrNull()
                ?.roundToInt()?.coerceIn(0, 100)
        }
        return SysSample(cpu, ghz, gpu)
    }

    private val layerCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val lastSample = java.util.concurrent.ConcurrentHashMap<String, LongArray>()
    @Volatile private var latencyFails = 0
    @Volatile private var latencyBroken = false
    @Volatile private var timeStatsReady = false

    /**
     * FPS game. Metode 1: `--latency` per layer (Android lama). Metode 2: TimeStats SurfaceFlinger
     * (jumlah frame per layer, dipakai Android 12+). Selalu mengembalikan alasan bila angka tidak ada.
     */
    fun measureFps(pkg: String): FpsResult {
        if (!safe(pkg)) return FpsResult(null, "nama paket tidak valid")
        var latencyNote = "dilewati"
        if (!latencyBroken) {
            val r = latencyMethod(pkg)
            if (r.fps != null) return r
            latencyNote = r.note
        }
        val t = timeStatsMethod(pkg)
        if (t.fps != null) return t
        return FpsResult(null, "latency: $latencyNote; timestats: ${t.note}")
    }

    /** Android 15 mencetak `--list` sebagai "RequestedLayerState{NAMA#id parentId=...}"; ambil NAMA bersihnya. */
    private fun cleanLayerName(line: String): String {
        var n = line.trim()
        if (n.startsWith("RequestedLayerState{")) n = n.removePrefix("RequestedLayerState{")
        val cut = n.indexOf(" parentId=")
        if (cut > 0) n = n.substring(0, cut)
        return n.trim()
    }

    private fun candidateLayers(pkg: String): Pair<List<String>, Int> {
        val listed = read("dumpsys SurfaceFlinger --list")
        val layers = listed.output.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val cands = layers
            .map { cleanLayerName(it) }
            .filter {
                it.contains(pkg) && !it.startsWith("Background") && !it.startsWith("Bounds") &&
                    !it.startsWith("Dim") && !it.startsWith("Surface(") && !it.startsWith("ActivityRecord") &&
                    !it.contains("InputSink")
            }
            .distinct()
            .sortedByDescending {
                (if (it.startsWith("SurfaceView[")) 3 else 0) + (if (it.contains("BLAST")) 2 else 0) +
                    (if (it.startsWith(pkg)) 1 else 0)
            }
        return cands to layers.size
    }

    private fun latencyMethod(pkg: String): FpsResult {
        val cached = layerCache[pkg]
        if (cached != null) {
            val f = latencyFps(cached)
            if (f != null) {
                latencyFails = 0
                return FpsResult(f, "ok")
            }
            layerCache.remove(pkg)
        }
        val (cands, total) = candidateLayers(pkg)
        if (total == 0) return FpsResult(null, "daftar layer kosong")
        if (cands.isEmpty()) return FpsResult(null, "layer game belum ada ($total layer)")
        var best: Int? = null
        var bestName: String? = null
        for (layer in cands.take(8)) {
            val variants = listOf(layer.replace(Regex("#\\d+$"), ""), layer).distinct()
            for (name in variants) {
                val f = latencyFps(name)
                val cur = best
                if (f != null && (cur == null || f > cur)) {
                    best = f
                    bestName = name
                }
                if (f != null) break
            }
        }
        val result = best
        val name = bestName
        if (result == null || name == null) {
            latencyFails++
            if (latencyFails >= 3) latencyBroken = true
            return FpsResult(null, "data frame kosong (${cands.size} layer)")
        }
        latencyFails = 0
        layerCache[pkg] = name
        return FpsResult(result, "ok")
    }

    private fun latencyFps(name: String): Int? {
        if (name.contains("'")) return null
        val lines = read("dumpsys SurfaceFlinger --latency '$name'").output.lines()
        val times = lines.drop(1).mapNotNull { l ->
            val parts = l.trim().split(Regex("\\s+"))
            val t = parts.getOrNull(1)?.toLongOrNull()
            if (t == null || t <= 0L || t == Long.MAX_VALUE) null else t
        }.takeLast(120)
        if (times.size < 5) return null
        val latest = times.last()
        if (System.nanoTime() - latest > 1_500_000_000L) return 0
        val recent = times.filter { latest - it <= 1_000_000_000L }
        val use = if (recent.size >= 4) recent else times.takeLast(30)
        val span = use.last() - use.first()
        if (span <= 0L) return null
        return ((use.size - 1) * 1_000_000_000.0 / span).toInt().coerceIn(0, 240)
    }

    /** TimeStats hanya mencatat layer yang dibuat SETELAH diaktifkan, jadi diaktifkan sedini mungkin. */
    fun enableTimeStats() {
        if (timeStatsReady) return
        read("dumpsys SurfaceFlinger --timestats -enable")
        timeStatsReady = true
    }

    private fun timeStatsDump(): ShellResult {
        var r = read("dumpsys SurfaceFlinger --timestats -dump")
        if (!r.output.contains("layerName")) r = read("dumpsys SurfaceFlinger --timestats")
        return r
    }

    /** FPS = selisih totalFrames layer game antara dua pembacaan dibagi selisih waktu. */
    private fun timeStatsMethod(pkg: String): FpsResult {
        if (!timeStatsReady) {
            read("dumpsys SurfaceFlinger --timestats -enable")
            timeStatsReady = true
        }
        val t0 = System.nanoTime()
        val r = timeStatsDump()
        val t1 = System.nanoTime()
        val at = (t0 + t1) / 2
        val out = r.output
        if (out.isBlank()) return FpsResult(null, "keluaran kosong ${r.error.take(30)}".trim())
        var name: String? = null
        var layerCount = 0
        val totals = LinkedHashMap<String, Long>()
        for (raw in out.lines()) {
            val l = raw.trim()
            if (l.startsWith("layerName")) {
                name = l.substringAfter("=").trim()
                layerCount++
            } else if (l.startsWith("totalFrames")) {
                val n = name
                val v = l.substringAfter("=").trim().toLongOrNull()
                if (n != null && v != null) totals[n] = v
            }
        }
        if (layerCount == 0) return FpsResult(null, "TimeStats tanpa layer")
        val mine = totals.filterKeys { it.contains(pkg) }
        if (mine.isEmpty()) return FpsResult(null, "game belum ada di TimeStats ($layerCount layer)")
        var best: Double? = null
        for ((layer, frames) in mine) {
            val prev = lastSample[layer]
            lastSample[layer] = longArrayOf(frames, at)
            if (prev != null && frames >= prev[0]) {
                val dt = (at - prev[1]) / 1e9
                if (dt in 0.2..6.0) {
                    val f = (frames - prev[0]) / dt
                    val cur = best
                    if (cur == null || f > cur) best = f
                }
            }
        }
        val b = best ?: return FpsResult(null, "mengukur...")
        return FpsResult(b.roundToInt().coerceIn(0, 240), "ok")
    }

    /** Laporan singkat untuk mencari tahu metode FPS mana yang didukung HP ini. */
    fun fpsDiagnostics(ctx: Context, pkg: String): String {
        val sb = StringBuilder()
        sb.append("AISZ diagnostik FPS\n")
        sb.append("HP: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("Shizuku=${ShizukuHelper.hasPermission()} DUMP=${hasDump(ctx)} game=$pkg\n")
        if (!safe(pkg)) return sb.append("paket tidak valid").toString()
        val (cands, total) = candidateLayers(pkg)
        sb.append("--list: $total layer, cocok game: ${cands.size}\n")
        cands.take(8).forEach { sb.append("  * ").append(it.take(110)).append('\n') }
        cands.take(3).forEach { c ->
            val nm = c.replace(Regex("#\\d+$"), "")
            if (nm.contains("'")) return@forEach
            val out = read("dumpsys SurfaceFlinger --latency '$nm'").output.lines()
            sb.append("--latency '${nm.take(60)}': ${out.size} baris; ")
            sb.append(out.take(3).joinToString(" | ").take(110)).append('\n')
        }
        val ts = timeStatsDump()
        val tl = ts.output.lines()
        sb.append("--timestats: ${tl.size} baris, err='${ts.error.take(40)}'\n")
        val tsNames = tl.filter { it.trim().startsWith("layerName") }
        sb.append("TimeStats layerName: ${tsNames.size}; contoh: ")
        sb.append(tsNames.take(3).joinToString(" | ") { it.trim().take(60) }).append('\n')
        tl.indices.filter { tl[it].contains(pkg) }.take(2).forEach { i ->
            tl.subList(max(0, i - 1), min(tl.size, i + 8)).forEach { sb.append("  ").append(it.take(100)).append('\n') }
        }
        return sb.toString().take(3800)
    }

    /**
     * Membuka aplikasi dalam jendela mengambang (freeform). Bentuk jendela dan perilaku game di
     * belakangnya ditentukan HyperOS, bukan aplikasi ini.
     */
    fun launchFreeform(context: Context, pkg: String): ShellResult {
        val comp = context.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            ?: return ShellResult(false, "", "Aplikasi tidak punya launcher")
        if (!safe(pkg) || !safe(comp.replace("$", ""))) return ShellResult(false, "", "Argumen tidak valid")
        val first = ShizukuHelper.exec("am start --windowingMode 5 -n '$comp'")
        if (first.ok) return first
        ShizukuHelper.exec(
            "settings put global enable_freeform_support 1; settings put global force_resizable_activities 1"
        )
        return ShizukuHelper.exec("am start --windowingMode 5 -n '$comp'")
    }

    fun resetFreeform(): ShellResult = ShizukuHelper.exec(
        "settings delete global enable_freeform_support; " +
            "settings delete global force_resizable_activities; " +
            "settings delete global freeform_window_management"
    )

    /** Foto seluruh properti sistem (getprop). Hanya membaca. */
    fun snapshotProps(): Map<String, String>? {
        if (!ShizukuHelper.hasPermission()) return null
        val m = HashMap<String, String>()
        val re = Regex("^\\[(.*?)\\]: \\[(.*)\\]$")
        for (line in ShizukuHelper.exec("getprop").output.lines()) {
            val g = re.find(line.trim())?.groupValues ?: continue
            m[g[1]] = g[2]
        }
        return m
    }

    /** Daftar berkas (ukuran|waktu ubah) di folder data/obb game. Hanya membaca, tidak mengubah apa pun. */
    fun snapshotFiles(pkgs: List<String>): Map<String, String>? {
        if (!ShizukuHelper.hasPermission()) return null
        val m = HashMap<String, String>()
        for (pkg in pkgs) {
            if (!Regex("[A-Za-z0-9._]+").matches(pkg) || pkg.contains("..")) continue
            for (base in listOf("/sdcard/Android/data/$pkg", "/sdcard/Android/obb/$pkg")) {
                val out = ShizukuHelper.exec(
                    "[ -d $base ] && find $base -type f -exec stat -c '%n|%s|%Y' {} + 2>/dev/null | head -n 30000"
                ).output
                for (line in out.lines()) {
                    val p = line.trim().split('|')
                    if (p.size == 3) m[p[0]] = "${p[1]}|${p[2]}"
                }
            }
        }
        return m
    }

    fun forceStop(pkg: String): ShellResult {
        if (!safe(pkg)) return ShellResult(false, "", "Argumen tidak valid")
        return ShizukuHelper.exec("am force-stop $pkg")
    }

    /** Mengembalikan aplikasi ke layar penuh (windowing mode 1). */
    fun bringFullscreen(context: Context, pkg: String): ShellResult {
        val comp = context.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            ?: return ShellResult(false, "", "Aplikasi tidak punya launcher")
        if (!safe(pkg) || !safe(comp.replace("$", ""))) return ShellResult(false, "", "Argumen tidak valid")
        return ShizukuHelper.exec("am start --windowingMode 1 -n '$comp'")
    }

    fun maxRefreshRate(context: Context): Float {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val d = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY) ?: return 60f
        return d.supportedModes.maxOfOrNull { it.refreshRate } ?: d.refreshRate
    }
}

/**
 * Menerapkan mode benar-benar ke HP:
 * - Hemat daya: Penghemat Baterai HP menyala (pengaturan hasil "Belajar mode" bila ada, selain itu AOSP).
 * - Seimbang: kondisi normal; Penghemat Baterai dan mode kinerja dimatikan, tidak ada yang lain.
 * - Performa: aplikasi latar ditutup (AISZ dan game tidak ikut), mode kinerja HP menyala, Game Mode performa.
 */
object ModeController {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun applyAsync(
        context: Context,
        p: GamingProfile,
        gamePkg: String?,
        onProgress: ((Float) -> Unit)? = null,
        onDone: ((String) -> Unit)? = null
    ) {
        val app = context.applicationContext
        executor.execute {
            val msg = applyBlocking(app, p, gamePkg) { f ->
                if (onProgress != null) main.post { onProgress(f) }
            }
            if (onDone != null) main.post { onDone(msg) }
        }
    }

    fun applyBlocking(ctx: Context, p: GamingProfile, gamePkg: String?, progress: (Float) -> Unit = {}): String {
        GameSettings(ctx).profile = p
        val parts = mutableListOf<String>()
        val shizuku = ShizukuHelper.hasPermission()
        progress(0.1f)

        // 1) Hemat daya
        val saverLearned = shizuku && ModeLearner.count(ctx, GamingProfile.HEMAT) > 0
        if (saverLearned) {
            val (ok, n) = ModeLearner.apply(ctx, GamingProfile.HEMAT, p == GamingProfile.HEMAT)
            if (p == GamingProfile.HEMAT) parts += if (ok > 0) "Hemat daya HP ON" else "Hemat daya HP gagal ($ok/$n)"
        }
        if (!(saverLearned && p == GamingProfile.HEMAT)) {
            when (setBatterySaver(ctx, p == GamingProfile.HEMAT)) {
                true -> if (p == GamingProfile.HEMAT) parts += "Penghemat Baterai ON"
                false -> parts += "Penghemat Baterai gagal"
                null -> parts += "aktifkan Penghemat Baterai di layar yang terbuka"
            }
        }
        progress(0.35f)

        // 2) Performa: hentikan aplikasi latar belakang, kecuali AISZ dan game
        if (p == GamingProfile.PERFORMA) {
            val freed = cleanBackground(ctx, setOf(gamePkg)) { f -> progress(0.35f + 0.3f * f) }
            parts += if (freed > 0) "app latar dihentikan (+$freed MB)" else "app latar sudah bersih"
        }
        progress(0.65f)

        // 3) Mode kinerja HP + Game Mode
        val perfLearned = shizuku && ModeLearner.count(ctx, GamingProfile.PERFORMA) > 0
        if (perfLearned) {
            val (ok, n) = ModeLearner.apply(ctx, GamingProfile.PERFORMA, p == GamingProfile.PERFORMA)
            if (p == GamingProfile.PERFORMA) parts += if (ok > 0) "Mode kinerja HP ON" else "Mode kinerja HP gagal ($ok/$n)"
        }
        if (shizuku) {
            if (!perfLearned) {
                val perf = ShellTools.setFixedPerformance(p == GamingProfile.PERFORMA)
                if (p == GamingProfile.PERFORMA) {
                    parts += if (perf.ok) "mode kinerja (Power HAL) ON" else "mode kinerja bawaan HP belum dikenali: pakai Atur > Belajar mode"
                }
            }
            if (gamePkg != null) {
                val gm = ShellTools.setGameMode(gamePkg, p.gameMode)
                parts += if (gm.ok) "Game Mode ${p.gameMode}" else "Game Mode tidak didukung game ini"
            }
        } else if (p == GamingProfile.PERFORMA) {
            parts += "mode kinerja HP butuh Shizuku"
        }
        progress(1f)
        val body = if (parts.isEmpty()) "tidak ada yang diubah" else parts.joinToString(" • ")
        return "Mode ${p.label}: $body"
    }

    /** true = berhasil, false = gagal, null = pengguna perlu mengaktifkan sendiri (pengaturan dibuka). */
    private fun setBatterySaver(ctx: Context, on: Boolean): Boolean? {
        val v = if (on) 1 else 0
        if (ShizukuHelper.hasPermission()) return ShellTools.setBatterySaver(on).ok
        if (ShellTools.hasSecureSettings(ctx)) {
            return try {
                Settings.Global.putInt(ctx.contentResolver, "low_power", v)
            } catch (e: Exception) {
                false
            }
        }
        if (on) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
            return null
        }
        return true
    }

    /**
     * Menghentikan proses latar belakang (cache). Aplikasi yang sedang tampil, AISZ (layanan latar
     * depan), dan game tidak ikut dihentikan. Mengembalikan MB memori yang bertambah.
     */
    fun cleanBackground(ctx: Context, keepExtra: Set<String?>, onStep: (Float) -> Unit = {}): Long {
        val pm = PerformanceMonitor(ctx)
        val before = pm.memory().availMb
        onStep(0.1f)
        if (ShizukuHelper.hasPermission()) {
            ShizukuHelper.exec("am kill-all")
        } else {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val keep = keepExtra + ctx.packageName
            ctx.packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            ).map { it.activityInfo.packageName }.distinct().filter { it !in keep }.forEach {
                try {
                    am.killBackgroundProcesses(it)
                } catch (_: Exception) {
                }
            }
        }
        onStep(0.6f)
        Thread.sleep(800)
        onStep(1f)
        return (pm.memory().availMb - before).coerceAtLeast(0L)
    }
}
