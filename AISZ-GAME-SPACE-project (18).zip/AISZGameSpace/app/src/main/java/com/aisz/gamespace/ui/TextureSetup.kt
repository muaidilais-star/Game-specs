package com.aisz.gamespace.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.ShellTools
import com.aisz.gamespace.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun TextureSetupScreen(
    gameName: String,
    onCancel: () -> Unit,
    onStart: (Boolean, Int, Boolean, Boolean, Boolean) -> Unit
) {
    val ctx = LocalContext.current
    val settings = remember { GameSettings(ctx) }
    var on by remember { mutableStateOf(false) }
    var level by remember { mutableStateOf(settings.texLevel) }
    var sharp by remember { mutableStateOf(settings.texSharp) }
    var noAniso by remember { mutableStateOf(settings.texNoAniso) }
    var sysProp by remember { mutableStateOf("") }
    var alt by remember { mutableStateOf(settings.texAlt) }
    var angleOk by remember { mutableStateOf<Boolean?>(null) }
    var shizuku by remember { mutableStateOf<Boolean?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val ok = withContext(Dispatchers.IO) { ShizukuHelper.hasPermission() }
        shizuku = ok
        if (ok) {
            on = withContext(Dispatchers.IO) { ShellTools.lightTextureOn() }
            sysProp = withContext(Dispatchers.IO) { ShellTools.lightTextureProp() }
            angleOk = withContext(Dispatchers.IO) { ShellTools.angleSupported() }
        }
    }

    val switchColors = SwitchDefaults.colors(
        checkedThumbColor = AiszColors.Black,
        checkedTrackColor = AiszColors.Neon,
        uncheckedThumbColor = AiszColors.TextDim,
        uncheckedTrackColor = AiszColors.SurfaceHigh
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (!busy) onCancel()
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .widthIn(max = 440.dp)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            GlowCard(
                Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            ) {
                SectionTitle("Tekstur Ringan")
                Text(
                    "Atur dulu sebelum $gameName dibuka. Tekstur dibuat kotak-kotak supaya GPU lebih ringan.",
                    color = AiszColors.TextDim,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Aktifkan Tekstur Ringan", color = AiszColors.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Switch(checked = on, onCheckedChange = { on = it }, enabled = shizuku == true, colors = switchColors)
                }
                if (shizuku == false) {
                    Text(
                        "Shizuku belum aktif, jadi pengaturan tidak bisa diterapkan. Game tetap dibuka seperti biasa.",
                        color = AiszColors.Warn,
                        fontSize = 11.sp
                    )
                }
                if (shizuku == true && angleOk == false) {
                    Text(
                        "HP ini sepertinya tidak punya lapisan grafis ANGLE, jadi tekstur kotak mungkin tidak muncul.",
                        color = AiszColors.Warn,
                        fontSize = 11.sp
                    )
                }
                if (on) {
                    Spacer(Modifier.height(10.dp))
                    SectionTitle("Tingkat kotak")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NeonChip("1 Tipis", level == 1, Modifier.weight(1f)) { level = 1 }
                        NeonChip("2 Sedikit", level == 2, Modifier.weight(1f)) { level = 2 }
                        NeonChip("3 Sedang", level == 3, Modifier.weight(1f)) { level = 3 }
                        NeonChip("4 Penuh", level == 4, Modifier.weight(1f)) { level = 4 }
                    }
                    Text(
                        when (level) {
                            1 -> "Tipis: kotak halus, garis blur di tanah hampir tidak ada. Hemat GPU paling kecil."
                            2 -> "Sedikit: kotak ringan, garis blur sedikit."
                            3 -> "Sedang: kotak jelas, garis blur di tanah mulai terlihat."
                            else -> "Penuh: paling kotak dan paling ringan, garis blur di tanah paling jelas."
                        },
                        color = AiszColors.TextDim,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Jarak tegas", color = AiszColors.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Switch(checked = sharp, onCheckedChange = { sharp = it }, colors = switchColors)
                    }
                    Text(
                        "Perpindahan detail tekstur antar jarak dibuat tegas, tanpa campuran halus. Blur yang berasal " +
                            "dari pengaturan grafis game sendiri tidak bisa dihilangkan dari sini.",
                        color = AiszColors.TextDim,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Eksperimen: matikan anisotropik", color = AiszColors.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Switch(checked = noAniso, onCheckedChange = { noAniso = it }, colors = switchColors)
                    }
                    Text(
                        "Dicoba bila jarak tegas belum mengubah apa pun. Hasilnya bisa lebih tajam atau malah lebih buram, tergantung game.",
                        color = AiszColors.TextDim,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    if (Build.VERSION.SDK_INT >= 33) {
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Mode alternatif: turunkan resolusi", color = AiszColors.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Switch(checked = alt, onCheckedChange = { alt = it }, colors = switchColors)
                        }
                        Text(
                            "Untuk HP tanpa ANGLE: menurunkan resolusi render game lewat Game Mode (Android 13+). " +
                                "Gambar jadi lebih pecah tetapi lebih ringan. Dipakai bersama tingkat di atas.",
                            color = AiszColors.TextDim,
                            fontSize = 11.sp
                        )
                    } else if (angleOk == false) {
                        Text(
                            "Android 12 tidak punya mode alternatif. Tekstur Ringan di HP ini bergantung pada ANGLE.",
                            color = AiszColors.TextDim,
                            fontSize = 11.sp
                        )
                    }
                    if (sysProp.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Terpasang di sistem: $sysProp", color = AiszColors.TextDim, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    "Jika game sedang berjalan, tutup dulu agar pengaturan berlaku.",
                    color = AiszColors.TextDim,
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    GhostButton("Batal", Modifier.weight(1f)) { if (!busy) onCancel() }
                    Spacer(Modifier.width(10.dp))
                    NeonButton("MULAI GAME", Modifier.weight(1.5f), enabled = !busy) {
                        busy = true
                        onStart(on, level, sharp, noAniso, alt)
                    }
                }
            }
        }
    }
}
