# AISZ GAME SPACE v1.6.0

Aplikasi Android (Kotlin + Jetpack Compose): dashboard bertema hitam-biru, panel gaming melayang,
game launcher dengan profil per game, monitor FPS/suhu/WLAN/latensi/RAM, rekam layar, Jangan Ganggu,
dan dukungan Shizuku (dimulai lewat ADB nirkabel).

- Package: `com.aisz.gamespace` - minSdk 24, target/compileSdk 35
- AGP 8.6.1, Gradle 8.7, Kotlin 1.9.24, Compose BOM 2024.06.00, JDK 17

## Build
- GitHub Actions: `.github/workflows` (APK debug sebagai artifact), atau
- Android Studio: Build > Build APK(s), atau `gradle assembleDebug`.

## Shizuku / ADB nirkabel
Fitur sistem (FPS game, Game Mode, Penghemat Baterai, kunci refresh rate, jendela mengambang)
memakai Shizuku. Mulai Shizuku lewat Debugging nirkabel (Android 11+) atau ADB dari PC, lalu
ketuk "Izinkan" di AISZ > Atur. Tanpa Shizuku fitur tersebut dinonaktifkan dengan pesan jelas.

## Catatan jujur
- Mode Hemat/Seimbang/Performa memakai Game Mode & Penghemat Baterai bawaan Android. Efeknya bergantung
  pada game dan ROM; tidak ada jaminan kenaikan FPS.
- FPS game dibaca dari SurfaceFlinger (best effort); bila tidak terbaca tampil N/A.
- Jendela mengambang memakai `am start --windowingMode 5`; hanya jalan jika ROM mendukung freeform.
- Rekam layar tanpa audio, disimpan di Movies/AISZ.

## Keamanan dan keaslian APK
- `keystore/aisz-release.keystore` adalah kunci tanda tangan tetap proyek ini. JANGAN dihapus, diganti
  isinya, atau dibuat ulang — semua build dari repo ini harus memakai keystore yang sama supaya tanda
  tangan APK tetap konsisten di setiap rilis.
- `IntegrityCheck.kt` membandingkan tanda tangan APK yang berjalan dengan nilai `EXPECTED_SHA256`. Kalau
  APK ini diambil, diubah, lalu ditandatangani ulang dengan kunci lain untuk dibagikan ulang, aplikasi akan
  menampilkan peringatan layar penuh dan panel Game Space tidak akan menyala.
- Bila keystore ini pernah diganti dengan yang baru (hilang/bocor), hitung ulang SHA-256 sertifikatnya:
  `keytool -exportcert -alias aisz -keystore keystore/aisz-release.keystore | sha256sum`, lalu tempel
  hasilnya (format dengan titik dua tiap 2 digit, huruf besar) ke `EXPECTED_SHA256` di `IntegrityCheck.kt`.
- `IntegrityCheck.watermark()` adalah kode identitas proyek ini, tampil di tab Profil > Kode proyek,
  sebagai bukti kepemilikan bila ada yang mengklaim membuat aplikasi ini.
- Batasannya: pemeriksaan ini mendeteksi APK yang sudah ditandatangani ulang, tapi tidak bisa mencegah
  seseorang yang cukup paham membongkar APK (decompile) dan menghapus kode pemeriksaannya sendiri sebelum
  menandatangani ulang. Tidak ada proteksi APK Android yang benar-benar tidak bisa ditembus; ini menaikkan
  usaha yang dibutuhkan dan membuat modifikasi kasar mudah ketahuan, bukan menutup semua celah.
