package com.aisz.gamespace

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.security.MessageDigest

/**
 * Memeriksa apakah APK yang berjalan masih ditandatangani dengan kunci asli proyek ini
 * (keystore/aisz-release.keystore, lihat app/build.gradle). Bila seseorang mengambil APK ini,
 * mengubahnya, lalu menandatangani ulang dengan kuncinya sendiri untuk dibagikan ulang, tanda tangan
 * yang terbaca di HP pengguna akan BERBEDA dari nilai di bawah, dan ini akan ketahuan.
 *
 * KODE RAHASIA (watermark pembuat): dipakai sebagai bukti kepemilikan bila ada yang mengklaim
 * membuat aplikasi ini. Jangan dibagikan di luar repo ini.
 */
object IntegrityCheck {
    /** Ubah SATU baris ini saja bila keystore/aisz-release.keystore diganti dengan keystore baru. */
    private const val EXPECTED_SHA256 = "F3:86:BA:C9:9C:D5:F9:1F:0E:03:69:81:6B:13:61:AF:FA:4C:4C:E4:52:6A:27:15:E8:7C:AD:02:F8:DA:C7:FC"

    /** Kode rahasia pembuat, dipecah jadi beberapa bagian supaya tidak langsung terbaca saat APK dibongkar. */
    private val W = charArrayOf('A', 'I', 'S', 'Z', '-', '2', '0', '2', '6', '-', 'm', 'u', 'a', 'i', 'd', 'i', 'l', 'a', 'i', 's', '-', 's', 't', 'a', 'r')
    fun watermark(): String = String(W)

    class Report(val ok: Boolean, val reason: String, val signatureHash: String?)

    /** True bila tanda tangan APK yang berjalan cocok dengan [EXPECTED_SHA256]. */
    fun check(ctx: Context): Report {
        val hash = currentSignatureSha256(ctx) ?: return Report(false, "Tanda tangan APK tidak terbaca", null)
        val ok = hash.equals(EXPECTED_SHA256, ignoreCase = true)
        val reason = if (ok) "Tanda tangan sesuai (asli)" else "Tanda tangan BERBEDA dari aslinya — APK ini kemungkinan telah diubah dan ditandatangani ulang oleh pihak lain"
        return Report(ok, reason, hash)
    }

    private fun currentSignatureSha256(ctx: Context): String? = try {
        val pm = ctx.packageManager
        val sigs: Array<Signature> = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val h = info.signingInfo
            if (h == null) emptyArray() else if (h.hasMultipleSigners()) h.apkContentsSigners else h.signingCertificateHistory
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        val s = sigs.firstOrNull() ?: return null
        val md = MessageDigest.getInstance("SHA-256")
        md.update(s.toByteArray())
        md.digest().joinToString(":") { String.format("%02X", it) }
    } catch (_: Exception) {
        null
    }
}
