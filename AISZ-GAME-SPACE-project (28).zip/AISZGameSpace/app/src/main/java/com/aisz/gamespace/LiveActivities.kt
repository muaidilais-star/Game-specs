package com.aisz.gamespace

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import kotlin.math.max

/** Penghubung sederhana: panel dipanggil ulang setelah foto atau link diganti. */
object LiveBridge {
    var onChanged: (() -> Unit)? = null
    const val IMAGE_FILE = "live_overlay.png"
}

/** Memilih foto dari HP; disalin (diperkecil) ke penyimpanan aplikasi sehingga tetap ada walau berkas asli dipindah. */
class LiveImagePickActivity : ComponentActivity() {

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            finish()
        } else {
            Thread {
                val ok = saveImage(uri)
                runOnUiThread {
                    if (ok) {
                        GameSettings(this).liveMode = 0
                        Toast.makeText(this, "Foto dipasang", Toast.LENGTH_SHORT).show()
                        LiveBridge.onChanged?.invoke()
                    } else {
                        Toast.makeText(this, "Foto tidak bisa dibaca", Toast.LENGTH_LONG).show()
                    }
                    finish()
                }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        picker.launch(arrayOf("image/*"))
    }

    private fun saveImage(uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val side = max(bounds.outWidth, bounds.outHeight)
        while (side / sample > 1600) sample *= 2
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (bmp == null) {
            false
        } else {
            File(filesDir, LiveBridge.IMAGE_FILE).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
            true
        }
    } catch (_: Exception) {
        false
    }
}

/** Mengisi link halaman untuk overlay (mis. dari Sociabuzz). Hanya https; dimuat tanpa login. */
class LiveLinkActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val input = EditText(this).apply {
            setText(GameSettings(this@LiveLinkActivity).liveUrl)
            hint = "https://sociabuzz.com/..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setSelectAllOnFocus(true)
        }
        val box = FrameLayout(this).apply {
            setPadding((20 * d).toInt(), (8 * d).toInt(), (20 * d).toInt(), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Link overlay")
            .setMessage("Tempel link halaman, misalnya dari Sociabuzz. Hanya link https. Halaman hanya ditampilkan, tanpa login dan tanpa terhubung ke akun.")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ -> save(input.text.toString()) }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun save(raw: String) {
        var s = raw.trim()
        if (s.isEmpty()) {
            finish()
            return
        }
        if (!s.contains("://")) s = "https://$s"
        val u = Uri.parse(s)
        if (u.scheme != "https" || u.host.isNullOrBlank()) {
            Toast.makeText(this, "Link harus diawali https://", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val g = GameSettings(this)
        g.liveUrl = s
        g.liveMode = 1
        Toast.makeText(this, "Link disimpan", Toast.LENGTH_SHORT).show()
        LiveBridge.onChanged?.invoke()
        finish()
    }
}
