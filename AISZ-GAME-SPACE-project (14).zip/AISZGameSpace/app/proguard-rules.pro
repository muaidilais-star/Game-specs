# Shizuku dipanggil lewat refleksi (newProcess) dan Binder
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.**
# Kode AISZ dibiarkan utuh agar aman dari kejutan R8; pustaka (Compose dll.) tetap diperkecil dan dioptimalkan
-keep class com.aisz.gamespace.** { *; }
