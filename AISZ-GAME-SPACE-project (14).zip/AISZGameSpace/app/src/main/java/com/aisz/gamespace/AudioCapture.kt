package com.aisz.gamespace

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max

/**
 * Merekam suara perangkat (suara game, lewat AudioPlaybackCapture Android 10+) dan/atau mikrofon,
 * dicampur jadi satu trek AAC di berkas m4a sementara. Digabung dengan video setelah rekaman selesai.
 */
class AudioCapture(
    val outFile: File,
    private val projection: MediaProjection,
    private val wantDevice: Boolean,
    private val wantMic: Boolean
) {
    @Volatile private var running = false
    @Volatile var hasAudio = false
        private set
    private var devRec: AudioRecord? = null
    private var micRec: AudioRecord? = null
    private var thread: Thread? = null

    /** True bila minimal satu sumber suara siap. */
    @SuppressLint("MissingPermission")
    fun prepare(): Boolean {
        val enc = AudioFormat.ENCODING_PCM_16BIT
        val mask = AudioFormat.CHANNEL_IN_MONO
        val bufSize = max(AudioRecord.getMinBufferSize(SAMPLE_RATE, mask, enc), 4096) * 4
        if (wantDevice && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val r = AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(cfg)
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(enc).setSampleRate(SAMPLE_RATE).setChannelMask(mask).build()
                    )
                    .setBufferSizeInBytes(bufSize)
                    .build()
                if (r.state == AudioRecord.STATE_INITIALIZED) devRec = r else r.release()
            } catch (_: Exception) {
            }
        }
        if (wantMic) {
            try {
                val r = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, mask, enc, bufSize)
                if (r.state == AudioRecord.STATE_INITIALIZED) micRec = r else r.release()
            } catch (_: Exception) {
            }
        }
        return devRec != null || micRec != null
    }

    fun start() {
        running = true
        val t = Thread({ pump() }, "aisz-audio")
        thread = t
        t.start()
    }

    /** Menghentikan perekaman dan menutup berkas audio (menunggu maksimal 3 detik). */
    fun stop() {
        running = false
        try {
            thread?.join(3000L)
        } catch (_: InterruptedException) {
        }
        thread = null
        releaseRecorders()
    }

    fun abort() {
        stop()
        releaseRecorders()
        outFile.delete()
    }

    private fun releaseRecorders() {
        try { devRec?.stop() } catch (_: Exception) {}
        try { devRec?.release() } catch (_: Exception) {}
        devRec = null
        try { micRec?.stop() } catch (_: Exception) {}
        try { micRec?.release() } catch (_: Exception) {}
        micRec = null
    }

    private fun pump() {
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var track = -1
        var muxStarted = false
        try {
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            c.start()
            codec = c
            outFile.delete()
            val m = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            devRec?.startRecording()
            micRec?.startRecording()

            val dev = ShortArray(CHUNK)
            val mic = ShortArray(CHUNK)
            val bytes = ByteArray(CHUNK * 2)
            val info = MediaCodec.BufferInfo()
            var total = 0L

            fun drain(eos: Boolean) {
                var tries = 0
                while (true) {
                    val idx = c.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!eos || ++tries > 300) return
                    } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxStarted) {
                            track = m.addTrack(c.outputFormat)
                            m.start()
                            muxStarted = true
                            hasAudio = true
                        }
                    } else if (idx >= 0) {
                        val buf = c.getOutputBuffer(idx)
                        if (buf != null && info.size > 0 && muxStarted &&
                            (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        ) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            m.writeSampleData(track, buf, info)
                        }
                        c.releaseOutputBuffer(idx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            while (running) {
                val dn = max(0, devRec?.read(dev, 0, CHUNK) ?: 0)
                val mn = max(0, micRec?.read(mic, 0, CHUNK) ?: 0)
                val n = max(dn, mn)
                if (n == 0) {
                    try { Thread.sleep(5L) } catch (_: InterruptedException) {}
                    continue
                }
                for (i in 0 until n) {
                    var s = 0
                    if (i < dn) s += dev[i]
                    if (i < mn) s += mic[i]
                    s = s.coerceIn(-32768, 32767)
                    bytes[i * 2] = (s and 0xFF).toByte()
                    bytes[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
                }
                val inIdx = c.dequeueInputBuffer(10_000L)
                if (inIdx >= 0) {
                    val ib: ByteBuffer? = c.getInputBuffer(inIdx)
                    if (ib != null) {
                        ib.clear()
                        ib.put(bytes, 0, n * 2)
                        c.queueInputBuffer(inIdx, 0, n * 2, total * 1_000_000L / SAMPLE_RATE, 0)
                        total += n
                    }
                }
                drain(false)
            }
            val eosIdx = c.dequeueInputBuffer(100_000L)
            if (eosIdx >= 0) {
                c.queueInputBuffer(eosIdx, 0, 0, total * 1_000_000L / SAMPLE_RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                drain(true)
            }
        } catch (_: Exception) {
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { if (muxStarted) muxer?.stop() } catch (_: Exception) { hasAudio = false }
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    private companion object {
        const val SAMPLE_RATE = 44100
        const val CHUNK = 1024
    }
}

/** Menggabungkan video (tanpa suara) dengan berkas audio menjadi satu mp4. */
object RecMux {
    fun merge(video: File, audio: File, out: File) {
        out.delete()
        val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val ve = MediaExtractor()
        val ae = MediaExtractor()
        try {
            ve.setDataSource(video.absolutePath)
            ae.setDataSource(audio.absolutePath)
            val vi = findTrack(ve, "video/")
            val ai = findTrack(ae, "audio/")
            if (vi < 0 || ai < 0) throw IllegalStateException("Trek tidak ditemukan")
            val vTrack = mux.addTrack(ve.getTrackFormat(vi))
            val aTrack = mux.addTrack(ae.getTrackFormat(ai))
            ve.selectTrack(vi)
            ae.selectTrack(ai)
            mux.start()
            val buf = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                val vt = timeOf(ve)
                val at = timeOf(ae)
                if (vt == Long.MAX_VALUE && at == Long.MAX_VALUE) break
                val useVideo = vt <= at
                val e = if (useVideo) ve else ae
                val tr = if (useVideo) vTrack else aTrack
                buf.clear()
                val size = e.readSampleData(buf, 0)
                if (size < 0) {
                    e.advance()
                    continue
                }
                val flags = if ((e.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, size, e.sampleTime, flags)
                mux.writeSampleData(tr, buf, info)
                e.advance()
            }
            mux.stop()
        } finally {
            try { ve.release() } catch (_: Exception) {}
            try { ae.release() } catch (_: Exception) {}
            try { mux.release() } catch (_: Exception) {}
        }
    }

    private fun timeOf(e: MediaExtractor): Long {
        val t = e.sampleTime
        return if (t < 0) Long.MAX_VALUE else t
    }

    private fun findTrack(e: MediaExtractor, prefix: String): Int {
        for (i in 0 until e.trackCount) {
            val mime = e.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }
}
