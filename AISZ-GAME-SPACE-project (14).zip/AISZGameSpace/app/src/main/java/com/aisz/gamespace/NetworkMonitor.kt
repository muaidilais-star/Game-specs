package com.aisz.gamespace

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.InetSocketAddress
import java.net.Socket

data class NetStatus(
    val transport: String,
    val rssiDbm: Int?,
    val linkMbps: Int?,
    val band: String?
)

/** Status jaringan dan latensi (waktu koneksi TCP). Panggil pingMs dari thread latar belakang. */
class NetworkMonitor(context: Context) {
    private val app = context.applicationContext

    @Suppress("DEPRECATION")
    fun status(): NetStatus {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return when {
            caps == null -> NetStatus("Offline", null, null, null)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val info = wm.connectionInfo
                val rssi = info?.rssi?.takeIf { it > -127 }
                val link = info?.linkSpeed?.takeIf { it > 0 }
                val f = info?.frequency ?: 0
                val band = when {
                    f in 2400..2500 -> "2,4 GHz"
                    f in 4900..5900 -> "5 GHz"
                    f > 5900 -> "6 GHz"
                    else -> null
                }
                NetStatus("WLAN", rssi, link, band)
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetStatus("Seluler", null, null, null)
            else -> NetStatus("Jaringan", null, null, null)
        }
    }

    fun pingMs(host: String = "1.1.1.1", port: Int = 443, timeoutMs: Int = 1500): Int? = try {
        Socket().use { s ->
            val t0 = System.nanoTime()
            s.connect(InetSocketAddress(host, port), timeoutMs)
            ((System.nanoTime() - t0) / 1_000_000L).toInt()
        }
    } catch (e: Exception) {
        null
    }
}
