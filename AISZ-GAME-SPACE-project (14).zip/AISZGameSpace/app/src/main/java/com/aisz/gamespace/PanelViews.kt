package com.aisz.gamespace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Menggambar crosshair gaya 0..4 di pusat (cx, cy) dengan ukuran s. Dipakai overlay dan pratinjau. */
internal fun drawCrosshair(
    c: Canvas, style: Int, cx: Float, cy: Float, s: Float, color: Int, alpha: Int, density: Float
) {
    val sw = max(1.6f * density, s * 0.045f)
    val half = s / 2f
    val main = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = sw
        this.color = color
        this.alpha = alpha
    }
    val edge = Paint(main).apply {
        strokeWidth = sw + 2.2f * density
        this.color = Color.BLACK
        this.alpha = (alpha * 0.45f).toInt()
    }
    fun both(draw: (Paint) -> Unit) {
        draw(edge)
        draw(main)
    }
    when (style) {
        0 -> both { p ->
            c.drawLine(cx - half, cy, cx + half, cy, p)
            c.drawLine(cx, cy - half, cx, cy + half, p)
        }
        1 -> both { p ->
            p.pathEffect = DashPathEffect(floatArrayOf(sw * 2.4f, sw * 2.4f), 0f)
            c.drawLine(cx - half, cy, cx + half, cy, p)
            c.drawLine(cx, cy - half, cx, cy + half, p)
            p.pathEffect = null
        }
        2 -> both { p ->
            val gap = half * 0.3f
            c.drawLine(cx - half, cy, cx - gap, cy, p)
            c.drawLine(cx + gap, cy, cx + half, cy, p)
            c.drawLine(cx, cy - half, cx, cy - gap, p)
            c.drawLine(cx, cy + gap, cx, cy + half, p)
        }
        3 -> {
            val r = max(2f * density, s * 0.09f)
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.FILL }
            dot.color = Color.BLACK
            dot.alpha = (alpha * 0.45f).toInt()
            c.drawCircle(cx, cy, r + 1.2f * density, dot)
            dot.color = color
            dot.alpha = alpha
            c.drawCircle(cx, cy, r, dot)
        }
        else -> {
            val r = half * 0.5f
            both { p ->
                c.drawCircle(cx, cy, r, p)
                c.drawLine(cx - half, cy, cx - r * 0.55f, cy, p)
                c.drawLine(cx + r * 0.55f, cy, cx + half, cy, p)
                c.drawLine(cx, cy - half, cx, cy - r * 0.55f, p)
                c.drawLine(cx, cy + r * 0.55f, cx, cy + half, p)
            }
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.FILL }
            dot.color = color
            dot.alpha = alpha
            c.drawCircle(cx, cy, max(1.4f * density, s * 0.03f), dot)
        }
    }
}

/**
 * Crosshair: dipakai sebagai overlay di layar (ukuran = bentuk + bantalan) dan sebagai pratinjau kecil
 * (padPx = 0). Saat editing, bisa diseret dan memiliki tombol centang untuk menyimpan posisi.
 */
class CrosshairView(context: Context) : View(context) {
    var style: Int = 0
        set(v) { field = v; invalidate() }
    var color: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    var shapeAlpha: Int = 255
        set(v) { field = v; invalidate() }
    var shapeSizePx: Int = 0
        set(v) { field = v; requestLayout(); invalidate() }
    var padPx: Int = 0
        set(v) { field = v; requestLayout() }
    var editing: Boolean = false
        set(v) { field = v; invalidate() }
    var onCheck: (() -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        color = Color.argb(190, 255, 255, 255)
        pathEffect = DashPathEffect(floatArrayOf(6f * d, 4f * d), 0f)
    }
    private val chip = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E65B9BE0") }
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2.2f
        color = Color.WHITE
    }
    private val gp = Path()
    private val rect = RectF()
    private var lastX = 0f
    private var lastY = 0f
    private var checkDown = false

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val s = shapeSizePx + 2 * padPx
        setMeasuredDimension(resolveSize(s, widthSpec), resolveSize(s, heightSpec))
    }

    private fun chipCx() = width - 16f * d
    private fun chipCy() = 16f * d

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        drawCrosshair(c, style, cx, cy, shapeSizePx.toFloat(), color, shapeAlpha, d)
        if (editing) {
            val r = shapeSizePx / 2f + 8f * d
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawRoundRect(rect, 10f * d, 10f * d, border)
            c.drawCircle(chipCx(), chipCy(), 14f * d, chip)
            val gs = 16f * d
            c.save()
            c.translate(chipCx() - gs / 2f, chipCy() - gs / 2f)
            c.scale(gs / 24f, gs / 24f)
            drawGlyph(c, Glyph.CHECK, glyphPaint, gp)
            c.restore()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                checkDown = hypot(e.x - chipCx(), e.y - chipCy()) <= 20f * d
            }
            MotionEvent.ACTION_MOVE -> {
                if (!checkDown) {
                    onDrag?.invoke(e.rawX - lastX, e.rawY - lastY)
                    lastX = e.rawX
                    lastY = e.rawY
                }
            }
            MotionEvent.ACTION_UP -> {
                if (checkDown && hypot(e.x - chipCx(), e.y - chipCy()) <= 24f * d) onCheck?.invoke()
                else onDragEnd?.invoke()
                checkDown = false
            }
            MotionEvent.ACTION_CANCEL -> {
                onDragEnd?.invoke()
                checkDown = false
            }
        }
        return true
    }
}

/** Saklar hidup/mati dengan animasi halus. */
class ToggleSwitch(context: Context) : View(context) {
    var accent: Int = Color.parseColor("#5B9BE0")
        set(v) { field = v; invalidate() }
    var onToggle: ((Boolean) -> Unit)? = null
    private var checked = false
    private var pos = 0f
    private var anim: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()

    fun setCheckedSilently(c: Boolean) {
        anim?.cancel()
        checked = c
        pos = if (c) 1f else 0f
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        track.color = ColorUtils.blendARGB(Color.parseColor("#4A5260"), accent, pos)
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, track)
        val cx = r + (w - 2f * r) * pos
        c.drawCircle(cx, r, r - 3f * d, thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP &&
            e.x in 0f..width.toFloat() && e.y in 0f..height.toFloat()
        ) {
            checked = !checked
            anim?.cancel()
            anim = ValueAnimator.ofFloat(pos, if (checked) 1f else 0f).apply {
                duration = 160
                addUpdateListener {
                    pos = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
            onToggle?.invoke(checked)
        }
        return true
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}

/** Teks "FOKUS AKTIF" berwarna biru transparan yang muncul huruf demi huruf dengan kilau, lalu memudar. */
class FocusBannerView(context: Context, private val title: String, private val sub: String) : View(context) {
    private val d = resources.displayMetrics.density
    private var p = 0f
    private var anim: ValueAnimator? = null
    private val main = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.ITALIC)
        textSize = 34f * d
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        textSize = 11f * d
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.12f
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2f * d
    }

    fun start(onEnd: () -> Unit) {
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2800L
            interpolator = LinearInterpolator()
            addUpdateListener {
                p = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onEnd()
                }
            })
            start()
        }
    }

    fun cancel() {
        anim?.removeAllListeners()
        anim?.cancel()
        anim = null
    }

    private fun easeOut(t: Float): Float {
        val u = 1f - t.coerceIn(0f, 1f)
        return 1f - u * u * u
    }

    override fun onDraw(c: Canvas) {
        val n = title.length
        if (n == 0) return
        val gap = 5f * d
        val ws = FloatArray(n) { main.measureText(title[it].toString()) + gap }
        val total = ws.sum()
        val startX = (width - total) / 2f
        val baseY = height * 0.5f
        val out = if (p > 0.82f) (1f - (p - 0.82f) / 0.18f).coerceIn(0f, 1f) else 1f
        val sweep = (p - 0.40f) / 0.32f
        var x0 = startX
        for (i in 0 until n) {
            val local = ((p - i.toFloat() / n * 0.38f) / 0.22f).coerceIn(0f, 1f)
            val e = easeOut(local)
            val cx = x0 + ws[i] / 2f
            val glow = if (sweep in 0f..1f) {
                (1f - abs(cx - (startX + total * sweep)) / (total * 0.16f)).coerceIn(0f, 1f)
            } else 0f
            val alpha = ((0.60f + 0.32f * glow) * e * out).coerceIn(0f, 1f)
            val r = (77 + 150 * glow).toInt()
            val gr = (163 + 80 * glow).toInt()
            main.color = Color.argb((alpha * 255).toInt(), r, gr, 255)
            main.setShadowLayer(14f * d, 0f, 0f, Color.argb((alpha * 210).toInt(), 64, 160, 255))
            c.save()
            c.translate(x0, baseY + (1f - e) * 18f * d)
            val sc = 0.7f + 0.3f * e
            c.scale(sc, sc, ws[i] / 2f, -main.textSize * 0.35f)
            c.drawText(title[i].toString(), 0f, 0f, main)
            c.restore()
            x0 += ws[i]
        }
        val ew = total * easeOut(p / 0.45f)
        line.color = Color.argb((140 * out).toInt(), 77, 163, 255)
        c.drawLine(width / 2f - ew / 2f, baseY + 12f * d, width / 2f + ew / 2f, baseY + 12f * d, line)
        val a2 = (((p - 0.35f) / 0.25f).coerceIn(0f, 1f) * out)
        if (a2 > 0f && sub.isNotEmpty()) {
            small.color = Color.argb((a2 * 170).toInt(), 150, 200, 255)
            c.drawText(sub, width / 2f, baseY + 36f * d, small)
        }
    }
}


/** Pegangan biru transparan untuk menggeser jendela mengambang; bagian kanan (x) menyembunyikannya. */
class FloatHandleView(context: Context) : View(context) {
    var onDrag: ((Float, Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null
    private val d = resources.displayMetrics.density
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var onClosePart = false
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 40, 130, 255) }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
        color = Color.argb(200, 150, 200, 255)
    }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(230, 235, 245, 255)
    }

    override fun onDraw(c: Canvas) {
        val r = height / 2f
        val rect = RectF(1f * d, 1f * d, width - 1f * d, height - 1f * d)
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, edge)
        val cx = (width - 30f * d) / 2f
        val cy = height / 2f
        for (i in -1..1) c.drawLine(cx - 14f * d, cy + i * 4f * d, cx + 14f * d, cy + i * 4f * d, mark)
        val xc = width - 18f * d
        val s = 4.5f * d
        c.drawLine(xc - s, cy - s, xc + s, cy + s, mark)
        c.drawLine(xc - s, cy + s, xc + s, cy - s, mark)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                downX = e.rawX
                downY = e.rawY
                onClosePart = e.x > width - 34f * d
            }
            MotionEvent.ACTION_MOVE -> if (!onClosePart) {
                onDrag?.invoke(e.rawX - lastX, e.rawY - lastY)
                lastX = e.rawX
                lastY = e.rawY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (onClosePart) {
                    if (e.actionMasked == MotionEvent.ACTION_UP && e.x > width - 34f * d &&
                        hypot(e.rawX - downX, e.rawY - downY) < 12f * d
                    ) onClose?.invoke()
                } else {
                    onDragEnd?.invoke()
                }
            }
        }
        return true
    }
}
