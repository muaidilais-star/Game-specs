package com.aisz.gamespace

/**
 * Pelacak perubahan (HANYA MEMBACA): membandingkan pengaturan sistem, properti sistem, dan daftar berkas
 * game sebelum dan sesudah pengguna menyalakan sebuah fitur di aplikasi lain, untuk mengetahui apa yang
 * sebenarnya diubah. Tidak ada yang ditulis atau diubah oleh alat ini.
 */
object ChangeTracker {
    private val GAME_PACKAGES = listOf("com.dts.freefiremax", "com.dts.freefireth")

    class Snap(
        val settings: Map<String, String>,
        val props: Map<String, String>,
        val files: Map<String, String>
    )

    fun take(): Snap? {
        val st = ModeLearner.snapshot() ?: return null
        val pr = ShellTools.snapshotProps() ?: return null
        val fl = ShellTools.snapshotFiles(GAME_PACKAGES) ?: return null
        return Snap(st, pr, fl)
    }

    private fun short(path: String): String =
        path.substringAfter("/Android/", path).let { if (it.length > 90) "…" + it.takeLast(88) else it }

    fun report(b: Snap, a: Snap): String {
        val sb = StringBuilder()
        sb.append("AISZ pelacak perubahan (hanya membaca)\n")

        val sc = ModeLearner.diff(b.settings, a.settings)
        sb.append("\n[Pengaturan sistem] ${sc.size} berubah\n")
        sc.take(40).forEach { sb.append("  ${it.id}: ${it.oldValue ?: "-"} -> ${it.newValue}\n") }

        val pChanged = a.props.filter { (k, v) -> b.props[k] != v }
        sb.append("\n[Properti sistem] ${pChanged.size} berubah\n")
        pChanged.entries.sortedBy { it.key }.take(40).forEach {
            sb.append("  ${it.key}: ${b.props[it.key] ?: "-"} -> ${it.value}\n".take(140))
        }

        val added = a.files.keys.filter { it !in b.files }
        val removed = b.files.keys.filter { it !in a.files }
        val changed = a.files.filter { (k, v) -> b.files[k] != null && b.files[k] != v }.keys
        sb.append("\n[Berkas game] sebelum ${b.files.size}, sesudah ${a.files.size}\n")
        sb.append("  ditambah ${added.size}, dihapus ${removed.size}, berubah ${changed.size}\n")
        added.sorted().take(15).forEach { sb.append("  + ${short(it)}\n") }
        removed.sorted().take(10).forEach { sb.append("  - ${short(it)}\n") }
        changed.sorted().take(15).forEach { sb.append("  ~ ${short(it)}\n") }
        if (sc.isEmpty() && pChanged.isEmpty() && added.isEmpty() && removed.isEmpty() && changed.isEmpty()) {
            sb.append("\nTidak ada perubahan terdeteksi. Pastikan fitur sudah dinyalakan (dan game sudah dibuka bila perlu) sebelum foto SESUDAH.\n")
        }
        return sb.toString().take(7000)
    }
}
