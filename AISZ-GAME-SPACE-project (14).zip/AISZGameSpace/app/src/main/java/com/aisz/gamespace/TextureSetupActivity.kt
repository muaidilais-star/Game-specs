package com.aisz.gamespace

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.aisz.gamespace.ui.AiszTheme
import com.aisz.gamespace.ui.TextureSetupScreen

/** Layar singkat sebelum Free Fire / Free Fire MAX dibuka: atur Tekstur Ringan, lalu mulai game. */
class TextureSetupActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PKG)
        if (pkg == null) {
            finish()
            return
        }
        val applyProfile = intent.getBooleanExtra(EXTRA_PROFILE, true)
        val name = if (pkg == "com.dts.freefiremax") "Free Fire MAX" else "Free Fire"
        setContent {
            AiszTheme {
                TextureSetupScreen(
                    gameName = name,
                    onCancel = { finish() },
                    onStart = { on, level, sharp, noAniso ->
                        val settings = GameSettings(this)
                        settings.texLevel = level
                        settings.texSharp = sharp
                        settings.texNoAniso = noAniso
                        Thread {
                            var info = ""
                            if (ShizukuHelper.hasPermission()) {
                                val r = ShellTools.setLightTexture(on, level, sharp, noAniso)
                                info = if (!r.ok) "Gagal menerapkan: ${r.error.take(60)}"
                                else if (on) "Terpasang: " + ShellTools.lightTextureProp().replace("force", "").replace("Filtering", "")
                                else "Tekstur Ringan dimatikan"
                            }
                            runOnUiThread {
                                if (info.isNotEmpty()) Toast.makeText(this, info, Toast.LENGTH_LONG).show()
                                GameLauncher(this).launch(pkg, applyProfile, skipSetup = true)
                                finish()
                            }
                        }.start()
                    }
                )
            }
        }
    }

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_PROFILE = "apply_profile"
    }
}
