package com.aisz.gamespace.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.MainActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest

/** Urutan tab = urutan di bilah navigasi. */
enum class Tab(val label: String, val icon: ImageVector) {
    GAMES("Game", Icons.Filled.PlayArrow),
    DASHBOARD("Home", Icons.Filled.Home),
    MONITOR("Monitor", Icons.Filled.Info),
    SETTINGS("Atur", Icons.Filled.Settings)
}

private val AlwaysActive: State<Boolean> = mutableStateOf(true)

/** Menandakan apakah tab pemilik composable ini sedang tampil. */
val LocalTabActive = compositionLocalOf<State<Boolean>> { AlwaysActive }

/** Menjalankan pembaruan berkala HANYA saat tab tampil (tab di latar tidak memboroskan tenaga). */
@Composable
fun WhileActive(block: suspend () -> Unit) {
    val active = LocalTabActive.current
    LaunchedEffect(Unit) {
        snapshotFlow { active.value }.collectLatest { on -> if (on) block() }
    }
}

/** Latar statis (digambar sekali, tanpa animasi terus-menerus). */
@Composable
private fun AmbientGlow() {
    Canvas(Modifier.fillMaxSize()) {
        val r = size.maxDimension * 0.55f
        val c1 = Offset(size.width * 0.15f, size.height * 0.06f)
        val c2 = Offset(size.width * 0.9f, size.height * 0.95f)
        drawCircle(
            Brush.radialGradient(listOf(AiszColors.Neon.copy(alpha = 0.16f), Color.Transparent), center = c1, radius = r),
            radius = r, center = c1
        )
        drawCircle(
            Brush.radialGradient(listOf(AiszColors.NeonSoft.copy(alpha = 0.10f), Color.Transparent), center = c2, radius = r),
            radius = r, center = c2
        )
    }
}

@Composable
private fun NavItem(t: Tab, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) AiszColors.Neon.copy(alpha = 0.2f) else Color.Transparent,
        tween(150), label = "navBg"
    )
    Row(
        Modifier
            .clip(RoundedCornerShape(26.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = if (selected) 16.dp else 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(t.icon, contentDescription = t.label, tint = if (selected) AiszColors.Neon else AiszColors.TextDim)
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Text(t.label, color = AiszColors.Neon, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun PillNav(tabState: MutableState<Tab>) {
    val tab = tabState.value
    val shape = RoundedCornerShape(32.dp)
    Box(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            Modifier
                .clip(shape)
                .background(AiszColors.Surface)
                .border(1.dp, AiszColors.Neon.copy(alpha = 0.3f), shape)
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Tab.values().forEach { t -> NavItem(t, tab == t) { tabState.value = t } }
        }
    }
}

/**
 * Setiap tab dikomposisi SEKALI lalu dipertahankan. Berpindah tab hanya menampilkan/menyembunyikan
 * (tanpa komposisi ulang), jadi animasi navigasi tidak patah-patah.
 */
@Composable
private fun TabHost(t: Tab, current: State<Tab>, activity: MainActivity, go: (Tab) -> Unit) {
    val active = remember(t) { derivedStateOf { current.value == t } }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(t) {
        snapshotFlow { active.value }.collect { on ->
            if (on) {
                fade.snapTo(0f)
                fade.animateTo(1f, tween(140))
            }
        }
    }
    CompositionLocalProvider(LocalTabActive provides active) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = fade.value }
                .layout { m, c ->
                    val p = m.measure(c)
                    // Tab tidak aktif tidak ditempatkan: tidak tergambar dan tidak menerima sentuhan.
                    layout(p.width, p.height) { if (active.value) p.place(0, 0) }
                }
        ) {
            when (t) {
                Tab.DASHBOARD -> HomeScreen(activity, go)
                Tab.GAMES -> GamesScreen(activity)
                Tab.MONITOR -> MonitorScreen()
                Tab.SETTINGS -> SettingsScreen(activity)
            }
        }
    }
}

@Composable
fun AiszApp(activity: MainActivity) {
    val tabState = remember { mutableStateOf(Tab.DASHBOARD) }
    val go = remember { { t: Tab -> tabState.value = t } }
    var mounted by remember { mutableStateOf(setOf(Tab.DASHBOARD)) }

    // Komposisi tab lain disiapkan bertahap setelah Home tampil, supaya tidak ada jeda saat berpindah.
    LaunchedEffect(Unit) {
        delay(1200)
        for (t in listOf(Tab.GAMES, Tab.MONITOR, Tab.SETTINGS)) {
            mounted = mounted + t
            delay(450)
        }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { tabState.value }.collect { t -> if (t !in mounted) mounted = mounted + t }
    }

    Box(Modifier.fillMaxSize().background(AiszColors.Black)) {
        AmbientGlow()
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = { PillNav(tabState) }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                Tab.values().forEach { t ->
                    if (t in mounted) key(t) { TabHost(t, tabState, activity, go) }
                }
            }
        }
        if (activity.guideVisible.value) {
            OnboardingScreen(activity) {
                GameSettings(activity).onboardingDone = true
                activity.guideVisible.value = false
            }
        }
    }
}
