package com.aisz.gamespace

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/** Aktivitas transparan: meminta izin mikrofon (bila suara dipilih) dan izin rekam layar, lalu memulai ScreenRecorderService. */
class RecordRequestActivity : ComponentActivity() {

    private var wantMic = false
    private var wantDevice = false

    private fun audioGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            val ok = audioGranted()
            val i = Intent(this, ScreenRecorderService::class.java)
                .setAction(ScreenRecorderService.ACTION_START)
                .putExtra(ScreenRecorderService.EXTRA_RESULT_CODE, res.resultCode)
                .putExtra(ScreenRecorderService.EXTRA_DATA, data)
                .putExtra(ScreenRecorderService.EXTRA_MIC, wantMic && ok)
                .putExtra(ScreenRecorderService.EXTRA_DEVICE, wantDevice && ok)
            ContextCompat.startForegroundService(this, i)
        } else {
            Toast.makeText(this, "Izin rekam layar ditolak.", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    private val audioPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            Toast.makeText(this, "Izin mikrofon ditolak, merekam tanpa suara.", Toast.LENGTH_SHORT).show()
        }
        startCapture()
    }

    private fun startCapture() {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(mgr.createScreenCaptureIntent())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = GameSettings(this)
        wantMic = s.recMic
        wantDevice = s.recDevice
        if ((wantMic || wantDevice) && !audioGranted()) {
            audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            startCapture()
        }
    }
}
