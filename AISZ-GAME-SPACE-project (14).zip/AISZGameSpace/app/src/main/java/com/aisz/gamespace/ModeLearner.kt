package com.aisz.gamespace

import android.content.Context

data class SettingChange(val ns: String, val key: String, val oldValue: String?, val newValue: String) {
    val id: String get() = "$ns/$key"
}

/**
 * "Belajar mode": menyimpan perubahan pengaturan sistem yang terjadi saat pengguna menyalakan sendiri
 * Hemat daya / mode kinerja di HP-nya, lalu memutar ulang perubahan itu saat mode dipilih di AISZ.
 * Berlaku untuk fitur HP yang digerakkan oleh pengaturan sistem (umumnya begitu di MIUI/HyperOS).
 */
object ModeLearner {
    private val NAMESPACES = listOf("system", "global", "secure")
    private val SAFE_KEY = Regex("[A-Za-z0-9_.:\\-]+")
    private val RELEVANT = Regex("(?i)(power|save|perf|batt|mode|turbo|boost|thermal|game|cpu|gpu|hyper)")
    private const val SEP = "\u001F"
    private const val REC = "\u001E"
    private const val NULLV = "\u0000null"

    /** Foto seluruh pengaturan. Butuh Shizuku; null bila tidak tersedia. */
    fun snapshot(): Map<String, String>? {
        if (!ShizukuHelper.hasPermission()) return null
        val m = HashMap<String, String>()
        for (ns in NAMESPACES) {
            val r = ShizukuHelper.exec("settings list $ns")
            for (line in r.output.lines()) {
                val i = line.indexOf('=')
                if (i <= 0) continue
                m["$ns/${line.substring(0, i)}"] = line.substring(i + 1)
            }
        }
        return m
    }

    fun diff(before: Map<String, String>, after: Map<String, String>): List<SettingChange> {
        val out = ArrayList<SettingChange>()
        for ((k, v) in after) {
            val old = before[k]
            if (old == v) continue
            val ns = k.substringBefore('/')
            val key = k.substringAfter('/')
            if (!SAFE_KEY.matches(key) || v.length > 200 || v.contains('\'') || v.contains('\n')) continue
            if (old != null && (old.contains('\'') || old.contains('\n'))) continue
            out += SettingChange(ns, key, old, v)
        }
        return out.sortedBy { it.id }
    }

    fun looksRelevant(c: SettingChange): Boolean = RELEVANT.containsMatchIn(c.key)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("aisz_modes", Context.MODE_PRIVATE)

    fun save(ctx: Context, profile: GamingProfile, changes: List<SettingChange>) {
        val s = changes.joinToString(REC) {
            listOf(it.ns, it.key, it.oldValue ?: NULLV, it.newValue).joinToString(SEP)
        }
        prefs(ctx).edit().putString("learn_${profile.name}", s).apply()
    }

    fun load(ctx: Context, profile: GamingProfile): List<SettingChange> {
        val raw = prefs(ctx).getString("learn_${profile.name}", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split(REC).mapNotNull { rec ->
            val p = rec.split(SEP)
            if (p.size != 4) null else SettingChange(p[0], p[1], if (p[2] == NULLV) null else p[2], p[3])
        }
    }

    fun count(ctx: Context, profile: GamingProfile): Int = load(ctx, profile).size

    fun clear(ctx: Context, profile: GamingProfile) {
        prefs(ctx).edit().remove("learn_${profile.name}").apply()
    }

    /** on=true menyalakan perubahan yang dipelajari, on=false mengembalikan nilai asalnya. Hasil: (berhasil, total). */
    fun apply(ctx: Context, profile: GamingProfile, on: Boolean): Pair<Int, Int> {
        val list = load(ctx, profile)
        var ok = 0
        for (c in list) {
            if (!SAFE_KEY.matches(c.key) || c.ns !in NAMESPACES) continue
            val value = if (on) c.newValue else c.oldValue
            if (value != null && (value.contains('\'') || value.contains('\n'))) continue
            val cmd = if (value == null) {
                "settings delete ${c.ns} ${c.key}"
            } else {
                "settings put ${c.ns} ${c.key} '$value'"
            }
            if (ShizukuHelper.exec(cmd).ok) ok++
        }
        return ok to list.size
    }
}
