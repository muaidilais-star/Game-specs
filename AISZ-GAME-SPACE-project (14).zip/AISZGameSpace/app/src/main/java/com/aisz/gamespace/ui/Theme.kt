package com.aisz.gamespace.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object AiszColors {
    val Black = Color(0xFF05070D)
    val Surface = Color(0xFF0B1220)
    val SurfaceHigh = Color(0xFF111B30)
    val Neon = Color(0xFF00B7FF)
    val NeonSoft = Color(0xFF4DD2FF)
    val Text = Color(0xFFE6F4FF)
    val TextDim = Color(0xFF8AA4BF)
    val Ok = Color(0xFF2BE38B)
    val Warn = Color(0xFFFFB020)
    val Hot = Color(0xFFFF4D5E)
}

private val AiszScheme = darkColorScheme(
    primary = AiszColors.Neon,
    onPrimary = AiszColors.Black,
    secondary = AiszColors.NeonSoft,
    background = AiszColors.Black,
    onBackground = AiszColors.Text,
    surface = AiszColors.Surface,
    onSurface = AiszColors.Text,
    surfaceVariant = AiszColors.SurfaceHigh,
    onSurfaceVariant = AiszColors.TextDim,
    error = AiszColors.Hot
)

@Composable
fun AiszTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AiszScheme, content = content)
}
